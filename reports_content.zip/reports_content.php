    <?php
    // Start output buffering to catch any accidental output
    ob_start();

    // Set error reporting for development
    ini_set('display_errors', 0);
    error_reporting(0);

    ?>
    <link rel="stylesheet" href="css/button.css">
    <hr>
    <!-- Signatory Modal -->
    <div class="modal fade" id="signatoryModal" tabindex="-1" role="dialog" aria-labelledby="signatoryModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="signatoryModalLabel">Add Signatory Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    <form id="signatoryForm">
                        <div class="form-group mb-3">
                            <label for="signatoryType" class="form-label">Signatory Type</label>
                            <select class="form-select" id="signatoryType" required>
                                <option value="certified">Certified True and Correct</option>
                                <option value="checked">Checked</option>
                                <option value="noted">Noted</option>
                                <option value="received">Received By</option>
                            </select>
                        </div>
                        <div class="form-group mb-3">
                            <label for="fullName" class="form-label">Full Name, W/ Title</label>
                            <input type="text" class="form-control" placeholder="Leave Blank if not needed!!!" id="fullName" style="text-transform: uppercase;" oninput="this.value = this.value.toUpperCase()">
                        </div>
                        <div class="form-group">
                            <label for="designation" class="form-label">Designation</label>
                            <select class="form-select" id="designation" required>
                                <option value="" disabled selected>Select Designation</option>
                                <option value="College Dean">College Dean</option>
                                <option value="Program Head">Program Head</option>
                                <option value="Registrar III">Registrar III</option>
                                <option value="Lecturer">Lecturer</option>
                                <option value="Instructor I">Instructor I</option>
                                <option value="Instructor II">Instructor II</option>
                                <option value="Instructor III">Instructor III</option>
                                <option value="Professor I">Professor I</option>
                                <option value="Professor II">Professor II</option>
                                <option value="Professor III">Professor III</option>
                                <option value="Professor IV">Professor IV</option>
                                <option value="Professor V">Professor V</option>
                            </select>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveSignatory">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-3">
        <div class="card-body p-3">
            <?php $class = isset($class) && is_array($class) ? $class : []; ?>
            <form action="" id="marks-form" class="mb-0">
                <div class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label for="quarter" class="form-label small text-muted mb-1">Quarter</label>
                        <select name="quarter" id="quarter" class="form-select form-select-sm" required>
                            <?php
                            // =================================================================
                            // Quarter dropdown - populated DYNAMICALLY via AJAX
                            // (get_quarter_options.php) whenever the active section/class
                            // changes. Quarters are CUSTOM MADE per class and live in
                            // `quarter_list` - no hardcoded term names are used:
                            //   * Class in URL -> that class's own quarter_list rows.
                            //   * No class yet -> neutral list of the quarter numbers that
                            //     exist across quarter_list (majority name when classes
                            //     agree, otherwise 'Quarter N'), refined via AJAX once a
                            //     class is picked.
                            // =================================================================
                            $report_rq_ini = [];
                            $report_rq_url_class = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;

                            if ($report_rq_url_class > 0 && isset($conn)) {
                                // Custom quarters belonging to the viewed class only.
                                $report_rq_qry = $conn->query("SELECT quarter, name FROM quarter_list WHERE class_id = '{$report_rq_url_class}' ORDER BY quarter ASC");
                                if ($report_rq_qry) {
                                    while ($report_rq_row = $report_rq_qry->fetchArray(SQLITE3_ASSOC)) {
                                        $report_rq_n  = (int)$report_rq_row['quarter'];
                                        $report_rq_nm = trim((string)$report_rq_row['name']);
                                        if ($report_rq_nm !== '') {
                                            $report_rq_ini[$report_rq_n] = $report_rq_nm;
                                        }
                                    }
                                }
                            } elseif (isset($conn)) {
                                // No class chosen yet - neutral global quarter list.
                                $report_rq_counts = [];
                                $report_rq_all = $conn->query("SELECT quarter, name FROM quarter_list");
                                if ($report_rq_all) {
                                    while ($report_rq_row = $report_rq_all->fetchArray(SQLITE3_ASSOC)) {
                                        $report_rq_n  = (int)$report_rq_row['quarter'];
                                        $report_rq_nm = trim((string)$report_rq_row['name']);
                                        if ($report_rq_nm === '') {
                                            continue;
                                        }
                                        $report_rq_counts[$report_rq_n][$report_rq_nm] = ($report_rq_counts[$report_rq_n][$report_rq_nm] ?? 0) + 1;
                                    }
                                }
                                foreach ($report_rq_counts as $report_rq_n => $report_rq_names) {
                                    arsort($report_rq_names);
                                    $report_rq_top = array_key_first($report_rq_names);
                                    $report_rq_ini[$report_rq_n] = (count($report_rq_names) === 1) ? $report_rq_top : ('Quarter ' . $report_rq_n);
                                }
                            }
                            ksort($report_rq_ini, SORT_NUMERIC);
                            $report_rq_current = isset($_GET['quarter']) ? $_GET['quarter'] : '';
                            ?>
                            <option value="" disabled <?php echo ($report_rq_current === '') ? 'selected' : '' ?>>Select Quarter</option>
                            <?php foreach ($report_rq_ini as $report_rq_num => $report_rq_name): $report_rq_num = (int)$report_rq_num; ?>
                            <option style="font-weight:bold;" value="<?php echo $report_rq_num ?>" <?php echo ($report_rq_current == $report_rq_num) ? 'selected' : '' ?>>
                                <?php echo htmlspecialchars($report_rq_name) ?>
                            </option>
                            <?php endforeach; ?>
                            <option style="font-weight:bold;" value="active" <?php echo ($report_rq_current === 'active') ? 'selected' : '' ?>> Active Quarters</option>
                        </select>
                        <script>

                            window.reportQuarterNamesCache = {};

                            window.renderReportQuarterSelect = function (names, currentVal) {
                                var $sel = $('#quarter');
                                if (!$sel.length) return;
                                var current = (typeof currentVal === 'string') ? currentVal : String($sel.val() || '');
                                var nums = Object.keys(names).map(Number).sort(function (a, b) { return a - b; });

                                var html = '<option value="" disabled' + (current === '' ? ' selected' : '') + '>Select Quarter</option>';
                                for (var i = 0; i < nums.length; i++) {
                                    var q = nums[i];
                                    var label = String(names[q]).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                                    html += '<option style="font-weight:bold;" value="' + q + '"' + (String(q) === current ? ' selected' : '') + '>' + label + '</option>';
                                }
                                html += '<option style="font-weight:bold;" value="active"' + (current === 'active' ? ' selected' : '') + '> Active Quarters</option>';
                                $sel.html(html);
                            };

                            // Fetches the custom quarters of the selected class and re-renders
                            // the dropdown. With no class yet the server-rendered list stays;
                            // on request failure the current options are left untouched.
                            window.applyReportQuarterOptions = function (cid) {
                                var $sel = $('#quarter');
                                if (!$sel.length) return;
                                var classKey = String(cid || '').trim();
                                if (classKey === '') {
                                    return; // keep the server-rendered neutral/custom list
                                }

                                if (window.reportQuarterNamesCache[classKey]) {
                                    window.renderReportQuarterSelect(window.reportQuarterNamesCache[classKey]);
                                    return;
                                }

                                $.ajax({
                                    url: 'get_quarter_options.php',
                                    data: { class_id: classKey },
                                    dataType: 'json',
                                    cache: false,
                                    success: function (res) {
                                        if (res && res.status === 'success' && Array.isArray(res.options) && res.options.length) {
                                            var names = {};
                                            for (var i = 0; i < res.options.length; i++) {
                                                names[String(res.options[i].value)] = String(res.options[i].name);
                                            }
                                            window.reportQuarterNamesCache[classKey] = names;
                                            window.renderReportQuarterSelect(names);
                                            // Remember this class so a later landing WITHOUT a
                                            // class in the URL can still label the dropdown with
                                            // its custom (possibly just-renamed) quarter names.
                                            try { localStorage.setItem('rq_last_class_id', classKey); } catch (e) {}
                                        }
                                        // Non-success responses leave the dropdown as-is.
                                    },
                                    error: function () {
                                        // Network/server failure - keep current options.
                                    }
                                });
                            };
                        </script>
                    </div>
                    <div class="col-md-9 d-flex gap-2 justify-content-md-end">
                        <button type="button" id="filter" style="font-weight:bold;" class="btn btn-sm btn-primary d-flex align-items-center gap-1">
                            <i class="fas fa-filter"></i>
                            <span>Load Reports</span>
                        </button>
                    <button type="button" id="print" style="font-weight:bold;" class="btn btn-sm btn-success d-flex align-items-center gap-1">
                            <i class="fas fa-print"></i>
                            <span>Print</span>
                        </button>
                    <button type="button" id="exportWord" style="font-weight:bold;" class="btn btn-sm btn-warning d-flex align-items-center gap-1">
                            <i class="fas fa-file-word"></i>
                            <span>Export to Word</span>
                        </button>
                        <button type="button" id="addSignatory" style="font-weight:bold;" class="btn btn-sm btn-info d-flex align-items-center gap-1">
                            <i class="fas fa-signature"></i>
                            <span>Add Signatory</span>
                        </button>
                    </div>
                </div>
                <?php
                $class_assessment_quarters = [];
                $assessment_quarter_qry = $conn->query("SELECT class_id, quarter FROM `assessment_list` GROUP BY class_id, quarter ORDER BY class_id ASC, quarter ASC");
                if ($assessment_quarter_qry) {
                    while($assessment_quarter_row = $assessment_quarter_qry->fetchArray(SQLITE3_ASSOC)) {
                        $assessment_class_id = (int)$assessment_quarter_row['class_id'];
                        if (!isset($class_assessment_quarters[$assessment_class_id])) {
                            $class_assessment_quarters[$assessment_class_id] = [];
                        }
                        $class_assessment_quarters[$assessment_class_id][] = (string)$assessment_quarter_row['quarter'];
                    }
                }

                $subject_tabs = [];
                $class_qry = $conn->query("SELECT c.*, (s.name || ' ' || c.grade || ' - ' || c.section) as class,s.name as sname,(c.grade || ' - ' || c.section) as grade_sec FROM `class_list` c inner join `subjects` s on c.subject_id = s.subject_id order by s.name asc, c.grade asc, c.section asc");
                while($row= $class_qry->fetchArray()):
                    $class_id_value = (int)$row['class_id'];
                    $subject_id_value = (int)$row['subject_id'];
                    $available_quarters = $class_assessment_quarters[$class_id_value] ?? [];
                    $row['available_quarters'] = $available_quarters;
                    $class[$class_id_value] = $row;

                    if (!isset($subject_tabs[$subject_id_value])) {
                        $subject_tabs[$subject_id_value] = [
                            'subject_id' => $subject_id_value,
                            'subject_name' => $row['sname'],
                            'available_quarters' => [],
                            'sections' => []
                        ];
                    }

                    $subject_tabs[$subject_id_value]['available_quarters'] = array_values(array_unique(array_merge($subject_tabs[$subject_id_value]['available_quarters'], $available_quarters)));
                    $subject_tabs[$subject_id_value]['sections'][] = [
                        'class_id' => $class_id_value,
                        'grade_sec' => $row['grade_sec'],
                        'available_quarters' => $available_quarters
                    ];
                endwhile;

                $selected_class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : 0;
                $selected_subject_id = ($selected_class_id > 0 && isset($class[$selected_class_id])) ? (int)$class[$selected_class_id]['subject_id'] : 0;
                ?>
                <input type="hidden" name="class_id" id="class_id" value="<?php echo $selected_class_id ?: '' ?>">
                <input type="hidden" name="subject_id" id="subject_id" value="<?php echo $selected_subject_id ?: '' ?>">
                <div class="row g-2 mt-2">
                    <div class="col-12 d-none" id="subjectTabsWrapper">
                        <label class="form-label small text-muted mb-1 d-block">Subject</label>
                        <div id="subjectTabs" class="nav nav-tabs border-bottom-0 report-class-tabs">
                            <?php foreach($subject_tabs as $subject_row): ?>
                                <button
                                    type="button"
                                    class="nav-link report-class-tab report-subject-tab <?php echo ($selected_subject_id === (int)$subject_row['subject_id']) ? 'active' : '' ?>"
                                    data-subject-id="<?php echo $subject_row['subject_id'] ?>"
                                    data-quarters='<?php echo htmlspecialchars(json_encode($subject_row['available_quarters'] ?? []), ENT_QUOTES, 'UTF-8') ?>'
                                >
                                    <?php echo htmlspecialchars($subject_row['subject_name']) ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                        <div id="subjectTabsEmptyState" class="alert alert-light border text-muted small py-2 px-3 mt-2 d-none mb-0">
                            No subjects available for the selected quarter.
                        </div>
                    </div>
                    <div class="col-12 d-none" id="sectionTabsWrapper">
                        <label class="form-label small text-muted mb-1 d-block">Section</label>
                        <div id="sectionTabs" class="nav nav-tabs border-bottom-0 report-class-tabs">
                            <?php foreach($subject_tabs as $subject_row): ?>
                                <?php foreach($subject_row['sections'] as $section_row): ?>
                                    <button
                                        type="button"
                                        class="nav-link report-class-tab report-section-tab <?php echo ($selected_class_id === (int)$section_row['class_id']) ? 'active' : '' ?>"
                                        data-subject-id="<?php echo $subject_row['subject_id'] ?>"
                                        data-class-id="<?php echo $section_row['class_id'] ?>"
                                        data-quarters='<?php echo htmlspecialchars(json_encode($section_row['available_quarters'] ?? []), ENT_QUOTES, 'UTF-8') ?>'
                                    >
                                        <?php echo htmlspecialchars($section_row['grade_sec']) ?>
                                    </button>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </div>
                        <div id="sectionTabsEmptyState" class="alert alert-light border text-muted small py-2 px-3 mt-2 d-none mb-0">
                            No sections available for the selected subject and quarter.
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
        <hr>
        <?php
        // Render report only when both class_id and quarter are provided and valid
        if(isset($_GET['class_id']) && isset($_GET['quarter']) && (int)$_GET['class_id'] > 0 && ((int)$_GET['quarter'] > 0 || $_GET['quarter'] == 'active')):
            // Quarters are CUSTOM MADE per class (quarter_list). Labels are resolved
            // through $class_quarter_names below; unknown quarter numbers fall
            // back to a neutral 'Quarter N'.
            $class_id = (int)$_GET['class_id'];
            $is_active_quarters = $_GET['quarter'] == 'active';
            $current_quarter = $is_active_quarters ? 0 : (int)$_GET['quarter'];

            // Custom quarter names defined for this class (single source of truth).
            $class_quarter_names = [];
            $class_qname_qry = $conn->query("SELECT quarter, name FROM quarter_list WHERE class_id = '" . $class_id . "' ORDER BY quarter ASC");
            if ($class_qname_qry) {
                while ($class_qname_row = $class_qname_qry->fetchArray(SQLITE3_ASSOC)) {
                    $class_quarter_names[(int)$class_qname_row['quarter']] = $class_qname_row['name'];
                }
            }

            // Helper closure to safely resolve a quarter label for any quarter index.
            $resolve_quarter_name = function($q_index) use ($class_quarter_names) {
                $q_index = (int)$q_index;
                if ($q_index > 0) {
                    if (isset($class_quarter_names[$q_index]) && trim((string)$class_quarter_names[$q_index]) !== '') {
                        return $class_quarter_names[$q_index];
                    }
                    return 'Quarter ' . $q_index;
                }
                return '';
            };

            // Fetch class information
            $stmt = $conn->prepare("
                SELECT
                    c.*,
                    s.name as subject_name
                FROM
                    class_list c
                JOIN
                    subjects s ON c.subject_id = s.subject_id
                WHERE
                    c.class_id = :class_id
            ");
            $stmt->bindValue(':class_id', $class_id, SQLITE3_INTEGER);
            $result = $stmt->execute();
            $class_info = $result->fetchArray(SQLITE3_ASSOC);

            if (!$class_info) {
                echo "<div class='alert alert-danger'>Class not found.</div>";
                exit;
            }
        ?>

                <!-- Search Box and Filters -->
                    <div class="row mb-3 no-print">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" id="studentSearch" class="form-control" placeholder="Search by Student Name or Transmuted Grade...">
                            </div>
                        </div>
                        <div class="col-md-4 d-flex align-items-center">
                            <button type="button" id="filterGradesAbove3" class="btn btn-outline-warning w-100 d-flex align-items-center justify-content-center gap-1" style="font-weight:bold;" title="Show students with Initial Grade below 75">
                                <i class="fas fa-exclamation-triangle"></i>
                                <span>Show Failed Students</span>
                            </button>
                        </div>
                        <div class="col-md-4 d-flex align-items-center gap-2">
                            <button type="button" id="rqFastEntryToggle" class="toggle-enter-btn btn-sm" aria-pressed="false" title="Pick a component + assessment header, then Tab/Enter in Search jumps to that cell">
                                <span class="toggle-enter-label">Fast Single Entry</span>
                                <span class="toggle-enter-switch">
                                    <span class="toggle-enter-knob"></span>
                                    <span class="toggle-enter-text"></span>
                                </span>
                            </button>
                            <small id="rqFastHint" class="text-muted">Fast entry off</small>
                        </div>
                    </div>
                    <div class="col-12" id="outprint">
                               <div class="row" >
                                   <div class="col-md-12 py-3 w-100 ">
                                       <?php
                                       $components = array();
                                       $components_query = $conn->query("SELECT c.*,g.name FROM `component_subject_percentage` c inner join `grading_components` g on c.component_id = g.component_id where c.subject_id = '" . $conn->escapeString($class[$_GET['class_id']]['subject_id']) . "' AND CAST(c.percentage AS REAL) > 0 order by component_id asc ");
                                       if ($components_query) {
                                           while($row = $components_query->fetchArray(SQLITE3_ASSOC)){
                                               $components[$row['component_id']] = $row;
                                           }
                                       }
                                       $assess = array();
                                       $assess_ids = array();
                                       $active_quarters = array();

                                       // Query to find active quarters (quarters with assessments)
                                       if ($is_active_quarters) {
                                           $active_quarters_query = $conn->query("SELECT DISTINCT quarter FROM `assessment_list` where class_id = '" . $conn->escapeString($_GET['class_id']) . "' ORDER BY quarter");
                                           if ($active_quarters_query) {
                                               while($row = $active_quarters_query->fetchArray(SQLITE3_ASSOC)){
                                                   $active_quarters[] = $row['quarter'];
                                               }
                                           }
                                           $assess_query = $conn->query("SELECT * FROM `assessment_list` where class_id = '" . $conn->escapeString($_GET['class_id']) . "' AND quarter IN (" . implode(',', $active_quarters) . ") order by quarter, `name` asc ");
                                       } else {
                                           $assess_query = $conn->query("SELECT * FROM `assessment_list` where class_id = '" . $conn->escapeString($_GET['class_id']) . "' and quarter = '" . $conn->escapeString($_GET['quarter']) . "' order by `name` asc ");
                                       }
                                       $component_totals = array(); // To store total percentage for each component

                                       // First pass: Store assessments and calculate total percentage per component
                                       if ($assess_query) {
                                           while($row = $assess_query->fetchArray(SQLITE3_ASSOC)){
                                               if ($is_active_quarters) {
                                                   // Organize by component -> quarter -> assessment for active quarters view
                                                   $assess[$row['component_id']][$row['quarter']][$row['assessment_id']] = $row;
                                               } else {
                                                   // Original structure for single quarter view
                                                   $assess[$row['component_id']][$row['assessment_id']] = $row;
                                               }
                                               $assess_ids[] = $row['assessment_id'];
                                               // Initialize component total if not set
                                               if (!isset($component_totals[$row['component_id']])) {
                                                   $component_totals[$row['component_id']] = 0;
                                               }
                                               // Add to component total (ensure percentage is treated as a number)
                                               $component_totals[$row['component_id']] += floatval($row['percentage']);
                                           }
                                       }

                                       // Second pass: Calculate weight for each assessment
                                       foreach ($assess as $component_id => $assessments) {
                                           $component_total = $component_totals[$component_id] > 0 ? $component_totals[$component_id] : 100; // Avoid division by zero
                                           if ($is_active_quarters) {
                                               // Handle active quarters structure: component -> quarter -> assessment
                                               foreach ($assessments as $quarter_num => $quarter_assessments) {
                                                   foreach ($quarter_assessments as $assessment_id => $assessment) {
                                                       // Calculate weight as a percentage of the component's total percentage
                                                       $weight = ($assessment['percentage'] / $component_total) * 100;
                                                       $assess[$component_id][$quarter_num][$assessment_id]['weight'] = $weight;
                                                   }
                                               }
                                           } else {
                                               // Handle single quarter structure: component -> assessment
                                               foreach ($assessments as $assessment_id => $assessment) {
                                                   // Calculate weight as a percentage of the component's total percentage
                                                   $weight = ($assessment['percentage'] / $component_total) * 100;
                                                   $assess[$component_id][$assessment_id]['weight'] = $weight;
                                               }
                                           }
                                       }
                                       // Safeguard: if there are no assessments, use a harmless IN list to avoid SQL error
                                       $a_ids = !empty($assess_ids) ? implode(",", array_map('intval', $assess_ids)) : '0';
                                       $marks = array();
                                       $students = array();
                                       $marks_qry = $conn->query("SELECT * FROM `mark_list` WHERE assessment_id IN ({$a_ids}) ");
                                       if ($marks_qry) {
                                           while($row = $marks_qry->fetchArray(SQLITE3_ASSOC)){
                                               $marks[$row['student_id']][$row['assessment_id']] = $row['mark'];
                                           }
                                       }
                                       $student_query = $conn->query("SELECT * FROM student_list WHERE class_id = '" . $conn->escapeString($_GET['class_id']) . "' ORDER BY TRIM(name) COLLATE NOCASE");
                                       $students = array();
                                       $student_status = array();
                                       $student_status_details = array(); // Store detailed status info for active quarters

                                       if ($student_query) {
                                           while($row = $student_query->fetchArray(SQLITE3_ASSOC)){
                                               $students[$row['student_id']] = $row['name'];

                                               // Store detailed status information
                                               $student_status_details[$row['student_id']] = [
                                                   'status' => $row['status'] ?? 'Active',
                                                   'status_quarter' => $row['status_quarter']
                                               ];

                                           if ($is_active_quarters) {
                                               // For active quarters, show status as-is since we need to display quarter-specific info
                                               $student_status[$row['student_id']] = $row['status'] ?? 'Active';
                                           } else {
                                               $current_quarter = isset($_GET['quarter']) ? (int)$_GET['quarter'] : 1;
                                               // For NoSub and NoExam statuses, only show if they apply to the current quarter
                                               if (($row['status'] === 'NoSub' || $row['status'] === 'NoExam') && $row['status_quarter'] != null) {
                                                   if ($row['status_quarter'] == $current_quarter) {
                                                       $student_status[$row['student_id']] = $row['status'];
                                                   } else {
                                                       $student_status[$row['student_id']] = 'Active'; // Show as Active for other quarters
                                                   }
                                               } else {
                                                   // For Active and Dropped, show as-is (they apply to all quarters)
                                                   $student_status[$row['student_id']] = $row['status'] ?? 'Active';
                                               }
                                           }
                                       }
                                       }
                                       $c_perc_arr = array();
                                       foreach($components as $row){
                                           $c_perc_arr[$row['component_id']] =( $row['percentage']/100);
                                       }
                                         $__trans_system = function_exists('get_active_transmutation_system') ? get_active_transmutation_system($conn) : 'CHED';
                                         $depEdReport = ($__trans_system === 'DEPED');
                                         $transmutaion_query = $conn->query("SELECT * FROM transmutation_table WHERE `system` = '{$__trans_system}' ORDER BY `from` ASC");
                                       $trans_tbl = array();
                                       while($row = $transmutaion_query->fetchArray(SQLITE3_ASSOC)){
                                           $trans_tbl[] = [
                                               'grade' => (float)$row['grade'],
                                               'from' => (float)$row['from'],
                                               'to' => (float)$row['to']
                                           ];
                                       }
                                       function transmute($grade = 0){
                                           global $trans_tbl;
                                           $transmuted = 0;
                                           foreach($trans_tbl as $row){
                                               if($row['from'] <= $grade && $grade <= $row['to']){
                                                   $transmuted = $row['grade'];
                                                   break;
                                               }
                                           }
                                           return $transmuted;
                                       }
                                       // Convert transmuted grade (60-100) to 1.0–5.0 equivalent
                                       function get_equivalent_from_transmutation($grade) {
                                           global $trans_tbl;

                                           $grade = round(floatval($grade), 2);
                                           $equivalent = 5.5; // Default numeric value if no range matches

                                           foreach ($trans_tbl as $row) {
                                               if ($grade >= $row['from'] && $grade <= $row['to']) {
                                                   $equivalent = (float)$row['grade'];
                                                   break;
                                               }
                                           }

                                            // DepEd transmuted grades (60-100 scale) pass through untouched.
                                            if ($equivalent > 5.5) {
                                                return number_format($equivalent, 1);
                                            }

                                            // If equivalent is above 5.0, treat as DROPPED
                                            if ($equivalent > 5.0 && $equivalent != 5.5) {
                                               return '5.0';
                                           } elseif ($equivalent === 5.5) {
                                               return 'DR';
                                           }

                                           return number_format($equivalent, 1);
                                       }

                                       function transmuted_to_equivalent($from, $to = null) {
                                           // Handle both old and new function signatures
                                           if ($to === null) {
                                               $g = floatval($from);
                                               if ($g <= 60) return number_format(5.0, 1);
                                               if ($g == 100) return number_format(1.0, 1);
                                               $equiv = 5.0 - (($g - 60.0) / 35.0) * 4.0; // maps 60->5.0 down to 95->1.0
                                               if ($equiv < 1.0) $equiv = 1.0;
                                               if ($equiv > 5.0) $equiv = 5.0;
                                               return number_format($equiv, 1);
                                           } else {
                                               // New implementation using from and to
                                               $from = floatval($from);
                                               $to = floatval($to);
                                               $midpoint = ($from + $to) / 2;

                                               // Handle edge cases
                                               if ($midpoint <= 50) return 5.0;
                                               if ($midpoint == 100) return 1.0;

                                               // Calculate equivalent based on the range
                                               if ($midpoint <= 75) {
                                                   // Linear interpolation between 50 (5.5) and 75 (3.0)
                                                   $equiv = 5.0 - (($midpoint - 50) / (75 - 50)) * 2.5;
                                               } else {
                                                   // Linear interpolation between 75 (3.0) and 100 (1.0)
                                                   $equiv = 3.0 - (($midpoint - 75) / (100 - 75)) * 2.0;
                                               }

                                               // Ensure the equivalent is within bounds
                                               return max(1.0, min(5.0, $equiv));
                                           }
                                       }
                                       ?>
                                       <?php if(empty($components)): ?>
                                           <div class="alert alert-warning rounded-0 py-2">No component percentages configured for this subject. Please configure them in the Percentages section.</div>
                                       <?php else: ?>


                                       <div class="table-responsive freeze-panes-container" style="max-height: 80vh; ">

                                            <?php if ($is_active_quarters): ?>
                                            <!-- Active Quarters Table Structure -->
                                            <table class="table table-hover table-bordered b-100 rq-grades" id="gradesTable" style="min-width: 1200px; max-width: 100%; page-break-after: avoid;">
                                                <thead class="sticky-top table-header rq-thead">
                                                    <tr class="rq-row-main">
                                                        <th class="py-2 px-2 text-center align-middle sticky-col rq-h-main rq-h-student" rowspan="4" style="min-width: 175px; max-width: 250px; position: sticky; left: 0; z-index: 10;">Student</th>
                                                       <?php
                                                       $total_colspan = 0;
                                                       foreach($components as $component_id => $component):
                                                           $component_colspan = 0;
                                                           foreach($active_quarters as $q_num):
                                                               if(isset($assess[$component_id][$q_num])):
                                                                   $component_colspan += count($assess[$component_id][$q_num]) + 2; // assessments + Total + Avg + %
                                                               else:
                                                                   $component_colspan += 2; // No assessments placeholder
                                                               endif;
                                                           endforeach;
                                                           $total_colspan += $component_colspan;
                                                       ?>
                                                         <th class="py-2 px-2 text-center rq-h-main rq-h-component" data-component-id="<?php echo $component_id ?>" colspan="<?php echo $component_colspan ?>">
                                                            <div class="d-flex flex-column align-items-center gap-1">
                                                                <span class="rq-comp-name"><?php echo htmlspecialchars($component['name']); ?></span>
                                                                <small class="rq-comp-pct"><?php echo $component['percentage'] ?>%</small>
                                                            </div>
                                                        </th>
                                                        <?php endforeach; ?>

                                                        <!-- Transmuted Grade Headers for Each Quarter -->
                                                        <?php foreach($active_quarters as $q_num): ?>
                                                        <th class="py-2 px-2 text-center align-middle rq-h-main rq-h-grade" rowspan="4" width="40px"><?php echo htmlspecialchars($resolve_quarter_name($q_num)) ?><span class="rq-h-sub">Grade</span></th>
                                                        <?php endforeach; ?>

                                                        <th class="py-2 px-2 text-center align-middle rq-h-main rq-h-grade rq-h-initial" rowspan="4" width="40px">Initial<span class="rq-h-sub">Grade</span></th>
                                                        <th class="py-2 px-2 text-center align-middle rq-h-main rq-h-grade rq-h-avg" rowspan="4" width="40px">AVG<span class="rq-h-sub">Grade</span></th>
                                                   </tr>
                                                    <tr class="rq-row-quarter">
                                                        <?php
                                                        foreach($components as $component_id => $component):
                                                            foreach($active_quarters as $q_num):
                                                                $quarter_name = $resolve_quarter_name($q_num);
                                                                if(isset($assess[$component_id][$q_num])):
                                                                    $assessment_count = count($assess[$component_id][$q_num]);
                                                                ?>
                                                                <th class="py-1 px-2 text-center rq-h-quarter" colspan="<?php echo $assessment_count + 2 ?>">
                                                                    <?php echo htmlspecialchars($quarter_name) ?>
                                                                </th>
                                                                <?php else: ?>
                                                                <th class="py-1 px-2 text-center rq-h-quarter rq-h-empty" colspan="2">
                                                                    <?php echo htmlspecialchars($quarter_name) ?>
                                                                </th>
                                                                <?php endif; ?>
                                                            <?php endforeach; ?>
                                                        <?php endforeach; ?>
                                                    </tr>
                                                    <tr class="rq-row-assess">
                                                        <?php
                                                        foreach($components as $component_id => $component):
                                                            foreach($active_quarters as $q_num):
                                                                if(isset($assess[$component_id][$q_num])):
                                                                    foreach($assess[$component_id][$q_num] as $assessment):
                                                                ?>
                                                                 <th class="py-1 px-2 text-center rq-h-assess" data-component-id="<?php echo $component_id ?>" data-quarter="<?php echo $q_num ?>" data-assessment-id="<?php echo $assessment['assessment_id']; ?>" title="<?php echo htmlspecialchars($assessment['name']) ?>">
                                                                    <div class="text-truncate rq-assess-name"><?php echo htmlspecialchars($assessment['name']) ?></div>
                                                                </th>
                                                                <?php
                                                                    endforeach;
                                                                ?>
                                                                <th class="py-1 px-2 text-center rq-h-total" title="Total score">T</th>

                                                                <th class="py-1 px-2 text-center rq-h-pct" title="Weighted percentage">%</th>
                                                                <?php else: ?>
                                                                <th class="py-1 px-2 text-center rq-h-none" colspan="2">
                                                                    <small>No assessments</small>
                                                                </th>
                                                                <?php endif; ?>
                                                            <?php endforeach; ?>
                                                        <?php endforeach; ?>
                                                    </tr>
                                                    <tr class="rq-row-hps">
                                                        <?php
                                                        foreach($components as $component_id => $component):
                                                            $percentage = $component['percentage'];
                                                            foreach($active_quarters as $q_num):
                                                                if(isset($assess[$component_id][$q_num])):
                                                                    $quarter_total_hps = 0;
                                                                    foreach($assess[$component_id][$q_num] as $assessment):
                                                                        $quarter_total_hps += $assessment['hps'];
                                                        ?>
                                                                <th class="py-1 px-2 text-center rq-h-hps">/<?php echo $assessment['hps'] ?></th>
                                                        <?php
                                                                    endforeach;
                                                        ?>
                                                                <th class="py-1 px-2 text-center rq-h-total-val"><?php echo $quarter_total_hps ?></th>
                                                                <th class="py-1 px-2 text-center rq-h-pct-val"><?php echo $percentage ?>%</th>
                                                        <?php else: ?>
                                                                <th class="py-1 px-2 text-center rq-h-none" colspan="2">-</th>
                                                       <?php
                                                               endif;
                                                           endforeach;
                                                       endforeach;
                                                       ?>
                                                   </tr>
                                               </thead>
                                           <?php else: ?>
                                            <!-- Original Single Quarter Table Structure -->
                                            <table class="table table-hover table-bordered w-100 rq-grades" id="gradesTable" style="min-width: 800px; max-width: 100%; page-break-after: avoid;">
                                                <thead class="sticky-top table-header rq-thead">
                                                    <tr class="rq-row-main">
                                                        <th class="py-2 px-2 text-center align-middle sticky-col rq-h-main rq-h-student" rowspan="3" style="min-width: 200px; max-width: 250px; position: sticky; left: 0; z-index: 10;">Student</th>
                                                        <?php
                                                        foreach($components as $row):
                                                            $colspan = isset($assess[$row['component_id']]) ? count($assess[$row['component_id']]) + 2 : 3;
                                                        ?>
                                                         <th class="py-2 px-2 text-center rq-h-main rq-h-component" data-component-id="<?php echo $row['component_id'] ?>" colspan="<?php echo $colspan ?>">
                                                            <div class="d-flex flex-column align-items-center gap-1">
                                                                <span class="rq-comp-name"><?php echo htmlspecialchars($row['name']); ?></span>
                                                                <small class="rq-comp-pct"><?php echo $row['percentage'] ?>%</small>
                                                            </div>
                                                        </th>

                                                        <?php endforeach; ?>
                                                        <th class="py-2 px-2 text-center align-middle initial-grade-header rq-h-main rq-h-grade rq-h-initial" rowspan="3" width="40px">Initial<span class="rq-h-sub">Grade</span></th>
                                                        <th class="py-2 px-2 text-center align-middle quarter-grade-header rq-h-main rq-h-grade" rowspan="3" width="40px"><?php echo htmlspecialchars($resolve_quarter_name($_GET['quarter'])); ?><span class="rq-h-sub">Grade</span></th>
                                                    </tr>
                                                    <tr class="rq-row-assess">
                                                        <?php
                                                        foreach($components as $k => $v):
                                                            if(isset($assess[$k])):
                                                                foreach($assess[$k] as $row):
                                                        ?>
                                                        <th class="py-1 px-2 text-center rq-h-assess" data-component-id="<?php echo $k; ?>" data-assessment-id="<?php echo $row['assessment_id']; ?>" style="min-width: 10px;" title="<?php echo htmlspecialchars($row['name']) ?>">
                                                            <div class="text-truncate rq-assess-name"><?php echo htmlspecialchars($row['name']) ?></div>
                                                        </th>

                                                        <?php
                                                                endforeach;
                                                        ?>
                                                        <th class="py-1 px-2 text-center rq-h-total" style="min-width: 10px;" title="Total score">T</th>
                                                        <th class="py-1 px-2 text-center rq-h-pct" style="min-width: 20px;" title="Weighted percentage">%</th>
                                                        <?php
                                                            else:
                                                        ?>

                                                        <th class="py-1 px-2 text-center rq-h-none" colspan="3">
                                                            <small>No assessments</small>
                                                        </th>
                                                        <?php
                                                            endif;
                                                        endforeach;
                                                        ?>
                                                    </tr>
                                                    <tr class="rq-row-hps">
                                                        <?php
                                                        $total_hps_arr = array();
                                                        foreach($components as $k => $v):
                                                            $total_hps = 0;
                                                            $percentage = $v['percentage'];
                                                            if(isset($assess[$k])):
                                                                foreach($assess[$k] as $row):
                                                                    $total_hps += $row['hps'];
                                                        ?>
                                                        <th class="py-1 px-2 text-center rq-h-hps">/<?php echo $row['hps'] ?></th>
                                                        <?php
                                                                endforeach;
                                                        ?>
                                                        <th class="py-1 px-2 text-center fw-bold rq-h-total-val"><?php echo $total_hps_arr[$k] = $total_hps ?></th>
                                                        <th class="py-1 px-2 text-center rq-h-pct-val"><?php echo $percentage ?>%</th>
                                                        <?php
                                                            else:
                                                        ?>
                                                        <th class="py-1 px-2 text-center rq-h-none" colspan="3">-</th>
                                                       <?php
                                                           endif;
                                                       endforeach;
                                                       ?>
                                                   </tr>
                                               </thead>
                                               <?php endif; ?>
                                               <tbody>
                                               <?php ob_start(); ?>
                                               <?php
                                               // Show a full-width row when no students are found
                                               if(empty($students)){
                                                   if ($is_active_quarters) {
                                                       $col_count = 1; // Student column
                                                       foreach($components as $component_id => $component){
                                                           foreach($active_quarters as $q_num){
                                                               $col_count += isset($assess[$component_id][$q_num]) ? count($assess[$component_id][$q_num]) + 3 : 3;
                                                           }
                                                       }
                                                       $col_count += count($active_quarters) + 2; // Quarter Grades + Initial Grade + AVG Grade
                                                   } else {
                                                       $col_count = 1; // Student column
                                                       foreach($components as $k => $v){
                                                           $col_count += isset($assess[$k]) ? count($assess[$k]) + 2 : 3; // assessments + Total + % OR 3 when none
                                                       }
                                                       $col_count += 2; // Initial Grade + Quarterly Grade
                                                   }
                                               ?>
                                                   <tr>
                                                       <td class="text-center" colspan="<?php echo $col_count; ?>" style="border: 1px solid #adb5bd;">No students found for this class.</td>
                                                   </tr>
                                               <?php
                                               }
                                               foreach($students as $k =>$v):
                                                   if ($is_active_quarters) {
                                                       // Active quarters calculations
                                                       $final_grade = 0;
                                                       $total_weighted_score = 0;
                                                       $total_percentage = 0;
                                                   } else {
                                                       // Single quarter calculations
                                                       $initial = 0;
                                                   }
                                               ?>
                                                   <?php
                                               $row_class = '';
                                               $border_color = '#dee2e6';
                                                if(isset($student_status[$k])) {
                                                    if($student_status[$k] === 'Dropped') {
                                                        $row_class = ' status-dropped';
                                                        $border_color = '#b91c1c';
                                                    } elseif($student_status[$k] === 'NoSub') {
                                                        $row_class = ' status-nosub';
                                                        $border_color = '#b45309';
                                                    } elseif($student_status[$k] === 'NoExam') {
                                                        $row_class = ' status-noexam';
                                                        $border_color = '#0369a1';
                                                    }
                                                }
                                               ?>
                                                    <tr data-student-id="<?php echo $k; ?>" data-student-status="<?php echo isset($student_status[$k]) ? htmlspecialchars($student_status[$k]) : 'Active'; ?>" class="rq-row <?php echo $row_class; ?>">
                                                        <td class="py-0 px-1 sticky-col rq-student" style="position: sticky; left: 0; z-index: 5; border-right: 2px solid <?php echo $border_color; ?>;">
                                                            <span class="rq-student-name"><?php echo $v ?></span>
                                                            <?php if(isset($student_status[$k]) && $student_status[$k] === 'Dropped'): ?>
                                                                <span class="badge rq-badge rq-badge-dropped">Dropped</span>
                                                            <?php elseif(isset($student_status[$k]) && $student_status[$k] === 'NoSub'): ?>
                                                                <span class="badge rq-badge rq-badge-nosub">No Submissions</span>
                                                            <?php elseif(isset($student_status[$k]) && $student_status[$k] === 'NoExam'): ?>
                                                                <span class="badge rq-badge rq-badge-noexam">No Exam</span>
                                                            <?php endif; ?>
                                                        </td>
                                                       <?php
                                                       if ($is_active_quarters) {
                                                           $student_component_quarter_stats = [];
                                                           $student_quarter_grade_stats = [];
                                                           $total_weighted_score = 0;
                                                           $total_percentage = 0;

                                                           foreach($components as $component_id => $component) {
                                                               foreach($active_quarters as $q_num) {
                                                                   if (!isset($assess[$component_id][$q_num])) {
                                                                       continue;
                                                                   }

                                                                   $quarter_total_hps = 0;
                                                                   $quarter_total_score = 0;

                                                                   foreach($assess[$component_id][$q_num] as $assessment) {
                                                                       $mark = isset($marks[$k][$assessment['assessment_id']]) ? $marks[$k][$assessment['assessment_id']] : 0;
                                                                       $quarter_total_score += $mark;
                                                                       $quarter_total_hps += $assessment['hps'];
                                                                   }

                                                                   $quarter_avg = $quarter_total_hps > 0 ? ($quarter_total_score / $quarter_total_hps) * 100 : 0;
                                                                   $quarter_weighted = ($quarter_avg * $component['percentage']) / 100;

                                                                   $student_component_quarter_stats[$component_id][$q_num] = [
                                                                       'score' => $quarter_total_score,
                                                                       'hps' => $quarter_total_hps,
                                                                       'avg' => $quarter_avg,
                                                                       'weighted' => $quarter_weighted,
                                                                       'component_percentage' => $component['percentage']
                                                                   ];

                                                                   $total_weighted_score += $quarter_weighted;
                                                                   $total_percentage += $component['percentage'];

                                                                   if (!isset($student_quarter_grade_stats[$q_num])) {
                                                                       $student_quarter_grade_stats[$q_num] = [
                                                                           'weighted_total' => 0,
                                                                           'percentage_total' => 0
                                                                       ];
                                                                   }
                                                                   $student_quarter_grade_stats[$q_num]['weighted_total'] += $quarter_weighted;
                                                                   $student_quarter_grade_stats[$q_num]['percentage_total'] += $component['percentage'];
                                                               }
                                                           }

                                                           $final_grade = $total_percentage > 0 ? ($total_weighted_score / $total_percentage) * 100 : 0;
                                                           $transmuted_equivalent = get_equivalent_from_transmutation($final_grade);
                                                            $is_failing = ($transmuted_equivalent === 'DR' || (is_numeric($transmuted_equivalent) && (!empty($depEdReport) ? (float)$transmuted_equivalent < 75 : (float)$transmuted_equivalent > 3.0)));

                                                            foreach($components as $component_id => $component):
                                                                foreach($active_quarters as $q_num):
                                                                    if(isset($assess[$component_id][$q_num])):
                                                                       $quarter_total_score = $student_component_quarter_stats[$component_id][$q_num]['score'] ?? 0;
                                                                       $quarter_weighted = $student_component_quarter_stats[$component_id][$q_num]['weighted'] ?? 0;
                                                                       foreach($assess[$component_id][$q_num] as $assessment):
                                                                           $mark = isset($marks[$k][$assessment['assessment_id']]) ? $marks[$k][$assessment['assessment_id']] : 0;

                                                                           // Calculate if this mark is a major cause of failure
                                                                           $mark_class = '';
                                                                           if ($is_failing && $assessment['hps'] > 0) {
                                                                               $mark_percentage = ($mark / $assessment['hps']) * 100;
                                                                               $component_weight = $component['percentage'];
                                                                               $impact_weight = $component_weight * ($assessment['percentage'] / 100);

                                                                               if ($mark_percentage < 75 && $impact_weight >= 5) {
                                                                                   if ($mark == 0 || $impact_weight >= 15) {
                                                                                       $mark_class = 'text-danger fw-bold bg-danger bg-opacity-25';
                                                                                   }
                                                                               }
                                                                           }
                                                                       ?>
                                                                         <td class="py-0 px-1 text-center editable-mark rq-mark <?php echo $mark_class; ?>"
                                                                         width="35px"
                                                                         title="Assessment Score"
                                                                         data-student-id="<?php echo $k; ?>"
                                                                         data-component-id="<?php echo $component_id; ?>"
                                                                         data-assessment-id="<?php echo $assessment['assessment_id']; ?>"
                                                                        data-class-id="<?php echo $_GET['class_id']; ?>"
                                                                        data-quarter="<?php echo $q_num; ?>"
                                                                        contenteditable="<?php echo (isset($student_status[$k]) && $student_status[$k] === 'Dropped') ? 'false' : 'true'; ?>"><?php echo $mark ?></td>
                                                                <?php
                                                                        endforeach;
                                                                ?>
                                                                        <td class="py-0 px-1 text-center rq-total" width="35px"><?php echo $quarter_total_score ?></td>
                                                                        <td class="py-0 px-1 text-center rq-weighted" width="35px"><?php echo number_format($quarter_weighted) ?></td>
                                                                <?php else: ?>
                                                                        <td class="py-0 px-1 text-center rq-none" colspan="2" width="35px">
                                                                            <small>No assessments</small>
                                                                        </td>
                                                               <?php endif; ?>
                                                               <?php endforeach; ?>
                                                           <?php endforeach; ?>

                                                           <!-- Quarter-wise Transmuted Grade Columns -->
                                                           <?php foreach($active_quarters as $q_num): ?>
                                                               <?php
                                                                $quarter_total_weighted = $student_quarter_grade_stats[$q_num]['weighted_total'] ?? 0;
                                                                $quarter_total_percentage = $student_quarter_grade_stats[$q_num]['percentage_total'] ?? 0;
                                                                $quarter_grade = $quarter_total_percentage > 0 ? ($quarter_total_weighted / $quarter_total_percentage) * 100 : 0;
                                                                $quarter_transmuted = get_equivalent_from_transmutation($quarter_grade);
                                                                $quarter_transmuted_num = is_numeric($quarter_transmuted) ? (float)$quarter_transmuted : 0;
                                                                 // INC rule: 0 score on a component with percentage >= 30% => INC
                                                                 $has_zero_q = false;
                                                                  foreach($components as $qc_cid => $qc_comp){
                                                                      if(isset($student_component_quarter_stats[$qc_cid][$q_num])){
                                                                          $qc_stat = $student_component_quarter_stats[$qc_cid][$q_num];
                                                                          if((($qc_stat['score'] ?? 0) == 0) && ($qc_comp['percentage'] ?? 0) >= 30){
                                                                              $has_zero_q = true; break;
                                                                          }
                                                                      }
                                                                  }
                                                                if($quarter_grade >= 30 && $quarter_grade < 55.49 && $has_zero_q && (!isset($student_status[$k]) || $student_status[$k] !== 'Dropped')){
                                                                    $quarter_transmuted = 'INC';
                                                                    $quarter_transmuted_num = 0;
                                                                }
 
                                                                if ($quarter_transmuted === 'INC') {
                                                                    $quarter_text_color = '#9a3412';
                                                                    $quarter_pill_bg = '#ffedd5';
                                                                    $quarter_pill_bd = '#fed7aa';
                                                                } elseif ($quarter_transmuted === 'DR') {
                                                                    $quarter_text_color = '#991b1b';
                                                                    $quarter_pill_bg = '#fee2e2';
                                                                    $quarter_pill_bd = '#fecaca';
                                                                } elseif (!empty($depEdReport) && $quarter_transmuted_num >= 75) {
                                                                    $quarter_text_color = '#166534';
                                                                    $quarter_pill_bg = '#dcfce7';
                                                                    $quarter_pill_bd = '#bbf7d0';
                                                                } elseif (!empty($depEdReport)) {
                                                                    $quarter_text_color = '#991b1b';
                                                                    $quarter_pill_bg = '#fee2e2';
                                                                    $quarter_pill_bd = '#fecaca';
                                                                } elseif ($quarter_transmuted_num >= 3.1 && $quarter_transmuted_num <= 3.5) {
                                                                    $quarter_text_color = '#92400e';
                                                                    $quarter_pill_bg = '#fef3c7';
                                                                    $quarter_pill_bd = '#fde68a';
                                                                } elseif ($quarter_transmuted_num > 3.5) {
                                                                    $quarter_text_color = '#991b1b';
                                                                    $quarter_pill_bg = '#fee2e2';
                                                                    $quarter_pill_bd = '#fecaca';
                                                                } elseif ($quarter_transmuted_num >= 1.0 && $quarter_transmuted_num <= 3.0) {
                                                                    $quarter_text_color = '#166534';
                                                                    $quarter_pill_bg = '#dcfce7';
                                                                    $quarter_pill_bd = '#bbf7d0';
                                                                } else {
                                                                    $quarter_text_color = '#334155';
                                                                    $quarter_pill_bg = '#f1f5f9';
                                                                    $quarter_pill_bd = '#e2e8f0';
                                                                }
                                                                ?>
                                                                 <td class="py-0 px-1 text-center transmuted-grade fw-bold rq-grade-cell" width="40px">
                                                                    <span class="rq-pill" style="color: <?php echo $quarter_text_color; ?>; background-color: <?php echo $quarter_pill_bg; ?>; border-color: <?php echo $quarter_pill_bd; ?>;"><?php echo is_numeric($quarter_transmuted) ? number_format($quarter_transmuted, 1) : $quarter_transmuted; ?></span>
                                                                </td>
                                                           <?php endforeach; ?>

                                                            <!-- Final Grade Columns -->
                                                            <?php
                                                            $initial = $final_grade;
                                                             // INC rule for final grade: 0 score on a component with percentage >= 30% => INC
                                                              $has_zero_final = false;
                                                              foreach($student_component_quarter_stats as $zc_cid => $zc_quarters){
                                                                  foreach($zc_quarters as $zc_qnum => $zc_stat){
                                                                      if((($zc_stat['score'] ?? 0) == 0) && ($zc_stat['component_percentage'] ?? 0) >= 30){
                                                                          $has_zero_final = true; break 2;
                                                                      }
                                                                  }
                                                              }
                                                            $transmuted_equivalent = get_equivalent_from_transmutation($initial);
                                                            $transmuted_equivalent_num = is_numeric($transmuted_equivalent) ? (float)$transmuted_equivalent : 0;
                                                            if($initial >= 30 && $initial < 55.49 && $has_zero_final && (!isset($student_status[$k]) || $student_status[$k] !== 'Dropped')){
                                                                $transmuted_equivalent = 'INC';
                                                                $transmuted_equivalent_num = 0;
                                                            }

                                                            // Check if student is dropped
                                                        if ($transmuted_equivalent === 'INC') {
                                                            $single_text_color = '#9a3412';
                                                            $single_pill_bg = '#ffedd5';
                                                            $single_pill_bd = '#fed7aa';
                                                        } elseif ($transmuted_equivalent === 'DR') {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif (!empty($depEdReport) && $transmuted_equivalent_num >= 75) {
                                                            $single_text_color = '#166534';
                                                            $single_pill_bg = '#dcfce7';
                                                            $single_pill_bd = '#bbf7d0';
                                                        } elseif (!empty($depEdReport)) {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif ($transmuted_equivalent_num >= 3.1 && $transmuted_equivalent_num <= 3.5) {
                                                            $single_text_color = '#92400e';
                                                            $single_pill_bg = '#fef3c7';
                                                            $single_pill_bd = '#fde68a';
                                                        } elseif ($transmuted_equivalent_num > 3.5) {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif ($transmuted_equivalent_num >= 1.0 && $transmuted_equivalent_num <= 3.0) {
                                                            $single_text_color = '#166534';
                                                            $single_pill_bg = '#dcfce7';
                                                            $single_pill_bd = '#bbf7d0';
                                                        } else {
                                                            $single_text_color = '#334155';
                                                            $single_pill_bg = '#f1f5f9';
                                                            $single_pill_bd = '#e2e8f0';
                                                        }
                                                            ?>
                                                              <td class="py-0 px-1 text-center fw-bold initial-grade-cell rq-initial-cell" width="40px"><?php echo number_format($initial, 1) ?></td>
                                                             <td class="py-0 px-1 text-center transmuted-grade fw-bold rq-grade-cell" width="40px">
                                                                <span class="rq-pill" style="color: <?php echo $single_text_color; ?>; background-color: <?php echo $single_pill_bg; ?>; border-color: <?php echo $single_pill_bd; ?>;"><?php echo is_numeric($transmuted_equivalent) ? number_format($transmuted_equivalent, 1) : $transmuted_equivalent; ?></span>
                                                            </td>
                                                       <?php } else { ?>
                                                           <?php
                                                            // Single quarter - calculate final grade first to determine if student is failing
                                                            $total_weighted_score = 0;
                                                            $total_percentage = 0;
                                                            $single_has_zero = false;
                                                           foreach($components as $cid => $v):
                                                               $total_hps_possible = 0;
                                                               $total_score = 0;
                                                               $component_has_grades = false;
                                                               if(isset($assess[$cid])) {
                                                                   foreach($assess[$cid] as $row):
                                                                       $mark = isset($marks[$k][$row['assessment_id']]) ? $marks[$k][$row['assessment_id']] : 0;
                                                                       $total_score += $mark;
                                                                       $total_hps_possible += $row['hps'];
                                                                       $component_has_grades = true;
                                                                   endforeach;

                                                                   if($component_has_grades && $total_hps_possible > 0) {
                                                                       $component_grade = ($total_score / $total_hps_possible) * 100;
                                                                       $perc_hps = ($component_grade * $components[$cid]['percentage']) / 100;
                                                                       $total_weighted_score += $perc_hps;
                                                                       $total_percentage += $components[$cid]['percentage'];
                                                                   }
                                                               }
                                                           endforeach;

                                                           $final_grade = $total_percentage > 0 ? ($total_weighted_score / $total_percentage) * 100 : 0;
                                                           $transmuted_equivalent = get_equivalent_from_transmutation($final_grade);
                                                            $is_failing = ($transmuted_equivalent === 'DR' || (is_numeric($transmuted_equivalent) && (!empty($depEdReport) ? (float)$transmuted_equivalent < 75 : (float)$transmuted_equivalent > 3.0)));

                                                            // Now display marks with impact analysis
                                                            foreach($components as $cid => $v): ?>
                                                               <?php
                                                               $total_hps_possible = 0;
                                                               $total_score = 0;
                                                               $perc_hps = 0;
                                                               $perc_hpss = 0;
                                                               $component_has_grades = false;
                                                               ?>
                                                               <?php if(isset($assess[$cid])): ?>
                                                                   <?php foreach($assess[$cid] as $row): ?>
                                                                       <?php
                                                                       $mark = isset($marks[$k][$row['assessment_id']]) ? $marks[$k][$row['assessment_id']] : 0;
                                                                       $total_score += $mark;
                                                                       $total_hps_possible += $row['hps'];
                                                                       $component_has_grades = true;

                                                                       // Calculate if this mark is a major cause of failure
                                                                       $mark_class = '';
                                                                       if ($is_failing && $row['hps'] > 0) {
                                                                           $mark_percentage = ($mark / $row['hps']) * 100;
                                                                           $component_weight = $components[$cid]['percentage'];
                                                                           $impact_weight = $component_weight * ($row['percentage'] / 100); // This assessment's weight in overall grade

                                                                           // If this mark is significantly below passing threshold and has significant weight
                                                                           if ($mark_percentage < 75 && $impact_weight >= 5) { // 5% or more of overall grade
                                                                               // Color code based on impact level
                                                                               if ($mark == 0) {
                                                                                   // Zero marks - always red regardless of impact
                                                                                   $mark_class = 'text-danger fw-bold bg-danger bg-opacity-25';
                                                                               } elseif ($impact_weight >= 15) {
                                                                                   // High impact (15% or more of overall grade) - Red
                                                                                   $mark_class = 'text-danger fw-bold bg-danger bg-opacity-25';
                                                                               }
                                                                           }
                                                                       }
                                                                       ?>
                                                                     <td class="py-0 px-1 text-center editable-mark rq-mark <?php echo $mark_class; ?>"
                                                                         width="35px"
                                                                         title="Assessment Score"
                                                                         data-student-id="<?php echo $k; ?>"
                                                                         data-component-id="<?php echo $cid; ?>"
                                                                         data-assessment-id="<?php echo $row['assessment_id']; ?>"
                                                                        data-class-id="<?php echo $_GET['class_id']; ?>"
                                                                        data-quarter="<?php echo $_GET['quarter']; ?>"
                                                                        contenteditable="<?php echo (isset($student_status[$k]) && $student_status[$k] === 'Dropped') ? 'false' : 'true'; ?>">
                                                                        <?php echo $mark?>
                                                                    </td>
                                                                   <?php endforeach; ?>

                                                                    <?php
                                                                    // Calculate percentage for this component (same method as report_of_grades.php)
                                                                    if($component_has_grades && $total_hps_possible > 0) {
                                                                        $component_grade = ($total_score / $total_hps_possible) * 100;
                                                                        $perc_hpss = $component_grade;
                                                                        $perc_hps = ($component_grade * $components[$cid]['percentage']) / 100;
                                                                    } else {
                                                                        $perc_hpss = 0;
                                                                        $perc_hps = 0;
                                                                    }
                                                                     // Track zero Total for INC rule (only if component % >= 30)
                                                                      if(isset($assess[$cid]) && (($total_score == 0) && ($components[$cid]['percentage'] ?? 0) >= 30)){
                                                                          $single_has_zero = true;
                                                                      }
                                                                    ?>
                                                                     <td class="py-0 px-1 text-center rq-total" width="35px"><?php echo $total_score ?></td>
                                                                     <td class="py-0 px-1 text-center rq-weighted" width="35px"><?php echo round($perc_hps,1) ?></td>
                                                                <?php else: ?>
                                                                    <td class="py-0 px-1 text-center rq-none" colspan="3">No assessments for this component</td>
                                                               <?php endif; ?>
                                                               <?php
                                                               $initial += ($perc_hpss * $c_perc_arr[$cid]);
                                                               ?>
                                                            <?php endforeach; ?>
                                                        <?php
                                                        // Get the equivalent grade from the transmutation table
                                                        $transmuted_equivalent = get_equivalent_from_transmutation($initial);
                                                        $transmuted_equivalent_num = is_numeric($transmuted_equivalent) ? (float)$transmuted_equivalent : 0;
                                                        // INC rule: initial in [30, 55.49) plus zero-score 30%+ component => INC
                                                        if($initial >= 30 && $initial < 55.49 && $single_has_zero && (!isset($student_status[$k]) || $student_status[$k] !== 'Dropped')){
                                                            $transmuted_equivalent = 'INC';
                                                            $transmuted_equivalent_num = 0;
                                                        }

                                                        // Check if student is dropped
                                                        if ($transmuted_equivalent === 'INC') {
                                                            $single_text_color = '#9a3412';
                                                            $single_pill_bg = '#ffedd5';
                                                            $single_pill_bd = '#fed7aa';
                                                        } elseif ($transmuted_equivalent === 'DR') {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif (!empty($depEdReport) && $transmuted_equivalent_num >= 75) {
                                                            $single_text_color = '#166534';
                                                            $single_pill_bg = '#dcfce7';
                                                            $single_pill_bd = '#bbf7d0';
                                                        } elseif (!empty($depEdReport)) {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif ($transmuted_equivalent_num >= 3.1 && $transmuted_equivalent_num <= 3.5) {
                                                            $single_text_color = '#92400e';
                                                            $single_pill_bg = '#fef3c7';
                                                            $single_pill_bd = '#fde68a';
                                                        } elseif ($transmuted_equivalent_num > 3.5) {
                                                            $single_text_color = '#991b1b';
                                                            $single_pill_bg = '#fee2e2';
                                                            $single_pill_bd = '#fecaca';
                                                        } elseif ($transmuted_equivalent_num >= 1.0 && $transmuted_equivalent_num <= 3.0) {
                                                            $single_text_color = '#166534';
                                                            $single_pill_bg = '#dcfce7';
                                                            $single_pill_bd = '#bbf7d0';
                                                        } else {
                                                            $single_text_color = '#334155';
                                                            $single_pill_bg = '#f1f5f9';
                                                            $single_pill_bd = '#e2e8f0';
                                                        }
                                                        ?>
                                                        <td class="py-0 px-1 text-center fw-bold initial-grade-cell rq-initial-cell" width="40px"><?php echo number_format($initial, 2) ?></td>
                                                        <td class="py-0 px-1 text-center transmuted-grade fw-bold rq-grade-cell" width="40px">
                                                            <span class="rq-pill" style="color: <?php echo $single_text_color; ?>; background-color: <?php echo $single_pill_bg; ?>; border-color: <?php echo $single_pill_bd; ?>;"><?php echo is_numeric($transmuted_equivalent) ? number_format($transmuted_equivalent, 1) : $transmuted_equivalent; ?></span>
                                                        </td>
                                                       
                                                                <?php }?>
                                                     </tr>
                                                <?php endforeach; ?>
                                                
                                                <?php $grades_table_body = ob_get_clean(); echo $grades_table_body; ?>
                                               </tbody>
                                           </table>                  
                                       </div>

                                       <?php endif; ?>
                                   </div>
                               </div>
                           </div>
                                    <!-- Signatories Section -->
                                   <div class="col-8" style="page-break-inside: auto;">
                                       <div class="row">
                                           <?php
                                           // Define signatory types and their display titles
                                           $signatoryTypes = [
                                               'certified' => 'CERTIFIED TRUE AND CORRECT',
                                               'checked' => 'CHECKED BY',
                                               'noted' => 'NOTED BY',
                                               'received' => 'RECEIVED BY'
                                           ];

                                           // Initialize signatories array
                                           $signatories = [];

                                           // First, check if the signatories table has the type column
                                           $hasTypeColumn = false;
                                           try {
                                               $result = $conn->query("PRAGMA table_info(signatories)");
                                               while ($col = $result->fetchArray(SQLITE3_ASSOC)) {
                                                   if ($col['name'] === 'type') {
                                                       $hasTypeColumn = true;
                                                       break;
                                                   }
                                               }
                                           } catch (Exception $e) {
                                               error_log("Error checking table structure: " . $e->getMessage());
                                           }

                                           // Fetch signatories based on whether type column exists
                                           foreach ($signatoryTypes as $type => $title) {
                                               $signatories[$type] = false;
                                               try {
                                                   if ($hasTypeColumn) {
                                                       // New query with type column
                                                       $result = $conn->query("
                                                           SELECT * FROM `signatories`
                                                           WHERE `type` = '" . SQLite3::escapeString($type) . "'
                                                           ORDER BY `date_created` DESC
                                                           LIMIT 1");
                                                   } else {
                                                       // Fallback for old schema (just get the first signatory)
                                                       $result = $conn->query("
                                                           SELECT * FROM `signatories`
                                                           ORDER BY `date_created` DESC
                                                           LIMIT 1");
                                                   }

                                                   if ($result) {
                                                       $signatories[$type] = $result->fetchArray(SQLITE3_ASSOC);
                                                   }
                                               } catch (Exception $e) {
                                                   error_log("Error fetching signatory ($type): " . $e->getMessage());
                                               }
                                           }

                                           // Output each signatory section only if it has a name or fullname
                                           foreach ($signatoryTypes as $type => $title):
                                               $signatory = $signatories[$type];
                                               // Only display if signatory exists and has a fullname
                                               if($signatory && !empty($signatory['fullname'])):
                                           ?>
                                           <div class="col-md-4 text-center">
                                               <div class="pt-4">
                                                   <h6 class="mb-4"><?php echo $title; ?>:</h6>
                                                   <div class="mb-4" style="min-height: 80px;">
                                                       <div class="mb-1" style="border-bottom: 1px solid #000; width: 90%; height: 50px; margin: 0 auto;">
                                                           <div style="height: 100%; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 5px;">
                                                               <?php echo htmlspecialchars($signatory['fullname']) ?>
                                                           </div>
                                                       </div>
                                                       <div class="mt-2 fw-bold"><?php echo htmlspecialchars($signatory['designation']) ?></div>
                                                       <div class="text-muted small">Signature Over Printed Name</div>
                                                   </div>
                                               </div>
                                           </div>
                                           <?php endif; endforeach; ?>
                                       </div>
                                   </div>
                                   <!-- End Signatories Section -->
        <?php endif; ?>

    </script>

    <?php require_once('security_protection.php'); ?>

    </html>

    <style>
        /* =====================================================================
           PROFESSIONAL GRADES TABLE DESIGN SYSTEM (rq-grades)
           Clean institutional look: navy/slate headers, hairline borders,
           pill grade badges, subtle hover. Functional hooks (#gradesTable,
           .editable-mark, .sticky-col, status classes) are preserved.
           ===================================================================== */
        :root {
            --rq-navy: #1e293b;
            --rq-navy-2: #0f172a;
            --rq-slate: #475569;
            --rq-line: #e2e8f0;
            --rq-line-strong: #cbd5e1;
            --rq-bg-soft: #f8fafc;
            --rq-bg-quarter: #f1f5f9;
            --rq-text: #0f172a;
            --rq-muted: #64748b;
            --rq-accent: #2563eb;
            --rq-radius: 10px;
        }
        .freeze-panes-container {
            border: 1px solid var(--rq-line-strong);
            border-radius: var(--rq-radius);
            box-shadow: 0 1px 2px rgba(15,23,42,.06), 0 8px 24px -12px rgba(15,23,42,.18);
            background: #fff;
        }
        #gradesTable.rq-grades {
            --bs-table-bg: #ffffff;
            --bs-table-color: var(--rq-text);
            --bs-table-border-color: var(--rq-line);
            border-collapse: separate;
            border-spacing: 0;
            font-size: 12px;
            color: var(--rq-text);
            background: #fff;
        }
        #gradesTable.rq-grades thead.rq-thead {
            background: var(--rq-navy);
        }
        /* --- Main header row: deep slate --- */
        #gradesTable.rq-grades thead tr.rq-row-main th {
            background-color: var(--rq-navy);
            color: #f8fafc;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
            border: 1px solid #334155;
            border-bottom: 2px solid #0f172a;
            padding: 10px 8px;
            vertical-align: middle;
            white-space: nowrap;
        }
        #gradesTable.rq-grades thead tr.rq-row-main th.rq-h-student {
            text-align: center;
            min-width: 200px;
            background-color: var(--rq-navy-2);
            border-right: 2px solid #475569;
            border-top-left-radius: 9px;
        }
        #gradesTable.rq-grades .rq-comp-name {
            display: block;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
            color: #fff;
            max-width: 220px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        #gradesTable.rq-grades .rq-comp-pct {
            display: inline-block;
            font-size: 10px;
            font-weight: 700;
            letter-spacing: .03em;
            color: #e2e8f0;
            background: rgba(255,255,255,.12);
            border: 1px solid rgba(255,255,255,.22);
            border-radius: 999px;
            padding: 1px 8px;
            line-height: 1.5;
        }
        #gradesTable.rq-grades .rq-h-sub {
            display: block;
            font-size: 9px;
            font-weight: 600;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: #cbd5e1;
            margin-top: 1px;
        }
        #gradesTable.rq-grades thead tr.rq-row-main th.rq-h-grade {
            background-color: #243449;
            min-width: 72px;
        }
        #gradesTable.rq-grades thead tr.rq-row-main th.rq-h-initial,
        #gradesTable.rq-grades thead tr.rq-row-main th.rq-h-avg {
            background-color: #1a365d;
        }
        /* --- Quarter band --- */
        #gradesTable.rq-grades thead tr.rq-row-quarter th {
            background-color: var(--rq-bg-quarter);
            color: var(--rq-slate);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: .06em;
            text-transform: uppercase;
            border: 1px solid var(--rq-line);
            padding: 6px 6px;
        }
        #gradesTable.rq-grades thead tr.rq-row-quarter th.rq-h-empty {
            color: #94a3b8;
            font-weight: 600;
        }
        /* --- Assessment / total / pct --- */
        #gradesTable.rq-grades thead tr.rq-row-assess th,
        #gradesTable.rq-grades thead tr.rq-row-hps th {
            border: 1px solid var(--rq-line);
            padding: 5px 6px;
        }
        #gradesTable.rq-grades thead tr.rq-row-assess th.rq-h-assess {
            background: #ffffff;
            color: var(--rq-text);
            font-size: 11px;
            font-weight: 600;
            min-width: 44px;
        }
        #gradesTable.rq-grades .rq-assess-name {
            font-size: 11px;
            font-weight: 600;
            color: #334155;
            max-width: 110px;
        }
        #gradesTable.rq-grades thead th.rq-h-total,
        #gradesTable.rq-grades thead th.rq-h-total-val {
            background: #dbe2ec;
            color: #334155;
            font-size: 10px;
            font-weight: 800;
            letter-spacing: .05em;
        }
        #gradesTable.rq-grades thead th.rq-h-pct,
        #gradesTable.rq-grades thead th.rq-h-pct-val {
            background: #cbd5e1;
            color: #1e293b;
            font-size: 10px;
            font-weight: 800;
        }
        #gradesTable.rq-grades thead th.rq-h-hps {
            background: #f8fafc;
            color: var(--rq-muted);
            font-size: 10px;
            font-weight: 600;
        }
        #gradesTable.rq-grades thead th.rq-h-none {
            background: #f8fafc;
            color: #94a3b8;
            font-size: 10px;
            font-weight: 600;
        }
        /* --- Body --- */
        #gradesTable.rq-grades tbody td {
            border: 1px solid var(--rq-line);
            padding: 2px 4px;
            font-size: 13px;
            vertical-align: middle;
            background: #fff;
            color: var(--rq-text);
        }
        #gradesTable.rq-grades tbody tr:nth-child(even) td:not(.rq-student):not(.rq-total):not(.rq-weighted):not(.rq-initial-cell):not(.rq-grade-cell) {
            background-color: #fcfdff;
        }
        #gradesTable.rq-grades td.rq-student {
            background: #fff;
            font-weight: 600;
            font-size: 13px;
            text-align: left;
            box-shadow: 6px 0 8px -6px rgba(15,23,42,.15);
            max-width: 250px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        #gradesTable.rq-grades td.rq-student .rq-student-name {
            font-weight: 600;
            color: #0f172a;
        }
        #gradesTable.rq-grades .rq-badge {
            font-size: 9px;
            font-weight: 700;
            letter-spacing: .04em;
            text-transform: uppercase;
            border-radius: 999px;
            padding: 2px 7px;
            border: 1px solid transparent;
            vertical-align: middle;
            margin-left: 6px;
        }
        #gradesTable.rq-grades .rq-badge-dropped { background: #fee2e2; color: #991b1b; border-color: #fecaca; }
        #gradesTable.rq-grades .rq-badge-nosub { background: #fef3c7; color: #92400e; border-color: #fde68a; }
        #gradesTable.rq-grades .rq-badge-noexam { background: #e0f2fe; color: #075985; border-color: #bae6fd; }
        #gradesTable.rq-grades td.rq-mark {
            font-variant-numeric: tabular-nums;
            text-align: center;
            border: 1px solid var(--rq-line);
        }
        #gradesTable.rq-grades td.rq-mark.text-danger { background-color: #fef2f2; color: #b91c1c; }
        #gradesTable.rq-grades td.rq-total {
            background: #e2e8f0;
            font-weight: 700;
            font-variant-numeric: tabular-nums;
        }
        #gradesTable.rq-grades td.rq-weighted {
            background: #d7dfea;
            font-weight: 700;
            color: #1e293b;
            font-variant-numeric: tabular-nums;
        }
        #gradesTable.rq-grades td.rq-none { background: #f8fafc; color: #94a3b8; font-size: 11px; }
        #gradesTable.rq-grades td.rq-initial-cell {
            font-weight: 800;
            font-size: 13px;
            font-variant-numeric: tabular-nums;
            background: #f8fafc;
            color: #0f172a;
            border-left: 2px solid var(--rq-line-strong);
            width: 40px;
            min-width: 40px;
            max-width: 40px;
            text-align: center;
        }
        #gradesTable.rq-grades td.rq-grade-cell {
            background: #fff;
            border-left: 1px solid var(--rq-line);
            width: 40px;
            min-width: 40px;
            max-width: 40px;
            text-align: center;
        }
        #gradesTable.rq-grades .rq-pill {
            display: inline-block;
            min-width: 34px;
            font-size: 13px;
            font-weight: 800;
            font-variant-numeric: tabular-nums;
            border: 1px solid var(--rq-line);
            border-radius: 999px;
            padding: 1px 6px;
            line-height: 1.4;
        }
        /* Subtle professional hover (overrides loud orange below) */
        #gradesTable.rq-grades.table-hover tbody tr:hover > td {
            background-color: #f1f5f9;
        }
        #gradesTable.rq-grades.table-hover tbody tr:hover > td.rq-student {
            background-color: #eef2f7;
        }
        #gradesTable.rq-grades.table-hover tbody tr:hover {
            cursor: default;
        }
        #gradesTable.rq-grades .editable-mark:focus {
            background-color: #eff6ff;
            outline: 2px solid var(--rq-accent);
            outline-offset: -2px;
            border-radius: 4px;
        }
        #gradesTable.rq-grades .editable-mark.error {
            background-color: #fef2f2;
            outline: 2px solid #dc2626;
        }
        /* Status tints - soft professional */
        #gradesTable.rq-grades tbody tr.status-dropped td { background-color: rgba(185,28,28,.06); }
        #gradesTable.rq-grades tbody tr.status-dropped td.rq-student { background-color: #fef2f2; }
        #gradesTable.rq-grades tbody tr.status-nosub td { background-color: rgba(146,64,14,.06); }
        #gradesTable.rq-grades tbody tr.status-nosub td.rq-student { background-color: #fffbeb; }
        #gradesTable.rq-grades tbody tr.status-noexam td { background-color: rgba(7,89,133,.06); }
        #gradesTable.rq-grades tbody tr.status-noexam td.rq-student { background-color: #f0f9ff; }
        /* Freeze Panes Styles */
        .freeze-panes-container {
            position: relative;
            max-height: 70vh;
            max-width: 100%;
            width: 100%;
            overflow-y: auto;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
        }

        .grades-table-container {
            overflow-x: auto;
            overflow-y: auto;
        }

        .table-header {
            position: sticky;
            top: 0;
            z-index: 15;
            /* Grades table is always light - even in dark mode */
            background-color: #ffffff;
        }

        .sticky-col {
            position: sticky !important;
            left: 0;
        }

        .sticky-student-col {
            left: 0 !important;
            min-width: 180px;
            width: 180px;
            max-width: 180px;
            background-color: #fff !important;
            background-clip: padding-box;
            border-right: 2px solid #adb5bd !important;
            box-shadow: 6px 0 8px -6px rgba(0,0,0,0.18);
            z-index: 12;
        }

        .grades-table tbody .sticky-student-col {
            position: sticky !important;
            left: 0 !important;
            z-index: 11;
            white-space: normal;
            word-break: break-word;
        }

        .grades-table thead .sticky-student-col {
            position: sticky !important;
            left: 0 !important;
            z-index: 30 !important;
        }

        /* Fix for scrolling alignment */
        .freeze-panes-container table {
            margin: 0;
            border-collapse: separate;
            border-spacing: 0;
        }

        .grades-table {
            display: block;
            width: 100%;
            min-width: 100%;
            max-width: 100%;
            overflow-x: auto;
            table-layout: auto;
        }

        .active-quarters-container {
            overflow-x: auto;
            overflow-y: auto;
        }

        .active-quarters-table {
            width: 100%;
            min-width: 100%;
        }

        .single-quarter-table {
            width: 100%;
            min-width: 100%;
        }

        /* Adjust row height for tbody */
        .freeze-panes-container tbody tr {
            height: 25px;
            min-height: 25px;
        }

        .freeze-panes-container tbody td {
            padding: 4px 6px;
            vertical-align: middle;
            line-height: 1.2;
        }

        /* Fix border issues during scrolling */
        .freeze-panes-container .table-bordered {
            border: 1px solid #adb5bd;
        }

        .freeze-panes-container .table-bordered th,
        .freeze-panes-container .table-bordered td {
            border: 1px solid #adb5bd;
        }

        /* Ensure header borders remain visible */
        .table-header th {
            border-bottom: 1px solid #adb5bd !important;
            border-top: 1px solid #adb5bd !important;
        }

        /* Fix sticky column borders */
        .sticky-col {
            border-left: 1px solid #adb5bd !important;
        }

        .table-header th.sticky-col {
            border-left: 1px solid #adb5bd !important;
            border-top: 1px solid #adb5bd !important;
        }

        .grades-table tbody td.sticky-student-col {
            background-color: #ffffff !important;
        }

        .grades-table.table-hover tbody tr:hover td.sticky-student-col {
            background-color: #f1f5f9 !important;
        }

        /* =====================================================================
           #gradesTable ALWAYS renders in LIGHT mode.
           Dark mode is intentionally NOT applied to the grades table so the
           class record stays readable and matches what gets printed/exported.
           These rules neutralize the Horizon dark theme's .table styling;
           the ID selector outranks every class-based dark rule in
           css/horizon-theme.css.
           ===================================================================== */
        html[data-theme="dark"] #gradesTable,
        body[data-theme="dark"] #gradesTable,
        body[data-bs-theme="dark"] #gradesTable {
            /* Bootstrap table tokens - forced to their light values.
               Striped vars pinned to white: rows must NOT alternate. */
            --bs-table-bg: #ffffff;
            --bs-table-color: #000000;
            --bs-table-border-color: #adb5bd;
            --bs-table-striped-bg: #ffffff;
            --bs-table-striped-color: #000000;
            /* Student column vars - permanently light */
            --rq-student-bg: #ffffff;
            --rq-student-text: #000000;
            --rq-cell-border: #adb5bd;
            /* Neutral surface + black text regardless of theme */
            background-color: #ffffff;
            color: #000000;
        }

        html[data-theme="dark"] #gradesTable tbody td,
        body[data-theme="dark"] #gradesTable tbody td,
        body[data-bs-theme="dark"] #gradesTable tbody td {
            /* Undo Horizon's dark tbody fill; let Bootstrap striping show */
            background-color: transparent;
            color: inherit;
            border-color: #adb5bd;
        }

        /* Restore the original subtle row hover instead of the theme hover */
        html[data-theme="dark"] #gradesTable.table-hover tbody tr:hover > td,
        body[data-theme="dark"] #gradesTable.table-hover tbody tr:hover > td,
        body[data-bs-theme="dark"] #gradesTable.table-hover tbody tr:hover > td {
            background-color: #f1f5f9 !important;
            color: #0f172a;
        }

        /* Restore the original status row tints (not Horizon's dark ones) */
        html[data-theme="dark"] #gradesTable tbody tr.status-dropped td,
        body[data-theme="dark"] #gradesTable tbody tr.status-dropped td,
        body[data-bs-theme="dark"] #gradesTable tbody tr.status-dropped td {
            background-color: rgba(185, 28, 28, 0.08) !important;
        }
        html[data-theme="dark"] #gradesTable tbody tr.status-nosub td,
        body[data-theme="dark"] #gradesTable tbody tr.status-nosub td,
        body[data-bs-theme="dark"] #gradesTable tbody tr.status-nosub td {
            background-color: rgba(146, 64, 14, 0.08) !important;
        }
        html[data-theme="dark"] #gradesTable tbody tr.status-noexam td,
        body[data-theme="dark"] #gradesTable tbody tr.status-noexam td,
        body[data-bs-theme="dark"] #gradesTable tbody tr.status-noexam td {
            background-color: rgba(7, 89, 133, 0.08) !important;
        }

        /* Sticky student cell: white surface, black text even in dark mode */
        html[data-theme="dark"] #gradesTable tbody td.sticky-col,
        body[data-theme="dark"] #gradesTable tbody td.sticky-col,
        body[data-bs-theme="dark"] #gradesTable tbody td.sticky-col {
            background-color: #ffffff !important;
            color: #000000 !important;
        }

        /* Add hover effect for table cells */
        .editable-mark:focus {
            background-color: #eff6ff;
            outline: 2px solid #2563eb;
            border-radius: 3px;
            min-height: 24px; /* Ensure minimum cell height */
            padding: 2px; /* Add some padding */
        }

        .table-hover tbody tr:hover td {
            background-color: #f1f5f9 !important;
        }

        .table-hover tbody tr:hover .sticky-col {
            background-color: #f1f5f9 !important;
        }

        .table-hover tbody tr:hover {
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .report-class-tabs {
            gap: 0;
            align-items: end;
            border-bottom: 1px solid #c6ccd3;
            padding-top: 0.35rem;
            padding-left: 0.35rem;
            overflow-x: auto;
            overflow-y: hidden;
            flex-wrap: nowrap;
            scrollbar-width: thin;
            background: linear-gradient(180deg, #eef2f6 0%, #e3e8ee 100%);
            border-radius: 0.65rem 0.65rem 0 0;
        }

        .report-class-tab {
            position: relative;
            margin-bottom: -1px;
            margin-right: -1px;
            padding: 0.55rem 1rem 0.5rem;
            border: 1px solid #bcc4cd;
            border-bottom: none;
            border-radius: 0.85rem 0.85rem 0 0;
            background: linear-gradient(180deg, #f1f4f7 0%, #dfe5ec 100%);
            color: #4b5563;
            font-size: 0.85rem;
            font-weight: 600;
            line-height: 1.2;
            white-space: nowrap;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.95);
            transition: background 0.2s ease, color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease;
        }

        .report-class-tab::before,
        .report-class-tab::after {
            content: "";
            position: absolute;
            bottom: 0;
            width: 12px;
            height: 12px;
            background: transparent;
            pointer-events: none;
        }

        .report-class-tab::before {
            left: -12px;
            border-bottom-right-radius: 12px;
            box-shadow: 6px 6px 0 0 #dfe5ec;
        }

        .report-class-tab::after {
            right: -12px;
            border-bottom-left-radius: 12px;
            box-shadow: -6px 6px 0 0 #dfe5ec;
        }

        .report-class-tab:hover {
            background: linear-gradient(180deg, #f9fbfc 0%, #e7edf3 100%);
            color: #1f2937;
            transform: translateY(-1px);
            z-index: 1;
        }

        .report-class-tab:hover::before {
            box-shadow: 6px 6px 0 0 #e7edf3;
        }

        .report-class-tab:hover::after {
            box-shadow: -6px 6px 0 0 #e7edf3;
        }

        .report-class-tab.active {
            background: linear-gradient(180deg, #ffffff 0%, #fdfefe 100%);
            border-color: #bcc4cd;
            color: #111827;
            z-index: 3;
            box-shadow: inset 0 1px 0 rgba(255,255,255,1), 0 -1px 0 rgba(255,255,255,1);
        }

        .report-class-tab.active::before {
            box-shadow: 6px 6px 0 0 #ffffff;
        }

        .report-class-tab.active::after {
            box-shadow: -6px 6px 0 0 #ffffff;
        }

        /* =====================================================================
           Dark mode (Horizon theme) - ACTIVE tab only.
           Only the selected Subject/Section tab switches to the dark card
           surface (melting into the content below via its ::before/::after
           corner shadows). Inactive tabs keep their regular styling.
           ===================================================================== */
        html[data-theme="dark"] .report-class-tab.active,
        body[data-theme="dark"] .report-class-tab.active,
        body[data-bs-theme="dark"] .report-class-tab.active {
            background: linear-gradient(180deg, #1d2a40 0%, #182235 100%);
            border-color: #3b4a63;
            color: #f1f5ff;
            box-shadow: inset 0 1px 0 rgba(255,255,255,0.08);
        }

        html[data-theme="dark"] .report-class-tab.active::before,
        body[data-theme="dark"] .report-class-tab.active::before,
        body[data-bs-theme="dark"] .report-class-tab.active::before {
            box-shadow: 6px 6px 0 0 #182235;
        }

        html[data-theme="dark"] .report-class-tab.active::after,
        body[data-theme="dark"] .report-class-tab.active::after,
        body[data-bs-theme="dark"] .report-class-tab.active::after {
            box-shadow: -6px 6px 0 0 #182235;
        }

        @media print {
            /* Printing always uses light surfaces, even in dark mode */
            :root,
            [data-theme="dark"],
            body[data-theme="dark"],
            body[data-bs-theme="dark"] {
                --rq-student-bg: #ffffff;
                --rq-cell-border: #adb5bd;
                --rq-student-text: #000000;
            }
            @page {
                size: 8.5in 13in;
                margin: 0.5in;
            }
            body {
                margin: 0;
                padding: 10px;
                font-family: Arial, sans-serif;
                font-size: 9pt;
            }

            .freeze-panes-container {
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            .grades-table-container {
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            .card-header, .btn, #transmuted_table, .no-print {
                display: none !important;
            }
            /* Let the long grades table paginate naturally across pages so
               signatories that follow can't overlap continued rows */
            #outprint {
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            #outprint .row {
                display: block !important;
            }
            .table-responsive {
                margin-bottom: 0 !important;
                clear: both !important;
                position: static !important;
                max-height: none !important;
                height: auto !important;
                overflow: visible !important;
            }
            .table {
                margin-bottom: 20px !important;
                position: static !important;
                max-height: none !important;
                height: auto !important;
                overflow: visible !important;
            }
            /* Sticky/frozen panes must not apply in print - they pin cells
               over the continued rows on page 2 */
            .table-header,
            thead.sticky-top,
            .sticky-col,
            th.sticky-col,
            td.sticky-col,
            .table-header th.sticky-col {
                position: static !important;
                left: auto !important;
                top: auto !important;
                box-shadow: none !important;
                z-index: auto !important;
            }
            /* Signatories flow after the table/table container in print */
            .col-8 {
                display: block !important;
                position: static !important;
                float: none !important;
                clear: both !important;
                width: 100% !important;
                max-width: 100% !important;
                padding: 0 !important;
                margin: 30px 0 0 0 !important;
                background: white !important;
                page-break-inside: avoid !important;
                break-inside: avoid !important;
            }
            .col-8.offset-2.mt-2 .row {
                display: flex !important;
                flex-wrap: wrap !important;
                margin-right: -15px !important;
                margin-left: -15px !important;
            }
            .col-md-4.text-center {
                display: block !important;
                page-break-inside: avoid;
                width: 33.33% !important;
                float: left !important;
                padding: 0 15px !important;
            }
            .col-md-4.text-center h6 {
                font-size: 10pt !important;
                margin-bottom: 15px !important;
            }
            .col-md-4.text-center .mb-4 {
                margin-bottom: 20px !important;
            }
            .col-md-4.text-center .mb-1 {
                border-bottom: 1px solid #000 !important;
                width: 90% !important;
                height: 50px !important;
                margin: 0 auto !important;
            }
            .col-md-4.text-center .mt-2 {
                margin-top: 10px !important;
                font-weight: bold !important;
                font-size: 9pt !important;
            }
            .col-md-4.text-center .text-muted {
                font-size: 8pt !important;
                color: #666 !important;
            }
            .table {
                width: 100% !important;
                max-width: 100% !important;
                margin: 0 0 30px 0 !important;
                font-size: 9pt !important;
                border-collapse: collapse !important;
                border: 1px solid #dee2e6 !important;
                position: static !important;
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            .table th, .table td {
                padding: 3px 5px !important;
                line-height: 1.2;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                border: 1px solid #dee2e6 !important;
            }
            .table td {
                width: 35px !important;
                min-width: 35px !important;
                max-width: 35px !important;
            }
            .table th {
                background-color:#1e293b !important;
                color: #fff !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                font-weight: bold;
            }
            .bg-dark {
                background-color: #1e293b !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                color: #fff !important;
            }
            .bg-warning {
                background-color: #fff3cd !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .bg-info {
                background-color: #d1ecf1 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .text-center {
                text-align: center !important;
                font-size: 7pt !important;
            }
            .text-truncate {
                text-align: center !important;
                font-size: 7pt !important;
            }
            .text-danger {
                color: #991b1b !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .text-light {
                color: #ffffff !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .text-success {
                color:#166534 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .text-warning {
                color: #92400e !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .text-dark {
                color: #1e293b !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            #gradesTable.rq-grades thead tr.rq-row-main th,
            #gradesTable.rq-grades thead th.rq-h-total,
            #gradesTable.rq-grades thead th.rq-h-pct,
            #gradesTable.rq-grades .rq-pill {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            /* --- Professional rq design in browser print (Ctrl+P) --- */
            #gradesTable.rq-grades thead tr.rq-row-main th {
                background-color: #1e293b !important;
                color: #f8fafc !important;
            }
            #gradesTable.rq-grades thead tr.rq-row-main th.rq-h-student {
                background-color: #0f172a !important;
            }
            #gradesTable.rq-grades thead tr.rq-row-quarter th {
                background-color: #f1f5f9 !important;
                color: #475569 !important;
            }
            #gradesTable.rq-grades thead tr.rq-row-assess th.rq-h-assess,
            #gradesTable.rq-grades thead tr.rq-row-hps th.rq-h-hps {
                background-color: #ffffff !important;
                color: #0f172a !important;
            }
            #gradesTable.rq-grades thead th.rq-h-total,
            #gradesTable.rq-grades thead th.rq-h-total-val {
                background-color: #dbe2ec !important;
                color: #334155 !important;
            }
            #gradesTable.rq-grades thead th.rq-h-pct,
            #gradesTable.rq-grades thead th.rq-h-pct-val {
                background-color: #cbd5e1 !important;
                color: #1e293b !important;
            }
            #gradesTable.rq-grades tbody td.rq-total {
                background-color: #e2e8f0 !important;
            }
            #gradesTable.rq-grades tbody td.rq-weighted {
                background-color: #d7dfea !important;
            }
            #gradesTable.rq-grades tbody td.rq-initial-cell {
                background-color: #f8fafc !important;
                color: #0f172a !important;
            }
            #gradesTable.rq-grades tbody td.rq-grade-cell {
                background-color: #ffffff !important;
            }
            #gradesTable.rq-grades .rq-pill,
            #gradesTable.rq-grades .rq-badge,
            #gradesTable.rq-grades .rq-comp-pct {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            /* Signatories section print styles */
            .pt-4 {
                padding-top: 20px !important;
            }
            .row {
                display: flex !important;
                flex-wrap: wrap !important;
                margin-right: -15px !important;
                margin-left: -15px !important;
            }
            /* Table positioning to ensure signatories appear after */
            #outprint {
                position: static !important;
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            #outprint .table-responsive {
                position: static !important;
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
            }
            #outprint .table {
                position: static !important;
                overflow: visible !important;
                max-height: none !important;
                height: auto !important;
                margin-bottom: 30px !important;
            }
            .mt-2 {
                margin-top: 20px !important;
            }
            .mb-4 {
                margin-bottom: 20px !important;
            }
            .mb-1 {
                margin-bottom: 5px !important;
            }
            .fw-bold {
                font-weight: bold !important;
            }
            .bg-opacity-50 {
                opacity: 1 !important;
            }
            /* Ensure tables don't break across pages */
            table { page-break-inside:auto; }
            tr    { page-break-inside:avoid; page-break-after:auto; }
            thead { display:table-header-group; }
            tfoot { display:table-footer-group; }
        }
    </style>
    <style>

            .text-success {
                color:#166534 !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .capital-red {
                color: inherit !important;
                font-weight: inherit;
            }

    </style>

    <!-- Tooltip styles -->
    <style>
    .error-tooltip {
        position: absolute;
        background-color: #dc3545;
        color: white;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 500;
        z-index: 9999;
        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
        white-space: nowrap;
        pointer-events: none;
        opacity: 0;
        transform: translateY(-5px);
        transition: opacity 0.3s ease, transform 0.3s ease;
    }

    .error-tooltip.show {
        opacity: 1;
        transform: translateY(0);
    }

    .error-tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 10%;
        margin-left: -5px;
        border-width: 5px;
        border-style: solid;
        border-color: #dc3545 transparent transparent transparent;
    }

    /* Status-based row coloring - soft professional tints */
    .status-dropped {
        background-color: rgba(185, 28, 28, 0.06) !important;
    }

    .status-nosub {
        background-color: rgba(146, 64, 14, 0.06) !important;
    }

    .status-noexam {
        background-color: rgba(7, 89, 133, 0.06) !important;
    }

    /* Ensure status colors remain on hover */
    .table-hover tbody tr.status-dropped td {
        background-color: rgba(185, 28, 28, 0.06) !important;
    }
    .table-hover tbody tr.status-nosub td {
        background-color: rgba(146, 64, 14, 0.06) !important;
    }
    .table-hover tbody tr.status-noexam td {
        background-color: rgba(7, 89, 133, 0.06) !important;
    }

    .editable-mark.error {
        background-color: #fef2f2 !important;
        outline: 2px solid #dc2626 !important;
        border-radius: 4px !important;
    }

    /* Fast Single Entry toggle (same look as marks.php) */
    .toggle-enter-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        border: none;
        background: transparent;
        cursor: pointer;
        font-weight: bold;
    }
    .toggle-enter-label {
        font-size: 0.8rem;
        text-transform: uppercase;
    }
    .toggle-enter-switch {
        position: relative;
        display: inline-flex;
        align-items: center;
        padding: 4px 12px 4px 4px;
        border-radius: 999px;
        background: #dee2e6;
        transition: background 0.2s ease-in-out;
    }
    .toggle-enter-knob {
        width: 22px;
        height: 16px;
        border-radius: 50%;
        background: white;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        transition: transform 0.2s ease-in-out;
    }
    .toggle-enter-btn.on .toggle-enter-switch {
        background: #0d55fdff;
        color: #ffffff;
    }
    .toggle-enter-btn.on .toggle-enter-knob {
        transform: translateX(16px);
    }
    .toggle-enter-text {
        font-size: 0.75rem;
        margin-left: 6px;
        font-weight: 600;
    }
    /* Selected component / assessment header target */
    #gradesTable th.rq-h-component.rq-fast-selected,
    #gradesTable th.rq-h-assess.rq-fast-selected {
        outline: 2px solid var(--horizon-brand-500, #4318FF) !important;
        outline-offset: -2px;
        background-color: rgba(67, 24, 255, 0.10) !important;
        color: #ffffff !important;
    }
    #gradesTable th.rq-h-component.rq-fast-selected *,
    #gradesTable th.rq-h-assess.rq-fast-selected * {
        
        background-color: rgba(67, 24, 255, 0.10) !important;
        color: #ffffff !important;

    }
    #gradesTable.rq-fast-armed th.rq-h-component,
    #gradesTable.rq-fast-armed th.rq-h-assess {
        cursor: pointer;
    }
    </style>

    <script>
        // Student name search and grade filter functionality
        function filterTable() {
            var searchText = $('#studentSearch').val().toLowerCase().trim();
            var filterFailed = $('#filterGradesAbove3').hasClass('active');

            $('#gradesTable tbody tr').each(function() {
                // Keep non-student placeholder rows (e.g. "No students found")
                // always visible regardless of search/filter state.
                if (!$(this).attr('data-student-id')) {
                    return;
                }

                var firstCell = $(this).find('td:first').text().trim().toLowerCase();
                var lastCell = $(this).find('td:last').text().trim().toLowerCase();

                // Find the student's Initial Grade cell
                var initialGradeCell = $(this).find('td.initial-grade-cell').last();
                var initialGradeText = initialGradeCell.text().trim();

                // Failed student = Initial Grade below the passing mark (75)
                var initialGradeNum = parseFloat(initialGradeText);

                var matchesSearch = searchText === '' || firstCell.includes(searchText) || lastCell.includes(searchText);
                var matchesGradeFilter = !filterFailed || (!isNaN(initialGradeNum) && initialGradeNum < 74.50);

                if (matchesSearch && matchesGradeFilter) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }

        $(document).on('input', '#studentSearch', filterTable);
        $(document).on('click', '#filterGradesAbove3', function() {
            $(this).toggleClass('active');
            if ($(this).hasClass('active')) {
                $(this).removeClass('btn-outline-warning').addClass('btn-warning');
            } else {
                $(this).removeClass('btn-warning').addClass('btn-outline-warning');
            }
            filterTable();
        });

        // Fast Single Entry (reports): arm with the toggle, click a component
        // header cell then a specific assessment header cell. Afterwards,
        // Tab or Enter in the student search box jumps to the first visible
        // editable cell for that component + assessment.
        var rqFast = { on: false, comp: null, assess: null, compName: '', assessName: '' };
        function rqFastArmed(){ return rqFast.on && rqFast.comp !== null && rqFast.assess !== null; }
        function rqFastHint(){
            var $h = $('#rqFastHint');
            if (!$h.length) return;
            if (!rqFast.on) { $h.text('Fast entry off'); return; }
            if (rqFast.comp === null) { $h.text('Step 1: click a component header'); return; }
            if (rqFast.assess === null) { $h.text('Step 2: click an assessment header'); return; }
            $h.text('Target: ' + rqFast.compName + ' › ' + rqFast.assessName + ' — search, then Tab/Enter');
        }
        function rqFastRepaint(){
            var $tbl = $('#gradesTable');
            $tbl.toggleClass('rq-fast-armed', rqFast.on);
            $tbl.find('th.rq-h-component, th.rq-h-assess').removeClass('rq-fast-selected');
            if (rqFast.comp !== null) $tbl.find('th.rq-h-component[data-component-id="' + rqFast.comp + '"]').addClass('rq-fast-selected');
            if (rqFast.assess !== null) $tbl.find('th.rq-h-assess[data-assessment-id="' + rqFast.assess + '"]').addClass('rq-fast-selected');
            rqFastHint();
        }
        function rqFastHeaderText($th, fallbackSel){
            var t = $.trim($th.find(fallbackSel).first().text());
            return t !== '' ? t : $.trim($th.text());
        }
        $(document).on('click', '#rqFastEntryToggle', function(){
            rqFast.on = !rqFast.on;
            $(this).toggleClass('on', rqFast.on).attr('aria-pressed', rqFast.on ? 'true' : 'false');
            if (!rqFast.on) {
                // Toggling off clears the picked component + assessment
                rqFast.comp = null;
                rqFast.assess = null;
                rqFast.compName = '';
                rqFast.assessName = '';
            }
            rqFastRepaint();
        });
        // Step 1: pick the component header cell
        $(document).on('click', '#gradesTable th.rq-h-component', function(){
            if (!rqFast.on) return;
            var cid = String($(this).attr('data-component-id') || '');
            if (cid === '' || cid === 'undefined') return;
            rqFast.comp = cid;
            rqFast.compName = rqFastHeaderText($(this), '.rq-comp-name');
            // A previously picked assessment from another component no longer applies
            var $cur = $('#gradesTable th.rq-h-assess[data-assessment-id="' + rqFast.assess + '"]');
            if (rqFast.assess === null || String($cur.attr('data-component-id') || '') !== cid) {
                rqFast.assess = null;
                rqFast.assessName = '';
            }
            rqFastRepaint();
        });
        // Step 2: pick the specific assessment header cell (implies its component)
        $(document).on('click', '#gradesTable th.rq-h-assess', function(){
            if (!rqFast.on) return;
            var aid = String($(this).attr('data-assessment-id') || '');
            if (aid === '' || aid === 'undefined') return;
            rqFast.assess = aid;
            rqFast.assessName = rqFastHeaderText($(this), '.rq-assess-name');
            var ccid = String($(this).attr('data-component-id') || '');
            if (ccid !== '' && ccid !== 'undefined') {
                rqFast.comp = ccid;
                var $compHead = $('#gradesTable th.rq-h-component[data-component-id="' + ccid + '"]');
                if ($compHead.length) rqFast.compName = rqFastHeaderText($compHead, '.rq-comp-name');
            }
            rqFastRepaint();
        });
        function rqFastFocusCell($cell){
            if (!$cell || !$cell.length) return false;
            $cell.focus();
            try {
                var range = document.createRange();
                range.selectNodeContents($cell[0]);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            } catch (err) {}
            try { $cell[0].scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (err) {}
            return true;
        }
        // Tab / Enter in the search box jumps to the first visible editable
        // cell of the selected component + assessment. Left alone when the
        // feature is not fully armed so normal Tab order is preserved.
        $(document).on('keydown', '#studentSearch', function(e){
            if (e.key !== 'Enter' && e.key !== 'Tab') return;
            if (!rqFastArmed()) return;
            e.preventDefault();
            var sel = '[data-component-id="' + rqFast.comp + '"][data-assessment-id="' + rqFast.assess + '"][contenteditable="true"]';
            var $cell = $();
            $('#gradesTable tbody tr').each(function(){
                var $row = $(this);
                if (!$row.is(':visible') || !$row.attr('data-student-id')) return;
                var $c = $row.find('td.editable-mark' + sel).first();
                if ($c.length) { $cell = $c; return false; }
            });
            if ($cell.length) {
                rqFastFocusCell($cell);
            } else if (window.showAppToast) {
                window.showAppToast('warning', 'No editable cell found for the selected component and assessment.');
            }
        });
        // Fast-entry loop: Tab / Enter inside an editable mark cell saves
        // the mark, refreshes the row totals/grades, then hands focus back
        // to the search box (cleared) for the next student. Registered
        // before the default cell handlers so it can suppress the
        // down-column move while fast entry is ON.
        $(document).on('keydown', '#gradesTable td.editable-mark', function(e){
            if (!rqFast.on) return;
            if (e.key !== 'Enter' && e.key !== 'Tab') return;
            e.preventDefault();
            e.stopImmediatePropagation();
            var $cell = $(this);
            var studentId = $cell.data('student-id');
            var assessmentId = $cell.data('assessment-id');
            var classId = $cell.data('class-id');
            var quarter = $cell.data('quarter');
            var raw = $cell.text().trim();
            if (raw === '') raw = '0';
            if (isNaN(raw)) {
                showErrorTooltip($cell, 'Please enter a valid number');
                return;
            }
            var mark = parseFloat(raw);
            var hps = (typeof assessmentHPS !== 'undefined') ? assessmentHPS[assessmentId] : null;
            if (hps && mark > hps) {
                showErrorTooltip($cell, 'Score cannot exceed HPS: ' + hps);
                $cell.text('');
                return;
            }
            mark = mark.toFixed(2);
            $cell.text(mark);
            $.ajax({
                url: 'update_mark.php',
                type: 'POST',
                data: { student_id: studentId, assessment_id: assessmentId, class_id: classId, quarter: quarter, mark: mark },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        updateRowCalculations(studentId, classId, quarter, function() {
                            var $sb = $('#studentSearch');
                            if ($sb.length) {
                                $sb.val('');
                                $sb.focus();
                                try { filterTable(); } catch (err) {}
                            }
                        });
                    } else {
                        alert('Error updating mark: ' + (response.message || 'Unknown error'));
                    }
                },
                error: function() {
                    alert('Error updating mark. Please try again.');
                }
            });
        });
        rqFastHint();

        // Initialize assessment HPS data for validation
        var assessmentHPS = <?php
            $hps_data = [];
            if (isset($assess)) {
                foreach ($assess as $component_id => $assessments) {
                    foreach ($assessments as $assessment_id => $assessment) {
                        $hps_data[$assessment_id] = $assessment['hps'];
                    }
                }
            }
            echo json_encode($hps_data);
        ?>;

        // Function to show error tooltip
        function showErrorTooltip($cell, message) {
            // Remove any existing tooltips
            $('.error-tooltip').remove();

            // Remove error class from all cells
            $('.editable-mark').removeClass('error');

            // Add error class to current cell
            $cell.addClass('error');

            // Create tooltip element
            var $tooltip = $('<div class="error-tooltip">' + message + '</div>');

            // Position the tooltip above the cell
            var cellPosition = $cell.offset();
            var cellWidth = $cell.outerWidth();
            var cellHeight = $cell.outerHeight();

            $tooltip.css({
                left: cellPosition.left + (cellWidth / 2) - ($tooltip.outerWidth() / 2),
                top: cellPosition.top - $tooltip.outerHeight() - 10
            });

            // Add to body and show with animation
            $('body').append($tooltip);

            // Trigger reflow for animation
            $tooltip[0].offsetHeight;
            $tooltip.addClass('show');

            // Auto-hide after 3 seconds
            setTimeout(function() {
                $tooltip.removeClass('show');
                setTimeout(function() {
                    $tooltip.remove();
                    $cell.removeClass('error');
                }, 300);
            }, 3000);

            // Hide when user starts typing again
            $cell.on('input', function() {
                $tooltip.removeClass('show');
                setTimeout(function() {
                    $tooltip.remove();
                    $cell.removeClass('error');
                }, 300);
            });

            // Hide when cell loses focus (if not already being handled)
            $cell.on('blur', function() {
                setTimeout(function() {
                    $tooltip.removeClass('show');
                    setTimeout(function() {
                        $tooltip.remove();
                        $cell.removeClass('error');
                    }, 300);
                }, 100);
            });
        }

            // Function to update mark via AJAX
        function updateMark(studentId, assessmentId, classId, quarter, mark) {
            $.ajax({
                url: 'update_mark.php',
                type: 'POST',
                data: {
                    student_id: studentId,
                    assessment_id: assessmentId,
                    class_id: classId,
                    quarter: quarter,
                    mark: mark
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        // Show success message or update UI as needed
                        console.log('Mark updated successfully');
                        // Update calculations dynamically and then focus next cell
                        updateRowCalculations(studentId, classId, quarter, function() {
                            // After row update, focus on the next cell below
                            focusNextCellBelow(studentId, assessmentId);
                        });
                    } else {
                        alert('Error updating mark: ' + response.message);
                        window.location.reload();
                    }
                },
                error: function() {
                    alert('Error updating mark. Please try again.');
                    window.location.reload();
                }
            });
        }

        // Track if focus change is automatic (from Enter key) or manual (user click)
        var isAutomaticFocus = false;
        var $currentEditingCell = null;

        // Function to update row calculations dynamically
        function updateRowCalculations(studentId, classId, quarter, callback) {
            console.log('Updating row calculations for student:', studentId, 'class:', classId, 'quarter:', quarter);

            // Check if this is active quarters view
            var is_active_quarters = window.location.search.includes('quarter=active');

            if (is_active_quarters) {
                console.log('Active quarters view detected - using specialized update');
                // For active quarters, use a different endpoint or modify the data
                $.ajax({
                    url: 'get_student_row_data.php',
                    type: 'POST',
                    data: {
                        student_id: studentId,
                        class_id: classId,
                        quarter: 'active' // Special parameter for active quarters
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Active quarters AJAX response:', response);
                        if (response.status === 'success') {
                            // Update the row with new data
                            var $row = $('tr[data-student-id="' + studentId + '"]');
                            console.log('Found row:', $row.length > 0);
                            if ($row.length > 0 && response.row_html) {
                                // Store the current focus before replacing
                                var $focusedElement = $(document.activeElement);
                                var focusSelector = '';

                                if ($focusedElement.length && $focusedElement.closest('tr').is($row)) {
                                    focusSelector = '.editable-mark[data-assessment-id="' + $focusedElement.data('assessment-id') + '"]';
                                }

                                $row.replaceWith(response.row_html);
                                console.log('Active quarters row updated successfully');

                                // Apply status class if provided in response
                                if (response.student_status) {
                                    var $newRow = $('tr[data-student-id="' + studentId + '"]');
                                    $newRow.removeClass('status-dropped status-nosub status-noexam');
                                    if (response.student_status === 'Dropped') {
                                        $newRow.addClass('status-dropped');
                                    } else if (response.student_status === 'NoSub') {
                                        $newRow.addClass('status-nosub');
                                    } else if (response.student_status === 'NoExam') {
                                        $newRow.addClass('status-noexam');
                                    }
                                }

                                // Restore focus if we had it
                                if (focusSelector) {
                                    var $newRow = $('tr[data-student-id="' + studentId + '"]');
                                    var $newFocusedElement = $newRow.find(focusSelector);
                                    if ($newFocusedElement.length) {
                                        $newFocusedElement.focus();
                                        // Move cursor to end
                                        var text = $newFocusedElement.text();
                                        $newFocusedElement.text('').text(text);
                                    }
                                }

                                // Execute callback if provided
                                if (typeof callback === 'function') {
                                    callback();
                                }
                            }
                        } else {
                            console.error('Error updating active quarters row calculations:', response.message);
                            // For active quarters, fallback to just executing callback
                            if (typeof callback === 'function') {
                                callback();
                            }
                        }
                    },
                    error: function() {
                        console.error('AJAX error for active quarters - executing callback');
                        // For active quarters, fallback to just executing callback
                        if (typeof callback === 'function') {
                            callback();
                        }
                    }
                });
                return;
            }

            // Get updated row data via AJAX (only for single quarter view)
            $.ajax({
                url: 'get_student_row_data.php',
                type: 'POST',
                data: {
                    student_id: studentId,
                    class_id: classId,
                    quarter: quarter
                },
                dataType: 'json',
                success: function(response) {
                    console.log('AJAX response:', response);
                    if (response.status === 'success') {
                        // Update the row with new data
                        var $row = $('tr[data-student-id="' + studentId + '"]');
                        console.log('Found row:', $row.length > 0);
                        if ($row.length > 0 && response.row_html) {
                            // Store the current focus before replacing
                            var $focusedElement = $(document.activeElement);
                            var focusSelector = '';

                            if ($focusedElement.length && $focusedElement.closest('tr').is($row)) {
                                focusSelector = '.editable-mark[data-assessment-id="' + $focusedElement.data('assessment-id') + '"]';
                            }

                            $row.replaceWith(response.row_html);
                            console.log('Row updated successfully');

                            // Apply status class if provided in response
                            if (response.student_status) {
                                var $newRow = $('tr[data-student-id="' + studentId + '"]');
                                $newRow.removeClass('status-dropped status-nosub status-noexam');
                                if (response.student_status === 'Dropped') {
                                    $newRow.addClass('status-dropped');
                                } else if (response.student_status === 'NoSub') {
                                    $newRow.addClass('status-nosub');
                                } else if (response.student_status === 'NoExam') {
                                    $newRow.addClass('status-noexam');
                                }
                            }

                            // Restore focus if we had it
                            if (focusSelector) {
                                var $newRow = $('tr[data-student-id="' + studentId + '"]');
                                var $newFocusedElement = $newRow.find(focusSelector);
                                if ($newFocusedElement.length) {
                                    $newFocusedElement.focus();
                                    // Move cursor to end
                                    var text = $newFocusedElement.text();
                                    $newFocusedElement.text('').text(text);
                                }
                            }

                            // Execute callback if provided
                            if (typeof callback === 'function') {
                                callback();
                            }
                        }
                    } else {
                        console.error('Error updating row calculations:', response.message);
                        // Fallback to page reload if AJAX fails

                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error updating row calculations');
                    console.error('Status:', status);
                    console.error('Error:', error);
                    console.error('Response:', xhr.responseText);
                    // Fallback to page reload if AJAX fails

                }
            });
        }

        // Function to focus on the next cell below
        function focusNextCellBelow(currentStudentId, currentAssessmentId) {
            // Try multiple times to find and focus the next cell
            var attempts = 0;
            var maxAttempts = 10;

            function tryFocus() {
                attempts++;
                var $currentRow = $('tr[data-student-id="' + currentStudentId + '"]');
                var $currentCell = $currentRow.find('.editable-mark[data-assessment-id="' + currentAssessmentId + '"]');

                if ($currentCell.length === 0) {
                    console.log('Current cell not found, attempt:', attempts);
                    if (attempts < maxAttempts) {
                        setTimeout(tryFocus, 50);
                    }
                    return;
                }

                // Find the next row
                var $nextRow = $currentRow.next('tr');

                if ($nextRow.length > 0) {
                    // Look for the cell with the same assessment_id in the next row
                    var $nextCell = $nextRow.find('.editable-mark[data-assessment-id="' + currentAssessmentId + '"]');

                    if ($nextCell.length > 0) {
                        $nextCell.focus();
                        // Select all text in the next cell
                        var range = document.createRange();
                        var sel = window.getSelection();
                        range.selectNodeContents($nextCell[0]);
                        sel.removeAllRanges();
                        sel.addRange(range);
                        console.log('Successfully focused on next cell with assessment_id:', currentAssessmentId);
                    } else {
                        console.log('Next cell not found with assessment_id:', currentAssessmentId);
                        // Fallback: try to find by column index
                        var currentColumnIndex = $currentCell.closest('td').index();
                        var $fallbackCell = $nextRow.find('td').eq(currentColumnIndex).find('.editable-mark');
                        if ($fallbackCell.length > 0) {
                            $fallbackCell.focus();
                            var range = document.createRange();
                            var sel = window.getSelection();
                            range.selectNodeContents($fallbackCell[0]);
                            sel.removeAllRanges();
                            sel.addRange(range);
                            console.log('Successfully focused using fallback column index:', currentColumnIndex);
                        } else {
                            console.log('Fallback also failed - no editable cell found in column:', currentColumnIndex);
                        }
                    }
                } else {
                    console.log('No next row found');
                }
            }

            // Start trying to focus
            setTimeout(tryFocus, 50);
        }

        // Handle mark editing
        $(document).on('blur', '.editable-mark', function() {
            var $cell = $(this);

            // Clear current editing cell
            if ($currentEditingCell && $currentEditingCell.is($cell)) {
                $currentEditingCell = null;
            }

            // Only proceed with automatic focus if this was triggered by Enter key
            if (!isAutomaticFocus) {
                return;
            }

            // Reset the flag
            isAutomaticFocus = false;

            var studentId = $cell.data('student-id');
            var assessmentId = $cell.data('assessment-id');
            var classId = $cell.data('class-id');
            var quarter = $cell.data('quarter');
            var mark = $cell.text().trim();

            // Validate mark is a number
            if (isNaN(mark) || mark === '') {
                showErrorTooltip($cell, 'Please enter a valid number');
                return;
            }

            // Convert to float and check against HPS
            mark = parseFloat(mark);
            var assessmentId = $cell.data('assessment-id');
            var hps = assessmentHPS[assessmentId];

            if (hps && mark > hps) {
                showErrorTooltip($cell, 'Score cannot exceed HPS: ' + hps);
                // Reset to previous valid value or 0
                $cell.text('');
                return;
            }

            // Round to 2 decimal places
            mark = mark.toFixed(2);

            // Update the cell with formatted number
            $cell.text(mark);

            // Call the update function
            updateMark(studentId, assessmentId, classId, quarter, mark);
        });

        // Handle mouse click on editable cells
        $(document).on('mousedown', '.editable-mark', function(e) {
            var $clickedCell = $(this);

            // If we're currently editing a different cell, save it first
            if ($currentEditingCell && !$currentEditingCell.is($clickedCell)) {
                e.preventDefault(); // Prevent default focus behavior

                // Clear current editing cell and let blur handle the save
                $currentEditingCell = null;

                // Focus the clicked cell after a short delay to let blur complete
                setTimeout(function() {
                    $clickedCell.focus();
                }, 50);
            } else {
                // Track this cell as the current editing cell
                $currentEditingCell = $clickedCell;
            }
        });

        // Function to update mark and then focus a specific cell
        function updateMarkAndFocusCell(studentId, assessmentId, classId, quarter, mark, $targetCell) {
            $.ajax({
                url: 'update_mark.php',
                type: 'POST',
                data: {
                    student_id: studentId,
                    assessment_id: assessmentId,
                    class_id: classId,
                    quarter: quarter,
                    mark: mark
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        console.log('Mark updated successfully');
                        // Update calculations dynamically and then focus target cell
                        updateRowCalculationsAndFocus(studentId, classId, quarter, $targetCell);
                    } else {
                        alert('Error updating mark: ' + response.message);
                    }
                },
                error: function() {
                    alert('Error updating mark. Please try again.');
                    window.location.reload();
                }
            });
        }

        // Function to update row calculations and focus a specific cell
        function updateRowCalculationsAndFocus(studentId, classId, quarter, $targetCell) {
            console.log('Updating row calculations for student:', studentId, 'class:', classId, 'quarter:', quarter);

            // Check if this is active quarters view
            var is_active_quarters = window.location.search.includes('quarter=active');

            if (is_active_quarters) {
                console.log('Active quarters view detected - using specialized update with focus');
                // For active quarters, use the same approach as updateRowCalculations but with focus
                $.ajax({
                    url: 'get_student_row_data.php',
                    type: 'POST',
                    data: {
                        student_id: studentId,
                        class_id: classId,
                        quarter: 'active' // Special parameter for active quarters
                    },
                    dataType: 'json',
                    success: function(response) {
                        console.log('Active quarters AJAX response for focus:', response);
                        if (response.status === 'success') {
                            // Update the row with new data
                            var $row = $('tr[data-student-id="' + studentId + '"]');
                            console.log('Found row:', $row.length > 0);
                            if ($row.length > 0 && response.row_html) {
                                $row.replaceWith(response.row_html);
                                console.log('Active quarters row updated successfully');

                                // Apply status class if provided in response
                                if (response.student_status) {
                                    var $newRow = $('tr[data-student-id="' + studentId + '"]');
                                    $newRow.removeClass('status-dropped status-nosub status-noexam');
                                    if (response.student_status === 'Dropped') {
                                        $newRow.addClass('status-dropped');
                                    } else if (response.student_status === 'NoSub') {
                                        $newRow.addClass('status-nosub');
                                    } else if (response.student_status === 'NoExam') {
                                        $newRow.addClass('status-noexam');
                                    }
                                }

                                // Focus the target cell after row replacement with delay to ensure DOM is ready
                                setTimeout(function() {
                                    var targetAssessmentId = $targetCell.data('assessment-id');
                                    var targetQuarter = $targetCell.data('quarter');
                                    var $newTargetCell;

                                    if (targetQuarter) {
                                        // For active quarters, find by both assessment-id and quarter
                                        $newTargetCell = $('tr[data-student-id="' + studentId + '"]').find('[data-assessment-id="' + targetAssessmentId + '"][data-quarter="' + targetQuarter + '"]');
                                    } else {
                                        // For single quarter, find by assessment-id only
                                        $newTargetCell = $('tr[data-student-id="' + studentId + '"]').find('[data-assessment-id="' + targetAssessmentId + '"]');
                                    }

                                    if ($newTargetCell.length > 0) {
                                        $newTargetCell.focus();
                                        console.log('Successfully focused on target cell after row replacement');
                                    } else {
                                        console.log('Target cell not found after row replacement, trying fallback');
                                        // Fallback: try to focus on original target cell
                                        $targetCell.focus();
                                    }
                                }, 100); // Small delay to ensure DOM is updated
                            }
                        }
                    },
                    error: function() {
                        console.error('AJAX error for active quarters - focusing target cell directly');
                        // Fallback: just focus the target cell
                        $targetCell.focus();
                    }
                });
                return;
            }

            // Original single quarter logic
            $.ajax({
                url: 'get_student_row_data.php',
                type: 'POST',
                data: {
                    student_id: studentId,
                    class_id: classId,
                    quarter: quarter
                },
                dataType: 'json',
                success: function(response) {
                    console.log('AJAX response:', response);
                    if (response.status === 'success') {
                        // Update the row with new data
                        var $row = $('tr[data-student-id="' + studentId + '"]');
                        console.log('Found row:', $row.length > 0);
                        if ($row.length > 0 && response.row_html) {
                            $row.replaceWith(response.row_html);
                            console.log('Row updated successfully');

                            // Focus the target cell after row update
                            setTimeout(function() {
                                focusSpecificCell($targetCell);
                            }, 100);
                        }
                    } else {
                        console.error('Error updating row:', response.message);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', error);
                    alert('Error updating row calculations. Please try again.');
                }
            });
        }

        // Function to focus a specific cell
        function focusSpecificCell($targetCell) {
            // Find the cell again in case it was replaced during row update
            var targetStudentId = $targetCell.data('student-id');
            var targetAssessmentId = $targetCell.data('assessment-id');

            var $updatedCell = $('tr[data-student-id="' + targetStudentId + '"] .editable-mark[data-assessment-id="' + targetAssessmentId + '"]');

            if ($updatedCell.length > 0) {
                $updatedCell.focus();
                // Select all text in the cell
                var range = document.createRange();
                var sel = window.getSelection();
                range.selectNodeContents($updatedCell[0]);
                sel.removeAllRanges();
                sel.addRange(range);
                console.log('Successfully focused on target cell');

                // Update current editing cell
                $currentEditingCell = $updatedCell;
            } else {
                console.log('Target cell not found after row update');
            }
        }

        // Prevent newlines in editable cells — Enter or Tab saves the mark
        // and refreshes the row (totals / initial / transmuted). Fast-entry
        // mode is handled above and suppresses this path via
        // stopImmediatePropagation.
        $(document).on('keydown', '.editable-mark', function(e) {
            var isEnter = e.key === 'Enter' || e.keyCode === 13;
            var isTab = e.key === 'Tab' || e.keyCode === 9;
            if (!isEnter && !isTab) return;
            e.preventDefault();
            var $cell = $(this);
            var studentId = $cell.data('student-id');
            var assessmentId = $cell.data('assessment-id');

            // Track this cell as current editing
            $currentEditingCell = $cell;

            // Set flag to indicate this is an automatic focus change
            isAutomaticFocus = true;

            // Blur current cell to save changes and move to next cell
            $cell.blur();

            // Focus on next cell below after a short delay to allow row update
            setTimeout(function() {
                focusNextCellBelow(studentId, assessmentId);
            }, 300);
        });

        // Real-time validation while typing
        $(document).on('input', '.editable-mark', function() {
            var $cell = $(this);
            var currentValue = $cell.text().trim();
            var assessmentId = $cell.data('assessment-id');
            var hps = assessmentHPS[assessmentId];

            // Remove any existing error styling
            $cell.removeClass('error');
            $('.error-tooltip').remove();

            // Only validate if there's a value and it's a complete number
            if (currentValue !== '' && !isNaN(currentValue)) {
                var mark = parseFloat(currentValue);

                // Check against HPS
                if (hps && mark > hps) {
                    showErrorTooltip($cell, 'Score cannot exceed HPS: ' + hps);
                }
            }
        });

        // Handle input to only accept numbers
        $(document).on('input', '.editable-mark', function(e) {
            var $this = $(this);
            var currentValue = $this.text();

            // Remove any non-numeric characters except decimal point
            var numericValue = currentValue.replace(/[^0-9.]/g, '');

            // Ensure only one decimal point
            var parts = numericValue.split('.');
            if (parts.length > 2) {
                numericValue = parts[0] + '.' + parts.slice(1).join('');
            }

            // Update the cell content if it changed
            if (currentValue !== numericValue) {
                $this.text(numericValue);

                // Position cursor at the end after cleaning
                var range = document.createRange();
                var sel = window.getSelection();
                var textNode = $this[0].childNodes[0];
                if (textNode && textNode.nodeType === Node.TEXT_NODE) {
                    range.setStart(textNode, numericValue.length);
                    range.setEnd(textNode, numericValue.length);
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
        });

        // Handle blur event to restore 0 if cell is empty
        $(document).on('blur', '.editable-mark', function() {
            var $this = $(this);
            var currentValue = $this.text().trim();

            // If cell is empty, restore to 0
            if (currentValue === '') {
                $this.text('0');
            }
        });

        // Track when cells gain focus
        $(document).on('focus', '.editable-mark', function() {
            $currentEditingCell = $(this);

            // Clear cell if value is 0
            var $this = $(this);
            var text = $this.text().trim();

            if (text === '0') {
                $this.text('');
                // Position cursor in the middle since we cleared it
                var range = document.createRange();
                var sel = window.getSelection();
                var textNode = document.createTextNode('');
                $this[0].appendChild(textNode);
                range.setStart(textNode, 0);
                range.setEnd(textNode, 0);
                sel.removeAllRanges();
                sel.addRange(range);
            } else {
                // Position cursor at the end and select all content
                var length = text.length;

                // Create a range and set cursor position to the end
                var range = document.createRange();
                var sel = window.getSelection();

                if ($this[0].childNodes.length > 0) {
                    // Find the last text node
                    var lastChild = $this[0].childNodes[$this[0].childNodes.length - 1];
                    if (lastChild.nodeType === Node.TEXT_NODE) {
                        // Select all content and position cursor at end
                        range.selectNodeContents(lastChild);
                        range.collapse(false); // false collapses to end
                    } else {
                        // If no text node, create one
                        var textNode = document.createTextNode('');
                        $this[0].appendChild(textNode);
                        range.setStart(textNode, 0);
                        range.setEnd(textNode, 0);
                    }
                } else {
                    // If no child nodes, create a text node
                    var textNode = document.createTextNode('');
                    $this[0].appendChild(textNode);
                    range.setStart(textNode, 0);
                    range.setEnd(textNode, 0);
                }

                sel.removeAllRanges();
                sel.addRange(range);
            }
        });

        $(function(){
            // Initialize modal
            var signatoryModal = new bootstrap.Modal(document.getElementById('signatoryModal'));

            // Handle signatory modal open
            $('#addSignatory').click(function(){
                // Reset form
                $('#signatoryForm')[0].reset();
                signatoryModal.show();
            });

            // Handle signatory type change to populate fields with existing data
            $('#signatoryType').change(function(){
                var selectedType = $(this).val();

                // Get existing signatories data from the page
                var signatories = {};
                $('.col-md-4.text-center').each(function() {
                    var title = $(this).find('h6').text().replace(':', '').trim();
                    var type = '';

                    // Determine the type based on title
                    if (title.includes('CERTIFIED')) type = 'certified';
                    else if (title.includes('CHECKED')) type = 'checked';
                    else if (title.includes('NOTED')) type = 'noted';
                    else if (title.includes('RECEIVED')) type = 'received';

                    if (type) {
                        // Get the name from the border-bottom div
                        var name = $(this).find('div[style*="border-bottom"] > div').first().text().trim();

                        // Get the designation from the .fw-bold element
                        var designation = $(this).find('.fw-bold').first().text().trim();

                        // Clean up the designation text
                        designation = designation.replace(/\s+/g, ' ').trim();

                        // If we couldn't find a designation or it's the default text, use empty string
                        if (!designation || designation === 'Designation') {
                            designation = '';
                        }

                        // If we couldn't find a name, use empty string
                        if (!name) {
                            name = '';
                        }

                        signatories[type] = {
                            fullname: name,
                            designation: designation
                        };
                    }
                });

                // Populate fields if signatory data exists for selected type
                if (signatories[selectedType]) {
                    $('#fullName').val(signatories[selectedType].fullname);
                    $('#designation').val(signatories[selectedType].designation);
                } else {
                    // Clear fields if no existing data
                    $('#fullName').val('');
                    $('#designation').val('');
                }
            });

            // Handle save signatory
            $('#saveSignatory').click(function(){
                var $btn = $(this);
                var fullName = $('#fullName').val().trim();
                var designation = $('#designation').val().trim();
                var signatoryType = $('#signatoryType').val();

                // Basic validation
                if(!designation) {
                    alert("Please fill in all required fields.");
                    return false;
                }

                // Show loading state
                var originalText = $btn.html();
                $btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...');

                // Send AJAX request
                $.ajax({
                    url: 'Actions.php?a=save_signatory',
                    method: 'POST',
                    data: {
                        fullname: fullName,
                        designation: designation,
                        type: signatoryType
                    },
                    dataType: 'json',
                    success: function(resp) {
                        if(resp.status === 'success') {
                            // Show success message
                            alert("Signatory saved successfully!");
                            // Close modal and reload page
                            signatoryModal.hide();
                            location.reload();
                        } else {
                            // Show error message
                            alert(resp.msg || "An error occurred while saving the signatory.");
                            // Re-enable button
                            $btn.prop('disabled', false).html(originalText);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("Error:", xhr.responseText);
                        alert("An error occurred while saving the signatory. Please check the console for details.");
                        // Re-enable button
                        $btn.prop('disabled', false).html(originalText);
                    }
                });
            });

            $('#signatoryForm input, #signatoryForm select').on('keypress', function(e) {
                if (e.which === 13) { // Enter key
                    e.preventDefault(); // Prevent default form submission
                    $('#saveSignatory').click(); // Trigger save button click
                }
            });

            // Close modal handler to reset form
            $('#signatoryModal').on('hidden.bs.modal', function () {
                $('#signatoryForm')[0].reset();
            });

            function loadReport(classId, quarter) {
                if(!classId || !quarter){
                    alert("Please select quarter, subject, and section first.");
                    return;
                }
                location.href = "./?page=reports&class_id=" + classId + "&quarter=" + quarter;
            }

            function parseTabQuarters($tab) {
                var availableQuarters = $tab.data('quarters');

                if (typeof availableQuarters === 'string') {
                    try {
                        availableQuarters = JSON.parse(availableQuarters);
                    } catch (e) {
                        availableQuarters = [];
                    }
                }

                return Array.isArray(availableQuarters) ? availableQuarters.map(String) : [];
            }

            function tabMatchesQuarter($tab, quarter) {
                var availableQuarters = parseTabQuarters($tab);

                if (!quarter) {
                    return false;
                }

                if (quarter === 'active') {
                    return availableQuarters.length > 0;
                }

                return availableQuarters.includes(String(quarter));
            }

            function updateSubjectTabs() {
                var quarter = $('#quarter').val();
                var selectedSubjectId = String($('#subject_id').val() || '');
                var visibleSubjectIds = [];

                if (!quarter) {
                    $('#subjectTabsWrapper, #sectionTabsWrapper').addClass('d-none');
                    $('#subjectTabsEmptyState, #sectionTabsEmptyState').addClass('d-none');
                    $('.report-subject-tab, .report-section-tab').removeClass('active');
                    $('#subject_id, #class_id').val('');
                    return { visibleSubjectIds: [], selectedSubjectVisible: false };
                }

                $('.report-subject-tab').each(function(){
                    var $tab = $(this);
                    var isVisible = tabMatchesQuarter($tab, quarter);
                    var subjectId = String($tab.data('subject-id'));

                    $tab.toggleClass('d-none', !isVisible);

                    if (isVisible) {
                        visibleSubjectIds.push(subjectId);
                    } else if (subjectId === selectedSubjectId) {
                        $tab.removeClass('active');
                    }
                });

                var selectedSubjectVisible = visibleSubjectIds.includes(selectedSubjectId);
                $('#subjectTabsWrapper').removeClass('d-none');
                $('#subjectTabsEmptyState').toggleClass('d-none', visibleSubjectIds.length > 0);
                $('#sectionTabsWrapper').addClass('d-none');
                $('#sectionTabsEmptyState').addClass('d-none');

                if (!selectedSubjectVisible) {
                    $('#subject_id').val('');
                    $('#class_id').val('');
                }

                return {
                    visibleSubjectIds: visibleSubjectIds,
                    selectedSubjectVisible: selectedSubjectVisible
                };
            }

            function updateSectionTabs() {
                var quarter = $('#quarter').val();
                var selectedSubjectId = String($('#subject_id').val() || '');
                var selectedClassId = String($('#class_id').val() || '');
                var visibleSectionIds = [];

                if (!quarter || !selectedSubjectId) {
                    $('#sectionTabsWrapper').addClass('d-none');
                    $('#sectionTabsEmptyState').addClass('d-none');
                    $('.report-section-tab').removeClass('active');
                    $('#class_id').val('');
                    return { visibleSectionIds: [], selectedSectionVisible: false };
                }

                $('.report-section-tab').each(function(){
                    var $tab = $(this);
                    var subjectId = String($tab.data('subject-id'));
                    var classId = String($tab.data('class-id'));
                    var isVisible = subjectId === selectedSubjectId && tabMatchesQuarter($tab, quarter);

                    $tab.toggleClass('d-none', !isVisible);

                    if (isVisible) {
                        visibleSectionIds.push(classId);
                    } else if (classId === selectedClassId) {
                        $tab.removeClass('active');
                    }
                });

                var selectedSectionVisible = visibleSectionIds.includes(selectedClassId);
                $('#sectionTabsWrapper').removeClass('d-none');
                $('#sectionTabsEmptyState').toggleClass('d-none', visibleSectionIds.length > 0);

                if (!selectedSectionVisible) {
                    $('#class_id').val('');
                }

                return {
                    visibleSectionIds: visibleSectionIds,
                    selectedSectionVisible: selectedSectionVisible
                };
            }

            function activateSubject(subjectId) {
                $('#subject_id').val(subjectId);
                $('.report-subject-tab').removeClass('active');
                $('.report-subject-tab[data-subject-id="' + subjectId + '"]').addClass('active');
            }

            function activateSection(classId) {
                $('#class_id').val(classId);
                $('.report-section-tab').removeClass('active');
                $('.report-section-tab[data-class-id="' + classId + '"]').addClass('active');
                // Refresh the quarter dropdown labels for this class's custom names.
                if (typeof window.applyReportQuarterOptions === 'function') {
                    window.applyReportQuarterOptions(classId);
                }
            }

            function initializeTabFlow(autoLoadFirstSection) {
                var quarter = $('#quarter').val();
                var subjectResult = updateSubjectTabs();
                var currentSubjectId = String($('#subject_id').val() || '');

                if (!subjectResult.selectedSubjectVisible && subjectResult.visibleSubjectIds.length > 0) {
                    currentSubjectId = subjectResult.visibleSubjectIds[0];
                    activateSubject(currentSubjectId);
                }

                var sectionResult = updateSectionTabs();
                var currentClassId = String($('#class_id').val() || '');

                if (!sectionResult.selectedSectionVisible && sectionResult.visibleSectionIds.length > 0) {
                    currentClassId = sectionResult.visibleSectionIds[0];
                    activateSection(currentClassId);
                }

                if (autoLoadFirstSection && quarter && currentClassId) {
                    loadReport(currentClassId, quarter);
                }
            }

            initializeTabFlow(false);

            // Ensure the dropdown reflects the custom quarter names of the class
            // currently loaded (URL) or auto-picked by the tab flow above. When the
            // URL has no class (fresh landing from the nav menu), fall back to the
            // last class used - so renames made in Marks show up right away.
            if (typeof window.applyReportQuarterOptions === 'function') {
                var rqInitClass = $('#class_id').val();
                if (!rqInitClass) {
                    try { rqInitClass = localStorage.getItem('rq_last_class_id') || ''; } catch (e) { rqInitClass = ''; }
                }
                window.applyReportQuarterOptions(rqInitClass);
            }

            $('#quarter').on('change', function(){
                initializeTabFlow(true);
            });

            $(document).on('click', '.report-subject-tab', function(){
                var quarter = $('#quarter').val();
                if(!quarter){
                    alert("Please select quarter first.");
                    return;
                }

                var subjectId = String($(this).data('subject-id'));
                activateSubject(subjectId);

                var sectionResult = updateSectionTabs();
                if (sectionResult.visibleSectionIds.length > 0) {
                    activateSection(sectionResult.visibleSectionIds[0]);
                }
            });

            $(document).on('click', '.report-section-tab', function(){
                var quarter = $('#quarter').val();
                var classId = $(this).data('class-id');

                if(!quarter){
                    alert("Please select quarter first.");
                    return;
                }

                activateSection(String(classId));
                loadReport(classId, quarter);
            });

            $('#filter').click(function(){
                var class_id = $('#class_id').val();
                var quarter = $('#quarter').val();
                loadReport(class_id, quarter);
            });

            $('#transmuted_table').click(function(){
                uni_modal('Transmutation Table', 'transmutation_table.php', 'mid-large');
            });

            $('#print').click(function(){
                // Create a new window for printing
                var printWindow = window.open('', '_blank');

                // Get the current date
                var currentDate = new Date().toLocaleDateString();

                // Get the report title and class info
                var title = "CLASS RECORDS";
                var classInfo = $('.report-section-tab.active').text().trim();
                var quarter = $('#quarter option:selected').text();
                var subject = $('.report-subject-tab.active').text().trim();

                // Get the signatories data first
                var signatories = {};
                $('.col-md-4.text-center').each(function() {
                    var title = $(this).find('h6').text().replace(':', '').trim();
                    var type = '';

                    // Determine the type based on title
                    if (title.includes('CERTIFIED')) type = 'certified';
                    else if (title.includes('CHECKED')) type = 'checked';
                    else if (title.includes('NOTED')) type = 'noted';
                    else if (title.includes('RECEIVED')) type = 'received';

                    if (type) {
                        // Get the name from the border-bottom div
                        var name = $(this).find('div[style*="border-bottom"] > div').first().text().trim();

                        // Get the designation from the .fw-bold element
                        var designation = $(this).find('.fw-bold').first().text().trim();

                        // Clean up the designation text (remove any extra whitespace or newlines)
                        designation = designation.replace(/\s+/g, ' ').trim();

                        // If we couldn't find a designation, use a default
                        if (!designation || designation === 'Designation') {
                            designation = 'Designation'; // Default text if not found
                        }

                        signatories[type] = {
                            fullname: name,
                            designation: designation
                        };

                        console.log('Signatory:', type, name, designation); // Debug log
                    }
                });

                // Get the table HTML and fix any issues with components
                var tableHTML = $('#outprint').clone();

                // Ensure all components are visible in the print view
                tableHTML.find('th, td').css('display', '');
                tableHTML.find('.table').addClass('table-print');

                // The on-screen wrapper carries inline max-height:80vh for scrolling.
                // In the print window there is no Bootstrap to contain it, so rows
                // taller than 80vh overflow visibly on top of the signatories.
                // Strip those constraints so the table paginates naturally.
                tableHTML.find('.table-responsive, .freeze-panes-container').css({
                    'max-height': 'none',
                    'height': 'auto',
                    'overflow': 'visible',
                    'overflow-x': 'visible',
                    'overflow-y': 'visible'
                });
                tableHTML.find('.table-header, thead, th.sticky-col, td.sticky-col, .sticky-col').css({
                    'position': 'static',
                    'left': 'auto',
                    'top': 'auto',
                    'box-shadow': 'none'
                });

                // Build the signatories HTML so it renders right after the grades
                // table in the print output (previously the print window never
                // included the signatories section at all).
                var printSignatoryTypes = [
                    { type: 'certified', title: 'CERTIFIED TRUE AND CORRECT:' },
                    { type: 'checked', title: 'CHECKED BY:' },
                    { type: 'noted', title: 'NOTED BY:' },
                    { type: 'received', title: 'RECEIVED BY:' }
                ];
                var printActiveSignatories = printSignatoryTypes.filter(function(s){
                    return signatories[s.type] && signatories[s.type].fullname && String(signatories[s.type].fullname).trim() !== '';
                });
                var signatoriesHTML = '';
                if (printActiveSignatories.length > 0) {
                    var printCellWidth = (100 / printActiveSignatories.length).toFixed(2);
                    var printSignatoryCells = printActiveSignatories.map(function(s){
                        return '<td style="width: ' + printCellWidth + '%; padding: 10px; vertical-align: top;">' +
                            '<h6 style="margin: 0 0 15px 0; text-align: left; font-size: 9pt; font-weight: bold;">' + s.title + '</h6>' +
                            '<div style="margin-bottom: 20px;">' +
                                '<div style="border-bottom: 1px solid #000; text-align: center; width: 90%; height: 50px; margin: 0 auto; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 5px;">' +
                                    signatories[s.type].fullname +
                                '</div>' +
                                '<div style="margin-top: 10px; text-align: center; font-weight: bold; font-size: 9pt;">' + (signatories[s.type].designation || 'Designation') + '</div>' +
                                '<div style="font-size: 8pt; text-align: center; color: #666;">Signature Over Printed Name</div>' +
                            '</div>' +
                        '</td>';
                    }).join('');
                    signatoriesHTML = '<div class="print-signatories" style="width: 100%; padding: 15px 0 0 0; background: #fff; page-break-inside: avoid; break-inside: avoid; clear: both; margin-top: 30px;">' +
                        '<table style="width: 100%; border-collapse: collapse; margin: 0 auto;">' +
                            '<tr>' + printSignatoryCells + '</tr>' +
                        '</table>' +
                    '</div>';
                }

                // Create the print HTML with proper styling
                var printHTML = `
                <!DOCTYPE html>
                <html>
                <head>

                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <style>

                        @page {
                            size: 8.5in 13in portrait; /* Folio */
                            margin: 0.5in !important;
                            padding: 0;
                        }

                        body {
                            margin: 0 !important;
                            padding: 0 !important;
                            font-family: Arial, sans-serif;
                            font-size: 9pt;
                            color: #000;
                            background: #fff;
                        }
                        .card-header, .btn, #transmuted_table, .no-print, .dataTables_info, .dataTables_length, .dataTables_filter, .dataTables_paginate {
                            display: none !important;
                        }
                        /* Cloned scroll wrappers must not cap height in print -
                           otherwise overflow rows paint over the signatories */
                        #outprint,
                        .table-responsive,
                        .freeze-panes-container,
                        .grades-table-container {
                            overflow: visible !important;
                            max-height: none !important;
                            height: auto !important;
                        }
                        .table-print {
                            width: 100% !important;
                            max-width: 100% !important;
                            margin: 0 0 30px 0 !important;
                            height: auto !important;
                            max-height: none !important;
                            overflow: visible !important;
                            font-size: 9pt !important;
                            border-collapse: collapse !important;
                            border: 1px solid #000 !important;
                            table-layout: fixed !important;
                            word-wrap: break-word;
                            box-sizing: border-box !important;
                            transform: none !important;
                        }
                        .table-print th, .table-print td {
                            padding: 2px 3px !important;
                            line-height: 1.1;
                            white-space: normal !important;
                            word-break: break-all;
                            overflow-wrap: break-word;
                            border: 1px solid #000 !important;
                            width: auto !important;
                            min-width: 30px !important;
                            max-width: none !important;
                            vertical-align: center !important;
                            box-sizing: border-box;
                            font-size: 7pt !important; /* Consistent font size */
                        }
                        /* Student column fixed width */
                        .table-print th:first-child,
                        .table-print td:first-child {
                        width: 180px !important;
                            min-width: 180px !important;
                            max-width: 180px !important;
                            white-space: normal;
                            align-content: center !important;
                            font-size:9px !important;
                        }
                        /* Grade columns fixed width - Dynamic for quarter grades */
                        .table-print th[class*="Grade"],
                        .table-print td[class*="Grade"] {
                            width: 40px !important;
                            min-width: 40px !important;
                            max-width: 40px !important;
                            text-align: center !important;
                            white-space: normal;
                            align-content: center !important;
                        }
                        .table-print th:nth-last-child(2),
                        .table-print td:nth-last-child(2) {
                            width: 40px !important;
                            min-width: 40px !important;
                            max-width: 40px !important;
                            text-align: center !important;
                            white-space: normal;
                            align-content: center !important;
                        }
                        .table-print th:nth-last-child(1),
                        .table-print td:nth-last-child(1) {
                            width: 40px !important;
                            min-width: 40px !important;
                            max-width: 40px !important;
                            text-align: center !important;
                            white-space: normal;
                            align-content: center !important;
                        }
                        .table-print th {
                            font-size: 6pt !important; /* Slightly larger for headers */
                            background-color: #1e293b !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                            font-weight: bold;
                            color: #fff !important;
                        }
                        /* --- Professional rq hierarchy in print popup --- */
                        .table-print.rq-grades thead tr.rq-row-main th {
                            background-color: #1e293b !important;
                            color: #f8fafc !important;
                            font-size: 6pt !important;
                            text-transform: uppercase;
                            letter-spacing: .04em;
                        }
                        .table-print.rq-grades thead tr.rq-row-main th.rq-h-student {
                            background-color: #0f172a !important;
                            text-align: center !important;
                        }
                        .table-print.rq-grades thead tr.rq-row-quarter th {
                            background-color: #f1f5f9 !important;
                            color: #475569 !important;
                            font-size: 6pt !important;
                            text-transform: uppercase;
                        }
                        .table-print.rq-grades thead th.rq-h-assess,
                        .table-print.rq-grades thead th.rq-h-hps,
                        .table-print.rq-grades thead th.rq-h-none {
                            background-color: #ffffff !important;
                            color: #0f172a !important;
                        }
                        .table-print.rq-grades thead th.rq-h-total,
                        .table-print.rq-grades thead th.rq-h-total-val {
                            background-color: #dbe2ec !important;
                            color: #334155 !important;
                        }
                        .table-print.rq-grades thead th.rq-h-pct,
                        .table-print.rq-grades thead th.rq-h-pct-val {
                            background-color: #cbd5e1 !important;
                            color: #1e293b !important;
                        }
                        .table-print.rq-grades tbody td.rq-total {
                            background-color: #e2e8f0 !important;
                            font-weight: bold !important;
                        }
                        .table-print.rq-grades tbody td.rq-weighted {
                            background-color: #d7dfea !important;
                            font-weight: bold !important;
                            color: #1e293b !important;
                        }
                        .table-print.rq-grades tbody td.rq-initial-cell {
                            background-color: #f8fafc !important;
                            color: #0f172a !important;
                            font-weight: bold !important;
                        }
                        .table-print.rq-grades tbody td.rq-grade-cell {
                            background-color: #ffffff !important;
                        }
                        .table-print.rq-grades .rq-pill {
                            display: inline-block !important;
                            border: 1px solid #cbd5e1 !important;
                            border-radius: 999px !important;
                            padding: 1px 6px !important;
                            font-weight: bold !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print.rq-grades .rq-comp-pct {
                            border: 1px solid rgba(255,255,255,.4) !important;
                            border-radius: 999px !important;
                            padding: 0 5px !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print.rq-grades td.rq-student {
                            text-align: left !important;
                            font-weight: bold !important;
                        }
                            .table-print    .text-truncate {
                                font-size: 6pt !important;

                            }
                                .table-print .initial-grade-header {
                                    width: 25px !important;
                                    min-width: 25px !important;
                                    max-width: 25px !important;
                                }
                                .table-print .quarter-grade-header {
                                    width: 25px !important;
                                    min-width: 25px !important;
                                    max-width: 25px !important;
                                }
                        .table-print .bg-dark {
                            background-color: #1e293b !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                            color: #fff !important;
                        }
                        .table-print .bg-warning {
                            background-color: #fef3c7 !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .bg-info {
                            background-color: #e2e8f0 !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .text-center {
                            text-align: center !important;
                            font-size: 6pt !important;

                        }
                        .table-print .text-danger {
                            color: #991b1b !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .text-warning {
                            color: #92400e !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .text-success {
                            color:#166534 !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .text-dark {
                            color: #1e293b !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .fw-bold {
                            font-weight: bold !important;
                        }
                        .table-print .text-light {
                            color: #fff !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .bg-opacity-50 {
                            opacity: 0.5 !important;
                        }

                        /* Sticky/frozen panes off in the print window - the clone
                           carries inline position:sticky which would pin cells
                           over continued rows on page 2 */
                        .table-print thead,
                        .table-print .table-header,
                        .table-print .sticky-col,
                        .table-print th.sticky-col,
                        .table-print td.sticky-col {
                            position: static !important;
                            left: auto !important;
                            top: auto !important;
                            box-shadow: none !important;
                            z-index: auto !important;
                        }

                        /* Signatories block rendered after the grades table */
                        .print-signatories {
                            page-break-inside: avoid !important;
                            break-inside: avoid !important;
                            page-break-before: auto !important;
                            clear: both !important;
                            width: 100% !important;
                            overflow: visible !important;
                        }
                        .print-signatories h6 {
                            font-weight: bold;
                            margin: 0 0 15px 0;
                        }

                        /* Signatures styling */
                        .signature-line {
                            border-bottom: 1px solid #000;
                            height: 30px;
                            margin: 0 auto 5px;
                            width: 100%;
                        }
                        .signature-label {
                            font-weight: bold;
                            font-size: 9pt;
                            margin: 5px 0;
                        }
                        .signature-note {
                            font-size: 9pt;
                            color: #666;
                        }

                        thead {
                            display: table-header-group;
                            break-inside: avoid;
                        }
                        tbody {
                            display: table-row-group;
                        }
                        tfoot {
                            display: table-footer-group;
                        }
                    .header-info {
                            margin-top: 0;
                                margin-bottom: 0px;
                                page-break-after: avoid;
                            }
                            .header-info h3 {
                                text-align: center;
                                margin: 5px 0;
                                font-size: 12pt;
                            }
                            .header-info div {
                                margin: 2px 0;
                                font-size: 9pt;
                            }

                        @media print {
                                @page {
                                    size: 8.5in 13in portrait; /* Folio */
                                    margin: 0.5in !important;
                                    padding: 0 !important;
                                }
                                html, body {
                                    margin: 0 !important;
                                    padding: 0 !important;
                                }
                                body {
                                    margin: 0;
                                    padding: 10px;
                                    font-size: 8pt;
                                }
                                .table-print {
                                    font-size: 9pt !important;
                                    width: 100% !important;
                                    max-width: 100% !important;
                                    height: auto !important;
                                    max-height: none !important;
                                    overflow: visible !important;
                                    margin-bottom: 30px !important;
                                    transform: scale(1) !important;
                                    transform-origin: 0 0 !important;
                                    table-layout: fixed !important;
                                }
                                /* Ensure signatories are visible in print */
                                .col-8.offset-2.mt-2 {
                                    display: block !important;
                                    page-break-before: auto;
                                    margin-top: 30px !important;
                                }
                                .col-md-4.text-center {
                                    display: block !important;
                                    page-break-inside: avoid;
                                    width: 33.33% !important;
                                    float: left !important;
                                }
                                .col-md-4.text-center h6 {
                                    font-size: 10pt !important;
                                    margin-bottom: 15px !important;
                                }
                                .col-md-4.text-center .mb-4 {
                                    margin-bottom: 20px !important;
                                }
                                .col-md-4.text-center .mb-1 {
                                    border-bottom: 1px solid #000 !important;
                                    width: 90% !important;
                                    height: 50px !important;
                                    margin: 0 auto !important;
                                }
                                .col-md-4.text-center .mt-2 {
                                    margin-top: 10px !important;
                                    font-weight: bold !important;
                                    font-size: 9pt !important;
                                }
                                .col-md-4.text-center .text-muted {
                                    font-size: 8pt !important;
                                    color: #666 !important;
                                }
                            }
                    </style>

                </head>
                <body style="margin: 0; padding: 0;">
                    <!-- Header -->
                    <table style="width: 100%; margin: 0;">
                        <div class="header-info">
                            <h3>${title}</h3>
                            <i style="font-size: 10pt; color:rgb(87, 87, 87); text-align: center; display: flex; justify-content: center; font-style: italic; font-family: Arial, sans-serif; margin-bottom: 10px;">
                                    <?php
                                    // Map quarter number to name (custom names supported)
                                    $quarter_num = $_GET['quarter'] ?? 0;
                                    $quarter_name = get_quarter_name($conn, $class_id, $quarter_num);
                                    echo htmlspecialchars($class_info['semester'] ?? 'N/A') . ', ' . htmlspecialchars($quarter_name) . ', School Year: ' . htmlspecialchars($class_info['year'] ?? 'N/A');
                                    ?>
                                    </i>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 20px; gap: 20px;">
                                <div style="flex: 1;">

                                    <table class="class-info-table" style="width: 40%; margin-top:10px; border-width: 1px; border-color: rgb(143, 143, 143);">
                                        <tr>
                                            <td style="width: 40%; padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><strong>Course Code:</strong>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><?php echo $class_info['course_no'] ?? 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><strong>Subject:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><?php echo $class_info['subject_name'] ?? 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><strong>Course & Section:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;">
                                                <?php
                                                if (isset($class_info['grade']) && isset($class_info['section'])) {
                                                    echo htmlspecialchars($class_info['grade'] . ' - ' . $class_info['section']);
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><strong>Schedule:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><?php echo htmlspecialchars($class_info['schedule'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><strong>Units:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 8pt;"><?php echo htmlspecialchars($class_info['unit'] ?? 'N/A'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div style="text-align: right; margin-top: 10px;">
                                <strong>Date Generated:</strong> ${currentDate}
                            </div>
                        </div>
                    </table>
                    <div style="margin-bottom: 10px !important; position:relative !important;border: 4px solid rgb(0, 0, 0) !important;">
                        ${tableHTML.html()}
                    </div>
                    <!-- Signatories rendered after the grades table -->
                    ${signatoriesHTML}




                <script>
                        window.onload = function() {
                            // Force show all components in the table
                            var tables = document.getElementsByClassName('table-print');
                            for (var i = 0; i < tables.length; i++) {
                                var table = tables[i];
                                var rows = table.getElementsByTagName('tr');
                                for (var j = 0; j < rows.length; j++) {
                                    rows[j].style.display = '';
                                    var cells = rows[j].getElementsByTagName('th');
                                    for (var k = 0; k < cells.length; k++) {
                                        cells[k].style.display = '';
                                    }
                                    cells = rows[j].getElementsByTagName('td');
                                    for (k = 0; k < cells.length; k++) {
                                        cells[k].style.display = '';
                                    }
                                }
                            }

                            // Add page numbers
                            var pageCount = 1;
                            var pageNumDivs = document.getElementsByClassName('pageNumber');
                            for (var i = 0; i < pageNumDivs.length; i++) {
                                pageNumDivs[i].textContent = pageCount;
                            }

                            // Print after a short delay to ensure everything is rendered
                            setTimeout(function() {
                                window.print();
                                window.onafterprint = function() {
                                    window.close();
                                };
                            }, 500);
                        };
                    <\/script>

                </body>
                </html>
                `;

                // Write content to the new window
                printWindow.document.open();
                printWindow.document.write(printHTML);
                printWindow.document.close();
            });

            // Word export functionality
            $('#exportWord').click(function(){
                // Get the current date
                var currentDate = new Date().toLocaleDateString();

                // Get the report title and class info
                var title = "CLASS RECORDS";
                var classInfo = $('.report-section-tab.active').text().trim();
                var quarter = $('#quarter option:selected').text();
                var subject = $('.report-subject-tab.active').text().trim();

                // Get the signatories data first
                var signatories = {};
                $('.col-md-4.text-center').each(function() {
                    var title = $(this).find('h6').text().replace(':', '').trim();
                    var type = '';

                    // Determine the type based on title
                    if (title.includes('CERTIFIED')) type = 'certified';
                    else if (title.includes('CHECKED')) type = 'checked';
                    else if (title.includes('NOTED')) type = 'noted';
                    else if (title.includes('RECEIVED')) type = 'received';

                    if (type) {
                        // Get the name from the border-bottom div
                        var name = $(this).find('div[style*="border-bottom"] > div').first().text().trim();

                        // Get the designation from the .fw-bold element
                        var designation = $(this).find('.fw-bold').first().text().trim();

                        // Clean up the designation text
                        designation = designation.replace(/\s+/g, ' ').trim();

                        if (!designation || designation === 'Designation') {
                            designation = 'Designation';
                        }

                        signatories[type] = {
                            fullname: name,
                            designation: designation
                        };
                    }
                });

                // Get the table HTML and fix any issues with components
                var tableHTML = $('#outprint').clone();

                // Ensure all components are visible
                tableHTML.find('th, td').css('display', '');
                tableHTML.find('.table').addClass('table-print');

                // Same overflow fix as the print path: strip the on-screen
                // max-height:80vh scroll constraints so nothing overflows
                // onto following content in Word.
                tableHTML.find('.table-responsive, .freeze-panes-container').css({
                    'max-height': 'none',
                    'height': 'auto',
                    'overflow': 'visible',
                    'overflow-x': 'visible',
                    'overflow-y': 'visible'
                });

                // Word cannot resolve CSS variables in inline styles and largely ignores
                // stylesheet rules once a cell has conflicting inline declarations. The
                // student cell carries `border: 1px solid var(--rq-cell-border, #000000)`
                // plus a status-colored `border-right`, which Word drops - leaving the
                // student column without a visible border. Strip those declarations and
                // apply an explicit inline 1px solid black border on every side, which is
                // the one form of border styling Word reliably honors.
                tableHTML.find('td.sticky-col, th.sticky-col').each(function() {
                    var cleanedStyle = ($(this).attr('style') || '')
                        .replace(/border(?:-(?:top|bottom|left|right))?\s*:[^;]*;?/gi, '');
                    cleanedStyle += ' border: 1px solid black;';
                    $(this).attr('style', cleanedStyle);
                });

                // Normalize every remaining inline border on the cloned cells to 1px.
                // The on-screen table headers carry inline `border: 2px solid black !important`
                // styles, and inline declarations win over the stylesheet inside Word -
                // without this pass those headers would keep 2px borders in the export.
                tableHTML.find('th, td').each(function() {
                    var normalizedStyle = ($(this).attr('style') || '')
                        .replace(/(border(?:-(?:top|bottom|left|right))?\s*:\s*[^;]*?)2px\s+solid/gi, '$11px solid');
                    $(this).attr('style', normalizedStyle);
                });

                // Word export: keep grade cells light so the professional pill
                // badges (inline background on .rq-pill) stay readable. Word
                // ignores most stylesheets when an inline background is present,
                // so normalize the clone's cell background to white and let the
                // pill span carry the status color.
                tableHTML.find('td.transmuted-grade').each(function() {
                    var s = ($(this).attr('style') || '').replace(/background(?:-color)?\s*:[^;]*;?/gi, '');
                    $(this).attr('style', s + ' background-color: #ffffff;');
                });
                tableHTML.find('td.initial-grade-cell').each(function() {
                    var s = ($(this).attr('style') || '').replace(/background(?:-color)?\s*:[^;]*;?/gi, '').replace(/color\s*:[^;]*;?/gi, '');
                    $(this).attr('style', s + ' background-color: #f8fafc; color: #0f172a;');
                });

                // Word ignores Bootstrap utilities (py-0 px-1) and often ignores
                // stylesheet padding on td with border-collapse + table-layout:fixed.
                // Force inline padding + mso-padding-alt + cellpadding so assessment
                // columns are not rendered tight.
                tableHTML.find('th, td').each(function() {
                    var s = ($(this).attr('style') || '').replace(/padding\s*:[^;]*;?/gi, '').replace(/mso-padding-alt\s*:[^;]*;?/gi, '');
                    $(this).attr('style', s + ' padding: 1px 2px; mso-padding-alt: 1px 2px;');
                });
                tableHTML.find('table.table-print').attr({ 'cellpadding': '1', 'cellspacing': '0' });

                // Create Word-compatible HTML
                var wordHTML = `
                <!DOCTYPE html>
                <html xmlns:o='urn:schemas-microsoft-com:office:office'
                      xmlns:w='urn:schemas-microsoft-com:office:word'
                      xmlns='http://www.w3.org/TR/REC-html40'>
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <title>CLASS RECORDS</title>
                    <!--[if gte mso 9]>
                    <xml>
                        <w:WordDocument>
                            <w:View>Print</w:View>
                            <w:Zoom>100</w:Zoom>
                            <w:DoNotOptimizeForBrowser/>
                            <w:Orientation>Landscape</w:Orientation>
                        </w:WordDocument>
                    </xml>
                    <![endif]-->
                    <style>
                        @page {
                            size: 8.5in 13in !important;
                            margin: 0.5in !important;
                            mso-page-orientation: landscape;
                        }
                        body {
                            margin: 0 !important;
                            padding: 0 !important;
                            font-family: Arial, sans-serif;
                            font-size: 9pt !important;
                            color: #000;
                            background: #fff;
                        }
                        .card-header, .btn, #transmuted_table, .no-print, .dataTables_info, .dataTables_length, .dataTables_filter, .dataTables_paginate {
                            display: none !important;
                        }
                        #outprint,
                        .table-responsive,
                        .freeze-panes-container,
                        .grades-table-container {
                            overflow: visible !important;
                            max-height: none !important;
                            height: auto !important;
                        }
                        .table-print {
                            width: 100% !important;
                            max-width: 100% !important;
                            margin: 0 !important;
                            font-size: 10pt !important;
                            border-collapse: collapse !important;
                            border: 1px solid black !important;
                            table-layout: fixed !important;
                            word-wrap: break-word;
                            box-sizing: border-box !important;
                        }
                        .table-print th, .table-print td {
                            padding: 1px 2px !important;
                            mso-padding-alt: 1px 2px !important;
                            line-height: 1.2;
                            white-space: normal !important;
                            word-break: break-all;
                            overflow-wrap: break-word;
                            border: 1px solid black !important;
                            border-collapse: collapse !important;
                            width: auto !important;
                            min-width: 40px !important;
                            max-width: none !important;
                            vertical-align: middle !important;
                            box-sizing: border-box;
                            font-size: 9pt !important;
                        }
                        .table-print td {
                            border: 1px solid black !important;
                            font-weight: bold !important;
                        }
                        /* Grade columns (Quarter / Initial / AVG) - light professional band for Word export */
                        .table-print .initial-grade-cell {
                            background-color: #f8fafc !important;
                            color: #0f172a !important;
                        }
                        .table-print .transmuted-grade {
                            background-color: #ffffff !important;
                        }
                        /* Grade columns (Quarter / Initial / AVG) print light */
                        .table-print .initial-grade-cell {
                            background-color: #f8fafc !important;
                            color: #0f172a !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print .transmuted-grade {
                            background-color: #ffffff !important;
                            -webkit-print-color-adjust: exact;
                            print-color-adjust: exact;
                        }
                        .table-print tbody td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr.status-dropped td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr.status-nosub td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr.status-noexam td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr[data-student-id] td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr[data-student-id] td.sticky-col {
                            border: 1px solid black !important;
                            border-bottom: 1px solid black !important;
                            border-top: 1px solid black !important;
                            border-left: 1px solid black !important;
                            border-right: 1px solid black !important;
                        }
                        .table-print td.sticky-col {
                            border: 1px solid black !important;
                            border-right: 1px solid black !important;
                        }
                        .table-print td.py-0.px-1.sticky-col {
                            border: 1px solid black !important;
                            border-bottom: 1px solid black !important;
                            border-top: 1px solid black !important;
                            border-left: 1px solid black !important;
                            border-right: 1px solid black !important;
                        }
                        .table-print tbody tr:first-child td {
                            border: 1px solid black !important;
                        }
                        .table-print tbody tr:first-child td.sticky-col {
                            border: 1px solid black !important;
                            border-bottom: 1px solid black !important;
                            border-top: 1px solid black !important;
                            border-left: 1px solid black !important;
                            border-right: 1px solid black !important;
                        }
                        .table-print td[style*="border"] {
                            border: 1px solid black !important;
                            border-bottom: 1px solid black !important;
                            border-top: 1px solid black !important;
                            border-left: 1px solid black !important;
                            border-right: 1px solid black !important;
                        }
                        .table-print th[class*="Grade"],
                        .table-print td[class*="Grade"] {
                            width: 40px !important;
                            min-width: 40px !important;
                            max-width: 40px !important;
                            text-align: center !important;
                        }
                        .table-print th {
                            font-size: 9pt !important;
                            background-color: #1e293b !important;
                            font-weight: bold;
                            color: #fff !important;
                        }
                        /* --- Professional rq hierarchy in Word export --- */
                        .table-print.rq-grades thead tr.rq-row-main th {
                            background-color: #1e293b !important;
                            color: #f8fafc !important;
                            text-transform: uppercase;
                        }
                        .table-print.rq-grades thead tr.rq-row-main th.rq-h-student {
                            background-color: #0f172a !important;
                            text-align: center !important;
                        }
                        .table-print.rq-grades thead tr.rq-row-quarter th {
                            background-color: #f1f5f9 !important;
                            color: #475569 !important;
                            text-transform: uppercase;
                        }
                        .table-print.rq-grades thead th.rq-h-assess,
                        .table-print.rq-grades thead th.rq-h-hps,
                        .table-print.rq-grades thead th.rq-h-none {
                            background-color: #ffffff !important;
                            color: #0f172a !important;
                        }
                        .table-print.rq-grades thead th.rq-h-total,
                        .table-print.rq-grades thead th.rq-h-total-val {
                            background-color: #dbe2ec !important;
                            color: #334155 !important;
                        }
                        .table-print.rq-grades thead th.rq-h-pct,
                        .table-print.rq-grades thead th.rq-h-pct-val {
                            background-color: #cbd5e1 !important;
                            color: #1e293b !important;
                        }
                        .table-print.rq-grades tbody td.rq-total {
                            background-color: #e2e8f0 !important;
                            font-weight: bold !important;
                        }
                        .table-print.rq-grades tbody td.rq-weighted {
                            background-color: #d7dfea !important;
                            font-weight: bold !important;
                            color: #1e293b !important;
                        }
                        .table-print.rq-grades tbody td.rq-initial-cell {
                            background-color: #f8fafc !important;
                            color: #0f172a !important;
                            font-weight: bold !important;
                        }
                        .table-print.rq-grades tbody td.rq-grade-cell {
                            background-color: #ffffff !important;
                        }
                        .table-print.rq-grades .rq-pill {
                            display: inline-block !important;
                            border: 1px solid #cbd5e1 !important;
                            border-radius: 999px !important;
                            padding: 1px 6px !important;
                            font-weight: bold !important;
                        }
                        .table-print.rq-grades td.rq-student {
                            text-align: left !important;
                            font-weight: bold !important;
                        }
                        .table-print .bg-dark {
                            background-color: #1e293b !important;
                            color: #fff !important;
                        }
                        .table-print .bg-warning {
                            background-color: #fef3c7 !important;
                            color: #92400e !important;
                        }
                        .table-print .bg-info {
                            background-color: #e2e8f0 !important;
                            color: #1e293b !important;
                        }
                        .table-print .bg-success {
                            background-color: #dcfce7 !important;
                            color: #166534 !important;
                        }
                        .table-print .bg-secondary {
                            background-color: #f1f5f9 !important;
                            color: #475569 !important;
                        }
                        .table-print .text-center {
                            text-align: center !important;
                        }
                        .table-print .text-danger {
                            color: #991b1b !important;
                        }
                        .table-print .text-warning {
                            color: #92400e !important;
                        }
                        .table-print .text-success {
                            color: #166534 !important;
                        }
                        .table-print .text-dark {
                            color: #1e293b !important;
                        }
                        .table-print .fw-bold {
                            font-weight: bold !important;
                        }
                        .table-print .text-light {
                            color: #fff !important;
                        }
                        .header-info {
                            margin-top: 0;
                            margin-bottom: 20px;
                        }
                        .header-info h3 {
                            text-align: center;
                            margin: 10px 0;
                            font-size: 14pt;
                        }
                        .header-info div {
                            margin: 5px 0;
                            font-size: 10pt;
                        }
                        .class-info-table {
                            width: 40%;
                            margin-top: 10px;
                            border: 1px solid white;
                            border-collapse: collapse;
                        }
                        .class-info-table td {
                            padding: 4px 8px;
                            border: 1px solid white;
                            font-size: 9pt;
                        }
                        table {
                            page-break-inside: auto;
                            border-collapse: collapse;
                        }
                        tr {
                            page-break-inside: avoid;
                            page-break-after: auto;
                        }
                        thead {
                            display: table-header-group;
                            break-inside: avoid;
                        }
                        tbody {
                            display: table-row-group;
                        }
                        .signature-line {
                            border-bottom: 1px solid black;
                            height: 40px;
                            margin: 0 auto 5px;
                            width: 90%;
                        }
                        .signature-label {
                            font-weight: bold;
                            font-size: 10pt;
                            margin: 5px 0;
                        }
                        .signature-note {
                            font-size: 9pt;
                            color: #666;
                        }
                    </style>
                </head>
                <body style="margin: 0; padding: 20px;">
                    <!-- Header images (uploads from Image Manager) by position -->
                    <?php
                    $word_header_images = [];
                    $word_hr = $conn->query("SELECT element_type, position, image_path, image_width, image_height FROM header_footer_settings WHERE element_type = 'header' AND is_active = 1 ORDER BY CASE position WHEN 'left' THEN 1 WHEN 'center' THEN 2 WHEN 'right' THEN 3 ELSE 4 END");
                    if ($word_hr) {
                        while ($word_h = $word_hr->fetchArray(SQLITE3_ASSOC)) {
                            $word_header_images[$word_h['position']] = $word_h;
                        }
                    }
                    $word_has_header = !empty($word_header_images);
                    if ($word_has_header):
                    ?>
                    <table style="width: 100%; margin: 0 0 10px 0; border: none; border-collapse: collapse;">
                        <tr>
                            <?php foreach (['left', 'center', 'right'] as $word_pos): ?>
                                <td style="width: 33.33%; text-align: <?php echo $word_pos; ?>; vertical-align: middle; border: none; padding: 4px;">
                                    <?php if (!empty($word_header_images[$word_pos]['image_path']) && file_exists($word_header_images[$word_pos]['image_path'])): ?>
                                        <?php
                                        $word_hp = $word_header_images[$word_pos]['image_path'];
                                        $word_hw = !empty($word_header_images[$word_pos]['image_width']) ? (int)$word_header_images[$word_pos]['image_width'] : 0;
                                        $word_hh = !empty($word_header_images[$word_pos]['image_height']) ? (int)$word_header_images[$word_pos]['image_height'] : 0;
                                        $word_hw = $word_hw > 0 ? min($word_hw, 280) : 180;
                                        $word_hh = $word_hh > 0 ? min($word_hh, 90) : 65;
                                        ?>
                                        <img src="<?php echo htmlspecialchars(str_replace(__DIR__, '', $word_hp)); ?>" width="<?php echo $word_hw; ?>" height="<?php echo $word_hh; ?>" style="max-width: 100%; object-fit: contain;">
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    </table>
                    <?php endif; ?>
                    <!-- Header -->
                    <table style="width: 100%; margin: 0;">
                        <div class="header-info">
                            <h3>${title}</h3>
                            <div style="font-size: 11pt; color:rgb(87, 87, 87); text-align: center; font-style: italic; font-family: Arial, sans-serif; margin-bottom: 10px;">
                                    <?php
                                    $quarter_num = $_GET['quarter'] ?? 0;
                                    $quarter_name = get_quarter_name($conn, $class_id, $quarter_num);
                                    echo htmlspecialchars($class_info['semester'] ?? 'N/A') . ', ' . htmlspecialchars($quarter_name) . ', School Year: ' . htmlspecialchars($class_info['year'] ?? 'N/A');
                                    ?>
                            </div>
                            <div style="display: flex; justify-content: space-between; margin-bottom: 20px; gap: 20px;">
                                <div style="flex: 1;">
                                    <table class="class-info-table" style="width: 50%; margin-top:10px; border-width: 1px; border-color: rgb(143, 143, 143);">
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><strong>Course Code:</strong>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><?php echo $class_info['course_no'] ?? 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><strong>Subject:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><?php echo $class_info['subject_name'] ?? 'N/A'; ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><strong>Course & Section:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;">
                                                <?php
                                                if (isset($class_info['grade']) && isset($class_info['section'])) {
                                                    echo htmlspecialchars($class_info['grade'] . ' - ' . $class_info['section']);
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><strong>Schedule:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><?php echo htmlspecialchars($class_info['schedule'] ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><strong>Units:</strong></td>
                                            <td style="padding: 2px 4px; border: 1px solid rgb(143, 143, 143); font-size: 10pt;"><?php echo htmlspecialchars($class_info['unit'] ?? 'N/A'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div style="text-align: right; margin-top: 10px;">
                                <strong>Date Generated:</strong> ${currentDate}
                            </div>
                        </div>
                    </table>
                    <div style="margin-bottom: 10px !important; position:relative !important;">
                        ${tableHTML.html()}
                    </div>
                    <!-- Signatories Section -->
                    <div style="width: 100%; padding: 15px; background: white; page-break-inside: avoid; clear: both; margin-top: 50px;">
                        <table style="width: 100%; border-collapse: collapse; margin: 0 auto;">
                            <tr>
                                ${(() => {
                                    const signatoryTypes = [
                                        { type: 'certified', title: 'CERTIFIED TRUE AND CORRECT:' },
                                        { type: 'checked', title: 'CHECKED BY:' },
                                        { type: 'noted', title: 'NOTED BY:' },
                                        { type: 'received', title: 'RECEIVED BY:' }
                                    ];

                                    const activeSignatories = signatoryTypes.filter(s =>
                                        signatories[s.type] && signatories[s.type].fullname && signatories[s.type].fullname.trim() !== ''
                                    );

                                    const cellWidth = (100 / activeSignatories.length).toFixed(2);

                                    return activeSignatories.map(s => `
                                        <td style="width: ${cellWidth}%; padding: 10px; vertical-align: top;">
                                            <h6 style="margin-bottom: 20px; text-align: left; font-size: 9px;">${s.title}</h6>
                                            <div style="margin-bottom: 20px;">
                                                <div style="border-bottom: 1px solid black; text-align: center; width: 20% !important; height: 50px; margin: 0 auto; display: flex; align-items: flex-end; justify-content: center; padding-bottom: 5px;">
                                                    ${signatories[s.type].fullname}
                                                </div>
                                                <div style="margin-top: 10px; text-align: center; font-weight: bold; font-size: 7pt;">${signatories[s.type].designation || 'Designation'}</div>
                                                <div style="font-size: 8pt; text-align: center; color: #666;">Signature Over Printed Name</div>
                                            </div>
                                        </td>
                                    `).join('');
                                })()}
                            </tr>
                        </table>
                    </div>
                    <!-- Footer images (uploads from Image Manager) by position -->
                    <?php
                    $word_footer_images = [];
                    $word_fr = $conn->query("SELECT element_type, position, image_path, image_width, image_height FROM header_footer_settings WHERE element_type = 'footer' AND is_active = 1 ORDER BY CASE position WHEN 'left' THEN 1 WHEN 'center' THEN 2 WHEN 'right' THEN 3 ELSE 4 END");
                    if ($word_fr) {
                        while ($word_f = $word_fr->fetchArray(SQLITE3_ASSOC)) {
                            $word_footer_images[$word_f['position']] = $word_f;
                        }
                    }
                    $word_has_footer = !empty($word_footer_images);
                    if ($word_has_footer):
                    ?>
                    <table style="width: 100%; margin: 30px 0 0 0; border: none; border-collapse: collapse;">
                        <tr>
                            <?php foreach (['left', 'center', 'right'] as $word_pos): ?>
                                <td style="width: 33.33%; text-align: <?php echo $word_pos; ?>; vertical-align: middle; border: none; padding: 4px;">
                                    <?php if (!empty($word_footer_images[$word_pos]['image_path']) && file_exists($word_footer_images[$word_pos]['image_path'])): ?>
                                        <?php
                                        $word_fp = $word_footer_images[$word_pos]['image_path'];
                                        $word_fw = !empty($word_footer_images[$word_pos]['image_width']) ? (int)$word_footer_images[$word_pos]['image_width'] : 0;
                                        $word_fh = !empty($word_footer_images[$word_pos]['image_height']) ? (int)$word_footer_images[$word_pos]['image_height'] : 0;
                                        $word_fw = $word_fw > 0 ? min($word_fw, 280) : 200;
                                        $word_fh = $word_fh > 0 ? min($word_fh, 90) : 55;
                                        ?>
                                        <img src="<?php echo htmlspecialchars(str_replace(__DIR__, '', $word_fp)); ?>" width="<?php echo $word_fw; ?>" height="<?php echo $word_fh; ?>" style="max-width: 100%; object-fit: contain;">
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    </table>
                    <?php endif; ?>
                </body>
                </html>
                `;

                // Create a blob with the HTML content
                var blob = new Blob(['\ufeff', wordHTML], {
                    type: 'application/msword'
                });

                // Create download link
                var url = URL.createObjectURL(blob);
                var downloadLink = document.createElement('a');

                // Generate filename with class info and date
                var sanitizedSubject = subject.replace(/[^a-zA-Z0-9]/g, '_');
                var sanitizedClassInfo = classInfo.replace(/[^a-zA-Z0-9]/g, '-');
                var filename = 'Class_Records_' + sanitizedSubject + '_' + sanitizedClassInfo + '_' + new Date().toISOString().slice(0,10) + '.doc';

                downloadLink.href = url;
                downloadLink.download = filename;

                // Trigger download
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);

                // Clean up
                URL.revokeObjectURL(url);
            });


            // High Impact Assessment Detection Loop
            function determineHighImpact() {
                $('.editable-mark').each(function() {
                    var $cell = $(this);
                    var mark = parseFloat($cell.text()) || 0;
                    var studentId = $cell.data('student-id');
                    var assessmentId = $cell.data('assessment-id');

                    // Get HPS for this assessment (from assessmentHPS array)
                    var hps = assessmentHPS[assessmentId] || 0;

                    if (hps > 0) {
                        var markPercentage = (mark / hps) * 100;
                        var componentWeight = 0; // This would need to be calculated based on component

                        // For demonstration, assume component weight from data attributes or calculate
                        // In a real implementation, you'd need to get the component weight

                        // Simple high impact detection based on mark percentage
                        var isHighImpact = false;
                        var markClass = '';

                        if (markPercentage < 75) {
                            // Low scores are considered high impact
                            if (mark === 0) {
                                markClass = 'text-danger fw-bold bg-danger bg-opacity-25';
                                isHighImpact = true;
                            } else if (markPercentage < 50) {
                                markClass = 'text-danger fw-bold bg-danger bg-opacity-25';
                                isHighImpact = true;
                            } else if (markPercentage < 75) {
                                markClass = 'text-dark fw-bold bg-warning bg-opacity-25';
                                isHighImpact = true;
                            }
                        }

                        // Apply styling based on impact
                        if (isHighImpact) {
                            $cell.removeClass('text-danger fw-bold bg-danger bg-opacity-25 text-dark fw-bold bg-warning bg-opacity-25')
                                  .addClass(markClass);
                        } else {
                            // Remove high impact styling if not applicable
                            $cell.removeClass('text-danger fw-bold bg-danger bg-opacity-25 text-dark fw-bold bg-warning bg-opacity-25');
                        }
                    }
                });
            }

            // Start the high impact detection loop (runs every 1 second)
            setInterval(function() {
                determineHighImpact();
            }, 100);

            // Also run immediately on page load
            determineHighImpact();
        });
    </script>