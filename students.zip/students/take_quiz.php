<?php
// Secure quiz-taking page. Tab switch / minimize / new-tab backgrounding is
// detected (Page Visibility + blur), logged as a violation, and auto-submits
// after 3 violations. Copy, right-click, print and devtools shortcuts are blocked.
if (session_status() === PHP_SESSION_NONE) {
    $p = '/students/';
    if (!empty($_SERVER['SCRIPT_NAME'])) {
        $d = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        if ($d !== '' && $d !== '.' && $d !== '/') $p = $d . '/';
    }
    session_set_cookie_params(['lifetime' => 0, 'path' => $p, 'domain' => '', 'secure' => false, 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
if (!isset($_SESSION['student_logged_in']) || $_SESSION['student_logged_in'] !== true || empty($_SESSION['student_number'])) {
    header('Location: login.php');
    exit();
}
require_once(__DIR__ . '/../quiz_schema.php');
$student_number = (string)$_SESSION['student_number'];
$quiz_id = (int)($_GET['q'] ?? 0);
$class_id = (int)($_GET['c'] ?? 0);
$db_key = trim($_GET['k'] ?? '');
$gate_error = '';
$quiz_meta = null;
if ($quiz_id <= 0 || $class_id <= 0 || $db_key === '') {
    $gate_error = 'Invalid quiz link. Open the quiz from your dashboard notification.';
} else {
    foreach (quiz_candidate_db_files() as $f) {
        if (quiz_db_key($f) !== $db_key) continue;
        try {
            $pdo = new PDO('sqlite:' . $f);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            quiz_ensure_schema($pdo);
            $st = $pdo->prepare("SELECT * FROM quiz_list WHERE quiz_id = :q AND class_id = :c LIMIT 1");
            $st->execute([':q' => $quiz_id, ':c' => $class_id]);
            $q = $st->fetch(PDO::FETCH_ASSOC);
            if (!$q) { $gate_error = 'Quiz not found.'; break; }
            if ((int)$q['is_active'] !== 1) { $gate_error = 'This quiz is no longer active.'; break; }
            $se = $pdo->prepare("SELECT student_id, name FROM student_list WHERE student_number = :sn AND class_id = :c LIMIT 1");
            $se->execute([':sn' => $student_number, ':c' => $class_id]);
            $stu = $se->fetch(PDO::FETCH_ASSOC);
            if (!$stu) { $gate_error = 'This quiz is for a different class — it is not assigned to you.'; break; }
            $asgGate = json_decode($q['assigned_student_ids'] ?? '', true);
            if (is_array($asgGate) && count($asgGate)) {
                $okGate = false;
                foreach ($asgGate as $aid) { if ((int)$aid === (int)$stu['student_id']) { $okGate = true; break; } }
                if (!$okGate) { $gate_error = 'This quiz was not assigned to you.'; break; }
            }
            $nq = $pdo->prepare("SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = :q");
            $nq->execute([':q' => $quiz_id]);
            $quiz_meta = ['title' => $q['title'], 'quiz_type_label' => quiz_type_label($q['quiz_type']), 'num_items' => (int)$nq->fetchColumn(), 'time_limit_minutes' => (int)$q['time_limit_minutes']];
        } catch (Exception $e) { $gate_error = 'Could not open the quiz — please retry.'; }
        break;
    }
    if ($quiz_meta === null && $gate_error === '') $gate_error = 'Quiz not found for your class.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Take Quiz — HORIZON Student Portal</title>
<script>
    // Apply saved Horizon theme before first paint (shares key with portal).
    try {
        if (localStorage.getItem('horizon-theme') === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
    } catch (error) {}
</script>
<link rel="icon" href="../favicon.ico" type="image/x-icon">
<link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/horizon-theme.css" rel="stylesheet">
<link href="../Font-Awesome-master/css/all.min.css" rel="stylesheet">
<style>
.horizon-page-bg{background:var(--horizon-bg-main);min-height:100vh}
.quiz-shell{max-width:860px;margin:0 auto;padding:14px 12px 40px}
.quiz-q{border:1px solid var(--horizon-card-border);border-radius:14px;background:var(--horizon-card-bg);padding:16px;margin-bottom:12px}
.quiz-q h6{font-weight:800;color:var(--horizon-text-title);font-size:14px;line-height:1.5;white-space:pre-line}
.quiz-opt{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--horizon-card-border);border-radius:10px;padding:10px 12px;margin-top:8px;cursor:pointer;font-size:13px;font-weight:600;color:var(--horizon-text-title)}
.quiz-opt:hover{border-color:var(--horizon-brand-300)}
.quiz-opt.sel{border-color:var(--horizon-brand-500);background:var(--horizon-brand-50)}
/* Dark mode: keep selected choice readable (light text needs a dark tint, not pale lavender) */
html[data-theme="dark"] .quiz-opt.sel{background:rgba(67,24,255,.32);border-color:#818cf8}
html[data-theme="dark"] .quiz-opt:hover{border-color:#818cf8}
#secureBar{position:sticky;top:0;z-index:50}
.violation-shake{animation:vshake .4s}
@keyframes vshake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
#gateOverlay{position:fixed;inset:0;z-index:2000;display:flex;align-items:center;justify-content:center;background:rgba(15,23,42,.55);padding:16px}
html[data-theme="dark"] .quiz-shell .form-control{background-color:var(--horizon-input-bg);border-color:var(--horizon-input-border);color:var(--horizon-input-text)}
html[data-theme="dark"] .quiz-shell .form-control::placeholder{color:var(--horizon-text-muted)}
/* ── Professional exam organization ── */
.quiz-head{border:1px solid var(--horizon-card-border);border-radius:14px;background:var(--horizon-card-bg);box-shadow:var(--horizon-card-shadow);padding:16px;margin-bottom:12px}
.quiz-progress{height:8px;border-radius:999px;background:var(--horizon-table-hover);overflow:hidden}
.quiz-progress > div{height:100%;width:0;background:var(--horizon-brand-linear);transition:width .25s ease}
.quiz-pal-grid{display:flex;flex-wrap:wrap;gap:6px}
.quiz-pal{width:34px;height:34px;border-radius:9px;border:1px solid var(--horizon-card-border);background:var(--horizon-card-bg);color:var(--horizon-text-muted);font-weight:800;font-size:12px;cursor:pointer;transition:all .15s}
.quiz-pal:hover{border-color:var(--horizon-brand-500);color:var(--horizon-brand-500)}
.quiz-pal.answered{background:var(--horizon-brand-500);border-color:var(--horizon-brand-500);color:#fff}
.quiz-q-head{display:flex;align-items:center;gap:8px;margin-bottom:8px;flex-wrap:wrap}
.quiz-opt input{position:absolute;opacity:0;width:1px;height:1px}
.quiz-opt:focus-within{border-color:var(--horizon-brand-500)}
.opt-letter{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;min-width:26px;border-radius:8px;background:var(--horizon-table-hover);color:var(--horizon-text-title);font-weight:800;font-size:12px}
.quiz-opt.sel .opt-letter{background:var(--horizon-brand-500);color:#fff}
#quizSubmitOverlay{position:fixed;inset:0;z-index:2000;display:none;align-items:center;justify-content:center;background:rgba(15,23,42,.55);padding:16px}
</style>
</head>
<body class="horizon-page-bg">
<nav id="horizon-navbar" style="margin:12px 20px">
  <div class="horizon-breadcrumb-area"><div class="horizon-breadcrumb"><a href="index.php">Student</a> <span style="opacity:.5">/</span> Quiz</div>
  <h1 class="horizon-page-title" style="font-size:16px"><i class="fas fa-pen-to-square me-2" style="color:var(--horizon-brand-500)"></i><?php echo $quiz_meta ? htmlspecialchars($quiz_meta['title']) : 'Quiz'; ?></h1></div>
  <div class="horizon-nav-pill-toolbar">
    <button type="button" id="horizon-theme-toggle" class="horizon-nav-icon-btn" aria-label="Enable dark mode" title="Enable dark mode" style="background:var(--horizon-brand-50);color:var(--horizon-brand-500)"><i class="fas fa-moon"></i></button>
    <span class="badge badge-secondary" id="quizTimer" style="display:none"><i class="fas fa-clock me-1"></i><span id="quizTimerText">--:--</span></span>
    <span class="badge badge-warning" id="violationBadge" title="Tab-switch / minimize violations"><i class="fas fa-shield-halved me-1"></i>Violations: <span id="violationCount">0</span>/3</span>
  </div>
</nav>
<main class="quiz-shell">
<?php if ($gate_error !== ''): ?>
  <div class="horizon-card"><div class="horizon-card-body text-center" style="padding:36px">
    <i class="fas fa-triangle-exclamation text-warning mb-3 d-block" style="font-size:28px"></i>
    <h5 class="fw-bold"><?php echo htmlspecialchars($gate_error); ?></h5>
    <a href="index.php" class="btn btn-primary mt-3"><i class="fas fa-arrow-left me-1"></i>Back to dashboard</a>
  </div></div>
<?php else: ?>
  <div id="secureBar" class="horizon-flash-banner horizon-flash-warning mb-3"><i class="fas fa-shield-halved"></i><span style="font-weight:700;font-size:12px">Secure mode: stay on this tab. Switching tabs, minimizing, or running this browser in the background is detected, logged, and auto-submits after 3 violations. Copying questions out or pasting text in (e.g. to use AI apps like ChatGPT/Gemini) is also detected and logged. Copy / right-click / print are disabled.</span></div>
  <div id="quizBody"><div class="horizon-card"><div class="horizon-card-body text-center py-5"><div class="spinner-border text-primary"></div><div class="small text-muted mt-2">Loading your quiz…</div></div></div></div>
<?php endif; ?>
</main>
<div id="gateOverlay" style="display:none"><div class="horizon-card" style="max-width:440px;width:100%"><div class="horizon-card-body text-center" style="padding:28px">
  <i class="fas fa-triangle-exclamation text-danger mb-2 d-block" style="font-size:30px"></i>
  <h5 class="fw-bold" id="gateTitle">Warning</h5>
  <p class="small text-muted" id="gateText"></p>
  <button class="btn btn-primary" id="gateBtn">I understand — continue</button>
</div></div></div>
<div id="doneWrap" style="display:none" class="quiz-shell"><div class="horizon-card"><div class="horizon-card-body text-center" style="padding:36px">
  <i class="fas fa-circle-check text-success mb-3 d-block" style="font-size:32px"></i>
  <h4 class="fw-bold" id="doneTitle">Submitted</h4>
  <p class="text-muted" id="doneText"></p>
  <a href="index.php" class="btn btn-primary"><i class="fas fa-arrow-left me-1"></i>Back to dashboard</a>
</div></div></div>
<div id="quizSubmitOverlay" style="display:none"><div class="horizon-card" style="max-width:440px;width:100%"><div class="horizon-card-body text-center" style="padding:28px">
  <span class="d-inline-flex align-items-center justify-content-center rounded-circle mb-3" style="width:56px;height:56px;font-size:22px;background:rgba(67,24,255,.1);color:var(--horizon-brand-500)"><i class="fas fa-paper-plane"></i></span>
  <h5 class="fw-bold" style="color:var(--horizon-text-title)">Submit quiz?</h5>
  <p class="small text-muted" id="quizSubmitSummary"></p>
  <div class="d-flex gap-2 justify-content-center">
    <button class="btn btn-secondary rounded-pill px-4" id="quizSubmitKeep">Keep answering</button>
    <button class="btn btn-primary rounded-pill px-4 fw-bold" id="quizSubmitGo"><i class="fas fa-check me-1"></i>Submit now</button>
  </div>
</div></div></div>
<script src="../js/bootstrap.bundle.min.js"></script>
<script>
// Horizon dark-mode toggle (same localStorage key as the portal).
(function(){
    var btn = document.getElementById('horizon-theme-toggle');
    function paint(){
        var dark = document.documentElement.getAttribute('data-theme') === 'dark';
        document.body.classList.toggle('dark', dark);
        if (btn){
            btn.innerHTML = '<i class="fas fa-' + (dark ? 'sun' : 'moon') + '"></i>';
            btn.setAttribute('aria-label', dark ? 'Enable light mode' : 'Enable dark mode');
            btn.title = dark ? 'Enable light mode' : 'Enable dark mode';
        }
    }
    paint();
    if (btn) btn.addEventListener('click', function(){
        var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
        document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
        try { localStorage.setItem('horizon-theme', dark ? 'dark' : 'light'); } catch (e) {}
        paint();
    });
})();
</script>
<?php if ($gate_error === ''): ?>
<script>
(function(){
'use strict';
var Q = <?php echo (int)$quiz_id; ?>, C = <?php echo (int)$class_id; ?>, K = <?php echo json_encode($db_key); ?>;
var questions = [], displayOrder = [], quizMeta = null, violations = 0, submitted = false, timerSecs = 0, timerHandle = null, warnCooldownUntil = 0;
var MAX_VIOLATIONS = 3;
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function fmtQ(s){ s = String(s == null ? '' : s); s = s.replace(/^Choose the correct answer:[ \t]+/, 'Choose the correct answer:\n\n'); return esc(s).replace(/\r?\n/g, '<br>'); }
function showGate(title, text, btnLabel){
    var o = document.getElementById('gateOverlay');
    document.getElementById('gateTitle').textContent = title;
    document.getElementById('gateText').textContent = text;
    document.getElementById('gateBtn').textContent = btnLabel || 'I understand — continue';
    o.style.display = 'flex';
}
document.getElementById('gateBtn').addEventListener('click', function(){
    document.getElementById('gateOverlay').style.display = 'none';
    try { document.documentElement.requestFullscreen().catch(function(){}); } catch (e) {}
});
document.getElementById('quizSubmitKeep').addEventListener('click', function(){
    document.getElementById('quizSubmitOverlay').style.display = 'none';
});
document.getElementById('quizSubmitGo').addEventListener('click', function(){
    document.getElementById('quizSubmitOverlay').style.display = 'none';
    submitQuiz(false);
});
function setViolations(n){
    violations = n;
    document.getElementById('violationCount').textContent = n;
    var b = document.getElementById('violationBadge');
    b.classList.remove('violation-shake'); void b.offsetWidth; b.classList.add('violation-shake');
}
function logViolation(reason){
    if (submitted) return;
    var fd = new FormData();
    fd.append('action', 'violate'); fd.append('quiz_id', Q); fd.append('class_id', C); fd.append('db_key', K); fd.append('reason', reason);
    fetch('quiz_api.php', { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function(r){ return r.json(); }).then(function(j){
            if (j && j.status === 'success' && typeof j.violations !== 'undefined') setViolations(j.violations);
        }).catch(function(){});
    // local immediate feedback even if network lags
    setViolations(violations + 1);
    if (violations + 1 >= MAX_VIOLATIONS || violations >= MAX_VIOLATIONS){ autoSubmit('Too many tab-switch violations'); return; }
    if (Date.now() > warnCooldownUntil){
        warnCooldownUntil = Date.now() + 8000;
        showGate('Warning ' + violations + ' of ' + MAX_VIOLATIONS, 'Leaving this tab, minimizing, or putting this browser in the background is not allowed during the quiz. This incident was logged. One more set of violations will auto-submit your answers.', 'I understand — continue');
    }
    if (violations >= MAX_VIOLATIONS) autoSubmit('Too many tab-switch violations');
}
function collectAnswers(){
    var ans = {};
    questions.forEach(function(q){
        if (q.qtype === 'multiple_choice'){
            var sel = document.querySelector('input[name="ans' + q.question_id + '"]:checked');
            if (sel) ans[q.question_id] = sel.value;
        } else if (q.qtype === 'true_false'){
            var sel2 = document.querySelector('input[name="ans' + q.question_id + '"]:checked');
            if (sel2) ans[q.question_id] = sel2.value;
        } else {
            var inp = document.getElementById('ans' + q.question_id);
            if (inp && inp.value.trim() !== '') ans[q.question_id] = inp.value.trim();
        }
    });
    return ans;
}
function typeBadge(t){
    if (t === 'identification') return '<span class="badge badge-secondary">ID · Identification</span>';
    if (t === 'true_false') return '<span class="badge badge-success">T/F · True or False</span>';
    return '<span class="badge badge-brand">MC · Multiple Choice</span>';
}
function isAnswered(q){
    if (q.qtype === 'identification'){
        var inp = document.getElementById('ans' + q.question_id);
        return !!(inp && inp.value.trim() !== '');
    }
    return !!document.querySelector('input[name="ans' + q.question_id + '"]:checked');
}
function updateProgress(){
    var done = 0, total = displayOrder.length;
    displayOrder.forEach(function(q, i){
        var ok = isAnswered(q);
        if (ok) done++;
        var pal = document.querySelector('#quizPalette .quiz-pal[data-i="' + i + '"]');
        if (pal) pal.classList.toggle('answered', ok);
        var flag = document.querySelector('.quiz-ans-flag[data-flag="' + q.question_id + '"]');
        if (flag) flag.innerHTML = ok ? '<span class="badge badge-success" style="font-size:9px"><i class="fas fa-check me-1"></i>Answered</span>' : '';
    });
    var badge = document.getElementById('quizProgBadge');
    if (badge) badge.textContent = done + '/' + total;
    var fill = document.getElementById('quizProgFill');
    if (fill) fill.style.width = (total ? Math.round(100 * done / total) : 0) + '%';
    var note = document.getElementById('quizFootNote');
    if (note) note.textContent = done + ' of ' + total + ' answered' + (done < total ? ' · ' + (total - done) + ' remaining' : ' · all done — good luck!');
}
function openSubmitModal(){
    var done = 0, total = displayOrder.length;
    displayOrder.forEach(function(q){ if (isAnswered(q)) done++; });
    document.getElementById('quizSubmitSummary').innerHTML = 'You answered <strong>' + done + '</strong> of <strong>' + total + '</strong>.' + (done < total ? '<br><span class="text-warning fw-bold">Unanswered: ' + (total - done) + ' — blank answers score zero.</span>' : '<br>All questions answered.');
    document.getElementById('quizSubmitOverlay').style.display = 'flex';
}
function render(){
    var body = document.getElementById('quizBody');
    // Shuffle display order per student load so "number X is answer Y" notes
    // can't be shared between seats. Grading is by question_id, unaffected.
    var order = questions.slice();
    for (var s = order.length - 1; s > 0; s--){ var rr = Math.floor(Math.random() * (s + 1)); var tt = order[s]; order[s] = order[rr]; order[rr] = tt; }
    displayOrder = order;
    var total = order.length;
    var h = '<div class="quiz-head"><div class="d-flex align-items-center gap-2 flex-wrap mb-2">'
        + '<span class="horizon-widget-icon-box brand" style="width:40px;height:40px;min-width:40px;font-size:16px"><i class="fas fa-pen-to-square"></i></span>'
        + '<div class="flex-grow-1" style="min-width:200px"><div class="fw-bold" style="font-size:14px;color:var(--horizon-text-title)">' + esc(quizMeta ? quizMeta.title : 'Quiz') + '</div>'
        + '<div class="small" style="color:var(--horizon-text-muted);font-weight:600">' + esc(quizMeta ? (quizMeta.quiz_type_label || '') : '') + ' · ' + total + ' questions' + ((quizMeta && quizMeta.time_limit_minutes > 0) ? ' · ' + quizMeta.time_limit_minutes + ' min limit' : '') + '</div></div>'
        + '<span class="badge badge-brand" id="quizProgBadge">0/' + total + '</span></div>'
        + '<div class="quiz-progress mb-2"><div id="quizProgFill"></div></div>'
        + '<div class="quiz-pal-grid" id="quizPalette">';
    order.forEach(function(q, i){ h += '<button type="button" class="quiz-pal" data-i="' + i + '" title="Go to question ' + (i + 1) + '">' + (i + 1) + '</button>'; });
    h += '</div></div>';
    var letters = 'ABCDEF';
    order.forEach(function(q, i){
        h += '<div class="quiz-q" id="qq' + q.question_id + '"><div class="quiz-q-head"><span class="badge badge-secondary">#' + (i + 1) + '</span>' + typeBadge(q.qtype) + '<span class="ms-auto quiz-ans-flag" data-flag="' + q.question_id + '"></span></div>';
        h += '<h6>' + fmtQ(q.question) + '</h6>';
        if (q.qtype === 'identification'){
            h += '<input type="text" class="form-control mt-2" id="ans' + q.question_id + '" placeholder="Type your answer…" autocomplete="off" autocapitalize="off" spellcheck="false">';
        } else {
            (q.choices || []).forEach(function(c, ci){
                var id = 'q' + q.question_id + '_' + ci;
                h += '<label class="quiz-opt" for="' + id + '"><input type="radio" class="form-check-input mt-1" name="ans' + q.question_id + '" id="' + id + '" value="' + esc(c) + '"><span class="opt-letter">' + (letters[ci] || (ci + 1)) + '</span><span>' + esc(c) + '</span></label>';
            });
        }
        h += '</div>';
    });
    h += '<div class="horizon-card"><div class="horizon-card-body d-flex align-items-center gap-3 flex-wrap"><div><div class="fw-bold" style="font-size:14px;color:var(--horizon-text-title)">Ready to submit?</div><div class="small" style="color:var(--horizon-text-muted);font-weight:600" id="quizFootNote"></div></div><button class="btn btn-primary ms-auto fw-bold px-4" id="quizSubmitBtn"><i class="fas fa-paper-plane me-1"></i>Submit answers</button></div></div>';
    body.innerHTML = h;
    body.querySelectorAll('.quiz-opt input').forEach(function(r){
        r.addEventListener('change', function(){
            body.querySelectorAll('input[name="' + r.name + '"]').forEach(function(x){ x.closest('.quiz-opt').classList.remove('sel'); });
            r.closest('.quiz-opt').classList.add('sel');
            updateProgress();
        });
    });
    body.querySelectorAll('input[type="text"]').forEach(function(inp){
        inp.addEventListener('input', updateProgress);
    });
    body.querySelectorAll('#quizPalette .quiz-pal').forEach(function(b){
        b.addEventListener('click', function(){
            var q = displayOrder[parseInt(b.getAttribute('data-i'), 10)];
            if (!q) return;
            var el = document.getElementById('qq' + q.question_id);
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    });
    document.getElementById('quizSubmitBtn').addEventListener('click', openSubmitModal);
    updateProgress();
}
function startTimer(mins){
    if (!mins || mins <= 0) return;
    timerSecs = mins * 60;
    var badge = document.getElementById('quizTimer');
    badge.style.display = '';
    function tick(){
        if (submitted) return;
        var m = Math.floor(timerSecs / 60), s = timerSecs % 60;
        document.getElementById('quizTimerText').textContent = (m < 10 ? '0' + m : m) + ':' + (s < 10 ? '0' + s : s);
        if (timerSecs <= 0){ autoSubmit('Time is up'); return; }
        timerSecs--;
        timerHandle = setTimeout(tick, 1000);
    }
    tick();
}
function finishView(title, text){
    submitted = true;
    if (timerHandle) clearTimeout(timerHandle);
    document.getElementById('quizBody').style.display = 'none';
    var sb = document.getElementById('secureBar'); if (sb) sb.style.display = 'none';
    var w = document.getElementById('doneWrap'); w.style.display = 'block';
    document.getElementById('doneTitle').textContent = title;
    document.getElementById('doneText').textContent = text;
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
function submitQuiz(auto){
    if (submitted) return;
    submitted = true;
    var fd = new FormData();
    fd.append('action', 'submit'); fd.append('quiz_id', Q); fd.append('class_id', C); fd.append('db_key', K);
    fd.append('answers', JSON.stringify(collectAnswers()));
    if (auto) fd.append('auto', '1');
    fetch('quiz_api.php', { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
            if (j && (j.status === 'success' || j.status === 'submitted')){
                finishView(auto ? 'Auto-submitted' : 'Quiz submitted', 'Your score: ' + j.score + ' out of ' + j.total + (auto ? ' (auto-submitted for a security violation / time limit).' : '.'));
            } else { submitted = false; alert((j && j.msg) || 'Submit failed — please retry.'); }
        })
        .catch(function(){ submitted = false; alert('Network error — please check your connection and retry.'); });
}
function autoSubmit(reason){
    if (submitted) return;
    showGate('Auto-submitting', reason + '. Your current answers are being submitted now.', 'OK');
    setTimeout(function(){ submitQuiz(true); }, 1200);
}
// ---- boot: fetch questions (answers stay server-side) ----
(function boot(){
    var fd = new FormData();
    fd.append('action', 'start'); fd.append('quiz_id', Q); fd.append('class_id', C); fd.append('db_key', K);
    fetch('quiz_api.php', { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(j){
            if (j && j.status === 'submitted'){ finishView('Already submitted', 'Your score: ' + j.score + ' out of ' + j.total + '.'); return; }
            if (!j || j.status !== 'success' || !j.questions || !j.questions.length) throw new Error((j && j.msg) || 'Could not load the quiz.');
            questions = j.questions;
            quizMeta = j.quiz || null;
            if (j.violations) setViolations(j.violations);
            render();
            startTimer(j.quiz.time_limit_minutes);
            armSecurity();
            showGate('Secure quiz mode', 'Do not switch tabs, minimize, or background this browser. Violations are logged and 3 violations auto-submit your quiz.', 'Begin quiz');
        })
        .catch(function(e){ document.getElementById('quizBody').innerHTML = '<div class="horizon-card"><div class="horizon-card-body text-center text-danger py-5">' + esc(e.message) + '<br><a href="index.php" class="btn btn-secondary mt-3">Back to dashboard</a></div></div>'; });
})();
// ---- anti-tab-switch / background / devtools security ----
function armSecurity(){
    var lastHiddenReport = 0;
    document.addEventListener('visibilitychange', function(){
        if (document.hidden){ if (Date.now() - lastHiddenReport > 1500){ lastHiddenReport = Date.now(); logViolation('tab_hidden'); } }
    });
    window.addEventListener('blur', function(){
        // blur fires when the window loses focus: new tab, another app, minimize
        if (!submitted && !document.hidden) logViolation('window_blur');
    });
    window.addEventListener('pagehide', function(){ if (!submitted) logViolation('page_hide'); });
    document.addEventListener('mouseleave', function(e){ if (!e.relatedTarget && !submitted && !document.hidden){ /* pointer left window — soft signal only */ } });
    document.addEventListener('contextmenu', function(e){ e.preventDefault(); return false; });
    // Exfiltration tripwire (anti-AI-search): the page cannot see inside
    // ChatGPT/Gemini/another tab — browsers isolate those — but copying
    // question text OUT (to feed an AI app) or pasting text IN (from an AI
    // answer) happens on THIS page and is observable, so every attempt is
    // blocked and logged as a violation.
    var lastExfilReport = 0;
    function reportExfil(kind){
        var now = Date.now();
        if (now - lastExfilReport < 5000) return; // at most one strike per 5s
        lastExfilReport = now;
        logViolation('exfil_' + kind);
    }
    document.addEventListener('copy', function(e){ e.preventDefault(); reportExfil('copy'); return false; });
    document.addEventListener('cut', function(e){ e.preventDefault(); reportExfil('cut'); return false; });
    document.addEventListener('paste', function(e){ e.preventDefault(); reportExfil('paste'); return false; });
    document.addEventListener('dragstart', function(e){ e.preventDefault(); reportExfil('drag'); return false; });
    document.addEventListener('keydown', function(e){
        var k = e.keyCode || e.which;
        if (k === 123) { e.preventDefault(); logViolation('devtools_f12'); return false; } // F12
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (k === 73 || k === 74 || k === 67)) { e.preventDefault(); logViolation('devtools_shortcut'); return false; }
        if ((e.ctrlKey || e.metaKey) && (k === 85 || k === 83 || k === 80)) { e.preventDefault(); return false; } // U/S/P
        if ((e.ctrlKey || e.metaKey) && k === 84) { /* Ctrl+T cannot be blocked; blur handler logs it */ }
    });
    window.addEventListener('beforeprint', function(e){ e.preventDefault(); return false; });
    window.addEventListener('beforeunload', function(e){
        if (!submitted){ e.preventDefault(); e.returnValue = ''; logViolation('navigate_away'); }
    });
    // Detect devtools-docked resizing heuristic (supplementary; primary is visibility/blur)
    var devtoolsOpen = false;
    setInterval(function(){
        if (submitted) return;
        var threshold = 170;
        var open = (window.outerWidth - window.innerWidth > threshold) || (window.outerHeight - window.innerHeight > threshold);
        if (open && !devtoolsOpen){ devtoolsOpen = true; logViolation('devtools_open'); }
        else if (!open){ devtoolsOpen = false; }
    }, 2500);
}
})();
</script>
<?php endif; ?>
</body>
</html>
