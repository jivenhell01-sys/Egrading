/* HORIZON offline layer — IndexedDB snapshot + outbox, synced with the
 * server SQLite3 via students/api_sync.php (pull = download my data,
 * push = upload queued actions like attendance confirmations).
 *
 * Two globals:
 *   HorizonDB   — promise-based IndexedDB access (snapshot + outbox queue)
 *   HorizonSync — pull()/push()/syncNow() driver + 'horizon-sync' DOM events
 *
 * Offline-first rules: reads never throw (resolve null/[] when IDB is
 * unavailable); writes are best-effort. Quiz taking always needs internet —
 * only quiz METADATA (titles, limits) is cached, never questions/answers.
 */
(function (global) {
    'use strict';

    var DB_NAME = 'horizon-student';
    var DB_VERSION = 1;
    var KV_SNAPSHOT = 'snapshot';
    var KV_SAVED_AT = 'saved_at';
    var MAX_OUTBOX = 50;
    var MAX_ATTEMPTS = 10;

    function emit(kind, detail) {
        try {
            var d = detail || {};
            d.kind = kind;
            document.dispatchEvent(new CustomEvent('horizon-sync', { detail: d }));
        } catch (e) { /* listeners are optional */ }
    }

    function idb() {
        return new Promise(function (resolve, reject) {
            if (!('indexedDB' in global)) {
                reject(new Error('IndexedDB unavailable'));
                return;
            }
            var req;
            try {
                req = global.indexedDB.open(DB_NAME, DB_VERSION);
            } catch (e) {
                reject(e);
                return;
            }
            req.onupgradeneeded = function () {
                var db = req.result;
                if (!db.objectStoreNames.contains('kv')) db.createObjectStore('kv');
                if (!db.objectStoreNames.contains('outbox')) {
                    db.createObjectStore('outbox', { keyPath: 'id', autoIncrement: true });
                }
            };
            req.onsuccess = function () { resolve(req.result); };
            req.onerror = function () { reject(req.error || new Error('IDB open failed')); };
        });
    }

    function txGet(store, key) {
        return idb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var t;
                try {
                    t = db.transaction(store, 'readonly').objectStore(store).get(key);
                } catch (e) { reject(e); return; }
                t.onsuccess = function () { resolve(t.result === undefined ? null : t.result); };
                t.onerror = function () { reject(t.error || new Error('IDB read failed')); };
            });
        });
    }

    function txPut(store, key, val) {
        return idb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var t;
                try {
                    var os = db.transaction(store, 'readwrite').objectStore(store);
                    t = (key === undefined) ? os.add(val) : os.put(val, key);
                } catch (e) { reject(e); return; }
                t.onsuccess = function () { resolve(t.result); };
                t.onerror = function () { reject(t.error || new Error('IDB write failed')); };
            });
        });
    }

    function txAll(store) {
        return idb().then(function (db) {
            return new Promise(function (resolve, reject) {
                var rows = [];
                var cursorReq;
                try {
                    cursorReq = db.transaction(store, 'readonly').objectStore(store).openCursor();
                } catch (e) { reject(e); return; }
                cursorReq.onsuccess = function () {
                    var c = cursorReq.result;
                    if (c) { rows.push(c.value); c.continue(); }
                    else resolve(rows);
                };
                cursorReq.onerror = function () { reject(cursorReq.error || new Error('IDB scan failed')); };
            });
        });
    }

    function txDelete(store, key) {
        return idb().then(function (db) {
            return new Promise(function (resolve) {
                try {
                    var r = db.transaction(store, 'readwrite').objectStore(store).delete(key);
                    r.onsuccess = function () { resolve(true); };
                    r.onerror = function () { resolve(false); };
                } catch (e) { resolve(false); }
            });
        });
    }

    var HorizonDB = {
        supported: ('indexedDB' in global),

        /** Persist a pull snapshot; stamps client-side saved_at. */
        saveSnapshot: function (snap) {
            if (!snap || typeof snap !== 'object') return Promise.resolve(false);
            snap.saved_at = new Date().toISOString();
            return txPut('kv', KV_SNAPSHOT, snap)
                .then(function () { return txPut('kv', KV_SAVED_AT, snap.saved_at); })
                .then(function () { emit('pull-saved', { saved_at: snap.saved_at }); return true; })
                .catch(function () { return false; });
        },

        /** Last snapshot, or null when never synced / IDB unavailable. */
        getSnapshot: function () {
            return txGet('kv', KV_SNAPSHOT).catch(function () { return null; });
        },

        getSavedAt: function () {
            return txGet('kv', KV_SAVED_AT).catch(function () { return null; });
        },

        /** Queue an offline action. Returns the queue id, or 0 when full/unsupported. */
        queueAction: function (type, payload) {
            return txAll('outbox').catch(function () { return null; }).then(function (rows) {
                if (!rows) return 0;
                if (rows.length >= MAX_OUTBOX) return 0;
                var item = {
                    type: String(type || ''),
                    payload: payload || {},
                    created_at: new Date().toISOString(),
                    attempts: 0
                };
                return txPut('outbox', undefined, item).then(
                    function (id) { emit('queued', { id: id, type: item.type }); return id; },
                    function () { return 0; }
                );
            });
        },

        listOutbox: function () {
            return txAll('outbox').catch(function () { return []; });
        },

        removeOutbox: function (ids) {
            return Promise.all((ids || []).map(function (id) { return txDelete('outbox', id); }));
        },

        bumpAttempts: function (ids) {
            if (!ids || !ids.length) return Promise.resolve(true);
            return idb().then(function (db) {
                return Promise.all(ids.map(function (id) {
                    return new Promise(function (resolve) {
                        try {
                            var os = db.transaction('outbox', 'readwrite').objectStore('outbox');
                            var g = os.get(id);
                            g.onsuccess = function () {
                                var v = g.result;
                                if (!v) { resolve(false); return; }
                                v.attempts = (v.attempts | 0) + 1;
                                if (v.attempts >= MAX_ATTEMPTS) {
                                    var d = os.delete(id);
                                    d.onsuccess = function () { resolve(true); };
                                    d.onerror = function () { resolve(false); };
                                } else {
                                    var p = os.put(v);
                                    p.onsuccess = function () { resolve(true); };
                                    p.onerror = function () { resolve(false); };
                                }
                            };
                            g.onerror = function () { resolve(false); };
                        } catch (e) { resolve(false); }
                    });
                }));
            }).catch(function () { return false; });
        }
    };

    var HorizonSync = {
        online: function () {
            return (typeof navigator === 'undefined' || navigator.onLine !== false);
        },

        /** GET api_sync.php?action=pull → save snapshot. Resolves snapshot or null. */
        pull: function () {
            if (!this.online()) { emit('offline-skip', { op: 'pull' }); return Promise.resolve(null); }
            return fetch('api_sync.php?action=pull', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
                .then(function (r) {
                    if (!r.ok) throw new Error('HTTP ' + r.status);
                    return r.json();
                })
                .then(function (j) {
                    if (!j || j.status !== 'success' || !j.snapshot) throw new Error((j && j.msg) || 'Bad snapshot');
                    return HorizonDB.saveSnapshot(j.snapshot).then(function () { return j.snapshot; });
                })
                .catch(function (err) {
                    emit('pull-failed', { error: String((err && err.message) || err) });
                    return null;
                });
        },

        /** POST queued outbox actions; server acks remove items. Resolves counts. */
        push: function () {
            if (!this.online()) { emit('offline-skip', { op: 'push' }); return Promise.resolve({ pushed: 0, pending: 0 }); }
            return HorizonDB.listOutbox().then(function (rows) {
                if (!rows.length) return { pushed: 0, pending: 0 };
                var actions = rows.map(function (it) {
                    return { client_id: it.id, type: it.type, payload: it.payload };
                });
                return fetch('api_sync.php?action=push', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify({ actions: actions })
                })
                    .then(function (r) {
                        if (!r.ok) throw new Error('HTTP ' + r.status);
                        return r.json();
                    })
                    .then(function (j) {
                        var done = [];
                        var retry = [];
                        var byId = {};
                        actions.forEach(function (a) { byId[a.client_id] = a; });
                        (j && j.results ? j.results : []).forEach(function (res) {
                            // success/info/expired all settle the item: the
                            // server already applied it, deduped it, or the
                            // window (e.g. today's session) is gone.
                            if (res && (res.status === 'success' || res.status === 'info' || res.status === 'expired')) done.push(res.client_id);
                            else if (res) retry.push(res.client_id);
                        });
                        // Unknown items (missing from results) stay queued.
                        return HorizonDB.removeOutbox(done).then(function () {
                            return HorizonDB.bumpAttempts(retry);
                        }).then(function () {
                            var out = { pushed: done.length, pending: retry.length };
                            emit('push', out);
                            return out;
                        });
                    })
                    .catch(function (err) {
                        emit('push-failed', { error: String((err && err.message) || err) });
                        return { pushed: 0, pending: rows.length };
                    });
            });
        },

        /** Push first, then pull — one call for page boot / reconnect. */
        syncNow: function () {
            var self = this;
            return self.push().then(function () { return self.pull(); });
        }
    };

    global.HorizonDB = HorizonDB;
    global.HorizonSync = HorizonSync;
})(typeof window !== 'undefined' ? window : this);
