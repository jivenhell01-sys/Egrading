/* HORIZON student portal service worker (v2 — offline-capable).
 *
 * Static assets: cache-first. Navigations (login/index pages): network-first
 * with runtime caching — a successfully loaded page is kept so the installed
 * app still opens without internet (it then renders the IndexedDB snapshot
 * saved by js/offline-db.js). API calls (api_*.php, POSTs) always go to the
 * network; when unreachable the page falls back to its cached copy, else
 * offline.html.
 *
 * Single-user bound device: the cached HTML belongs to the device owner, so
 * keeping it is safe. logout.php responses are never cached. */
const CACHE = 'horizon-students-v2';
const CORE = [
  'offline.html',
  'manifest.webmanifest',
  'icons/icon-192.png',
  'js/offline-db.js'
];
const MAX_PAGES = 15;

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

function trimPages() {
  return caches.open(CACHE).then((c) =>
    c.keys().then((keys) => {
      const pages = keys.filter((r) => {
        const u = new URL(r.url);
        return u.origin === self.location.origin && !/\.(css|js|png|ico|webmanifest|woff2?|ttf)(\?|$)/.test(u.pathname);
      });
      if (pages.length <= MAX_PAGES) return;
      const extra = pages.slice(0, pages.length - MAX_PAGES);
      return Promise.all(extra.map((r) => c.delete(r)));
    })
  );
}

self.addEventListener('fetch', (e) => {
  const { request } = e;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  // Never cache: logout (session end) and live JSON APIs (must stay fresh;
  // the client keeps its own IndexedDB snapshot instead).
  if (/logout\.php(\?|$)/.test(url.pathname) || /api_(sync|grades)\.php(\?|$)/.test(url.pathname)) {
    return;
  }
  if (request.mode === 'navigate') {
    e.respondWith(
      fetch(request)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(request, copy)).then(trimPages);
          return res;
        })
        .catch(() =>
          caches.match(request).then((hit) => hit || caches.match('offline.html'))
        )
    );
    return;
  }
  if (/(\.css|\.js|\.png|\.ico|\.webmanifest|\.woff2?|\.ttf)(\?|$)/.test(url.pathname)) {
    e.respondWith(
      caches.match(request).then(
        (hit) =>
          hit ||
          fetch(request).then((res) => {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(request, copy));
            return res;
          })
      )
    );
  }
});
