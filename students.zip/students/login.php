<?php
// Configure session for student system to avoid conflicts with admin system
if (session_status() === PHP_SESSION_NONE) {
    // Compute cookie path dynamically so it works both at /students/ (root deploy)
    // and at /grading_system/students/ (XAMPP subfolder). Must be a prefix of
    // the request URI or the browser will not send the cookie to index.php.
    $studentCookiePath = '/students/';
    if (!empty($_SERVER['SCRIPT_NAME'])) {
        $d = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
        if ($d !== '' && $d !== '.' && $d !== '/') {
            $studentCookiePath = $d . '/';
        }
    }
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => $studentCookiePath,
        'domain' => '',
        'secure' => false,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}
require_once('../DBConnection.php');

// Check if student is already logged in
if (isset($_SESSION['student_logged_in']) && $_SESSION['student_logged_in'] === true) {
    header('Location: index.php');
    exit();
}

$error_message = '';
$blocked_details = null; // for richer blocked UI

// ------------------------------------------------------------------
// Device binding helpers — MAIN database only (global binding)
// ------------------------------------------------------------------
define('HGS_MAIN_DB', __DIR__ . '/../db/grading_db.db');

function hgs_get_client_ip() {
    $keys = ['HTTP_X_FORWARDED_FOR','HTTP_CLIENT_IP','REMOTE_ADDR'];
    foreach ($keys as $k) {
        if (!empty($_SERVER[$k])) {
            $v = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($v, FILTER_VALIDATE_IP)) return $v;
            if ($v !== '') return $v;
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function hgs_parse_device_build_fallback($ua) {
    $ua = (string)$ua;
    // Build number: the token after "Build/" (e.g. TP1A.220624.014) — NOT
    // the model number (e.g. SM-A127F) that precedes it in Android UAs.
    if (preg_match('/Build\/([^\s;\)]+)/i', $ua, $m)) {
        $cand = trim($m[1]);
        if (preg_match('/[A-Za-z0-9]/', $cand) && strlen($cand) >= 2 && strlen($cand) <= 40) {
            return $cand;
        }
    }
    if (preg_match('/iPhone/i', $ua)) return 'iPhone';
    if (preg_match('/iPad/i', $ua)) return 'iPad';
    if (preg_match('/Android/i', $ua)) return 'Android Device';
    if (preg_match('/Windows NT/i', $ua)) return 'Windows PC';
    if (preg_match('/Macintosh|Mac OS X/i', $ua)) return 'Mac';
    if (preg_match('/CrOS/i', $ua)) return 'Chromebook';
    if (preg_match('/Linux/i', $ua)) return 'Linux PC';
    return 'Unknown Device';
}

function hgs_ensure_device_tables(PDO $pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `student_device_bindings` (
        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        `student_number` TEXT NOT NULL UNIQUE,
        `student_name` TEXT,
        `device_fingerprint` TEXT NOT NULL,
        `device_family` TEXT NOT NULL DEFAULT '',
        `device_unique_no` TEXT,
        `device_token` TEXT,
        `device_model` TEXT,
        `device_serial` TEXT,
        `device_android_id` TEXT,
        `device_fb` TEXT,
        `webauthn_credential_id` TEXT,
        `webauthn_public_key` TEXT,
        `webauthn_sign_count` INTEGER NOT NULL DEFAULT 0,
        `device_raw` TEXT,
        `platform` TEXT,
        `ip_address` TEXT,
        `user_agent` TEXT,
        `screen_resolution` TEXT,
        `timezone` TEXT,
        `first_seen` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `last_seen` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `is_active` INTEGER NOT NULL DEFAULT 1
    )");
    $pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_sdb_student_number ON `student_device_bindings`(`student_number`)");
    // NOTE: no UNIQUE index on device_fingerprint by design — identical
    // devices legitimately report identical fingerprints, and the family rule
    // (not the fingerprint) is what locks one device to one student.
    try { @$pdo->exec("DROP INDEX IF EXISTS idx_sdb_fingerprint"); } catch (Exception $e) {}
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdb_last_seen ON `student_device_bindings`(`last_seen`)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdb_family ON `student_device_bindings`(`device_family`)");
    // Lightweight migration for installs created before newer columns.
    try {
        $haveB = [];
        $ti = $pdo->query("PRAGMA table_info('student_device_bindings')");
        if ($ti) foreach ($ti->fetchAll(PDO::FETCH_ASSOC) as $cr) {
            if (isset($cr['name'])) $haveB[] = $cr['name'];
        }
        if (!in_array('device_family', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_family` TEXT NOT NULL DEFAULT ''");
        if (!in_array('device_unique_no', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_unique_no` TEXT");
        if (!in_array('device_token', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_token` TEXT");
        // Retired IMEI columns: unreadable from browsers, and regular apps
        // are blocked from IMEI since Android 10. ANDROID_ID (device_aid
        // POST below) is the hardware identifier now. DROP needs SQLite
        // 3.35+ — older engines throw here and the unused columns simply stay.
        if (in_array('device_imei1', $haveB, true)) { try { @$pdo->exec("ALTER TABLE `student_device_bindings` DROP COLUMN `device_imei1`"); } catch (Exception $e) {} }
        if (in_array('device_imei2', $haveB, true)) { try { @$pdo->exec("ALTER TABLE `student_device_bindings` DROP COLUMN `device_imei2`"); } catch (Exception $e) {} }
        if (!in_array('device_serial', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_serial` TEXT");
        if (!in_array('device_android_id', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_android_id` TEXT");
        if (!in_array('device_fb', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `device_fb` TEXT");
        // WebAuthn device key: credential id + PEM public key + sign counter.
        if (!in_array('webauthn_credential_id', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `webauthn_credential_id` TEXT");
        if (!in_array('webauthn_public_key', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `webauthn_public_key` TEXT");
        if (!in_array('webauthn_sign_count', $haveB, true)) $pdo->exec("ALTER TABLE `student_device_bindings` ADD COLUMN `webauthn_sign_count` INTEGER NOT NULL DEFAULT 0");
    } catch (Exception $e) {}
    // NOTE: the per-browser table (student_device_browsers) was removed on
    // purpose — a globally UNIQUE browser fingerprint blocked other students
    // even on different (identical-model) devices. One row per student in
    // student_device_bindings is the whole model now; the family rule below
    // is the only cross-student lock. Legacy tables are left untouched.
    $pdo->exec("CREATE TABLE IF NOT EXISTS `student_device_logs` (
        `id` INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
        `student_number` TEXT NOT NULL,
        `device_fingerprint` TEXT,
        `device_model` TEXT,
        `ip_address` TEXT,
        `user_agent` TEXT,
        `status` TEXT NOT NULL,
        `details` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdl_student_number ON `student_device_logs`(`student_number`)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdl_status ON `student_device_logs`(`status`)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdl_created_at ON `student_device_logs`(`created_at`)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sdl_fingerprint ON `student_device_logs`(`device_fingerprint`)");
}

function hgs_log_device(PDO $pdo, $student_number, $fp, $model, $ip, $ua, $status, $details = '') {
    try {
        hgs_ensure_device_tables($pdo);
        $stmt = $pdo->prepare("INSERT INTO student_device_logs (student_number, device_fingerprint, device_model, ip_address, user_agent, status, details) VALUES (:sn, :fp, :model, :ip, :ua, :status, :details)");
        $stmt->execute([
            ':sn' => (string)$student_number,
            ':fp' => substr((string)$fp, 0, 128),
            ':model' => substr((string)$model, 0, 120),
            ':ip' => substr((string)$ip, 0, 64),
            ':ua' => substr((string)$ua, 0, 500),
            ':status' => (string)$status,
            ':details' => substr((string)$details, 0, 2000),
        ]);
    } catch (Exception $e) {
        error_log('hgs_log_device: ' . $e->getMessage());
    }
}

// Which student (if any, other than $excludeSn) owns this device family?
// Numbered rows win over legacy number-less rows. Empty families never
// match — legacy rows without one can't collide.
function hgs_family_owner(PDO $pdo, $family, $excludeSn) {
    $family = (string)$family;
    if ($family === '') return null;
    try {
        $st = $pdo->prepare("SELECT student_number, student_name, device_unique_no FROM student_device_bindings WHERE device_family = :fam AND device_family != '' AND COALESCE(device_unique_no,'') != '' AND student_number != :sn LIMIT 1");
        $st->execute([':fam' => $family, ':sn' => (string)$excludeSn]);
        if ($hit = $st->fetch(PDO::FETCH_ASSOC)) return $hit;
        $st2 = $pdo->prepare("SELECT student_number, student_name, device_unique_no FROM student_device_bindings WHERE device_family = :fam AND device_family != '' AND student_number != :sn LIMIT 1");
        $st2->execute([':fam' => $family, ':sn' => (string)$excludeSn]);
        if ($hit2 = $st2->fetch(PDO::FETCH_ASSOC)) return $hit2;
    } catch (Exception $e) {}
    return null;
}

// Which binding (if any) owns this presented token pair? Cookies live per
// browser, so a presented pair registered to another number proves this
// browser is bound to someone else — regardless of family/IMEI evidence.
function hgs_token_owner(PDO $pdo, $ckFp, $ckUno) {
    $ckFp = strtolower(trim((string)$ckFp));
    $ckUno = strtolower(trim((string)$ckUno));
    if ($ckFp === '' || $ckUno === '') return null;
    try {
        $st = $pdo->prepare("SELECT student_number, student_name, device_unique_no FROM student_device_bindings WHERE LOWER(device_token) = :fp AND LOWER(device_unique_no) = :uno LIMIT 1");
        $st->execute([':fp' => $ckFp, ':uno' => $ckUno]);
        if ($hit = $st->fetch(PDO::FETCH_ASSOC)) return $hit;
    } catch (Exception $e) {}
    return null;
}

// One unique device number per bound device (hex). Retried on collision.
function hgs_new_unique_no(PDO $pdo) {
    for ($i = 0; $i < 5; $i++) {
        try {
            $u = bin2hex(random_bytes(16));
        } catch (Exception $e) { $u = md5(uniqid((string)mt_rand(), true)); }
        try {
            $st = $pdo->prepare("SELECT 1 FROM student_device_bindings WHERE device_unique_no = :u LIMIT 1");
            $st->execute([':u' => $u]);
            if (!$st->fetch(PDO::FETCH_ASSOC)) return $u;
        } catch (Exception $e) { return $u; }
    }
    try { return bin2hex(random_bytes(16)); } catch (Exception $e) { return md5(uniqid((string)mt_rand(), true)); }
}

function hgs_short_no($uno) {
    $uno = (string)$uno;
    return $uno === '' ? '' : strtoupper(substr($uno, 0, 8));
}

// Ensure this student's binding carries the ONE bound unique device number.
// Generates it on first adopt. Returns the number (or '' when unknown).
function hgs_adopt_device_no(PDO $pdo, $sn, $fam) {
    $fam = (string)$fam;
    if ($fam === '') return '';
    try {
        $uno = '';
        $st = $pdo->prepare("SELECT device_unique_no, device_family FROM student_device_bindings WHERE student_number = :sn LIMIT 1");
        $st->execute([':sn' => (string)$sn]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) return '';
        $uno = (string)($row['device_unique_no'] ?? '');
        if ($uno === '') {
            $uno = hgs_new_unique_no($pdo);
            $pdo->prepare("UPDATE student_device_bindings SET device_unique_no = :u WHERE student_number = :sn")->execute([':u' => $uno, ':sn' => (string)$sn]);
        }
        return $uno;
    } catch (Exception $e) { return ''; }
}

// Server-issued browser token: random per binding, stored in the row AND in
// persistent HttpOnly cookies. Unlike the reproducible browser fingerprint
// (identical phones compute identical ones), this token differs per browser
// jar — so two same-model phones never share it. Returns the token (or '').
function hgs_issue_device_token(PDO $pdo, $sn) {
    try {
        for ($i = 0; $i < 5; $i++) {
            try { $t = bin2hex(random_bytes(16)); } catch (Exception $e) { $t = md5(uniqid((string)mt_rand(), true)); }
            $st = $pdo->prepare("SELECT 1 FROM student_device_bindings WHERE device_token = :t LIMIT 1");
            $st->execute([':t' => $t]);
            if (!$st->fetch(PDO::FETCH_ASSOC)) {
                $pdo->prepare("UPDATE student_device_bindings SET device_token = :t WHERE student_number = :sn")->execute([':t' => $t, ':sn' => (string)$sn]);
                return $t;
            }
        }
    } catch (Exception $e) {}
    return '';
}

// Persist the device token pair on this browser (1 year, HttpOnly — the
// page JS never needs to see them; the server reads them on every login).
function hgs_set_device_cookies($tok, $uno) {
    if ($tok === '' || $uno === '' || headers_sent()) return;
    $exp = time() + 365 * 86400;
    try {
        setcookie('hgs_device_token', $tok, ['expires' => $exp, 'path' => '/', 'secure' => false, 'httponly' => true, 'samesite' => 'Lax']);
        setcookie('hgs_device_uno', $uno, ['expires' => $exp, 'path' => '/', 'secure' => false, 'httponly' => true, 'samesite' => 'Lax']);
    } catch (Exception $e) {}
}

// Facebook in-app browser version: the UA carries FBAV/<major.minor…>
// (e.g. FBAV/579.0.0.48) when students open the portal from Facebook /
// Messenger. Major number only — minors churn weekly.
// EVIDENCE ONLY, never identity: the app updates (577 → 579) on the same
// phone, two different phones commonly share one version, and Chrome on
// the same phone reports no FBAV at all. So it is stored, adopted, shown
// to admins and logged — but no verdict reads it. Returns '' otherwise.
function hgs_parse_fb_version($ua) {
    if (preg_match('/FBAV\/(\d{1,5})/i', (string)$ua, $m)) return substr($m[1], 0, 8);
    return '';
}
// Real hardware model name from Client Hints JSON (e.g. "SM-A127F").
// Returns '' when absent or malformed — never trust it for identity, it is
// display/forensics only (updates and clones share it).
function hgs_hint_model($hintsJson) {
    try {
        $hj = json_decode((string)$hintsJson, true);
        if (!is_array($hj)) return '';
        $hm = '';
        if (isset($hj['high']) && is_array($hj['high']) && trim((string)($hj['high']['model'] ?? '')) !== '') {
            $hm = trim((string)$hj['high']['model']);
        } elseif (trim((string)($hj['model'] ?? '')) !== '') {
            $hm = trim((string)$hj['model']);
        }
        if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9 _\-\.]{1,39}$/', $hm)) return '';
        return $hm;
    } catch (Exception $e) { return ''; }
}

// Student-initiated binding approval request. Writes one `bind_request`
// audit row per unresolved block; re-requests while one is pending are
// acknowledged, not duplicated (so the endpoint can't be used to spam the
// log — at most one open request per student number). A request resolves
// on any later success / first_bind / admin_force_bind / admin_unbind —
// the same rule the admin badge uses, so both sides always agree.
// Returns ['status' => success|info|error, 'msg' => ...].
function hgs_bind_request(PDO $pdo, $sn, $fp, $model, $fam, $raw, $ip = '', $ua = '') {
    $sn = trim((string)$sn);
    if (!preg_match('/^\d{2}-\d{5}$/', $sn)) return ['status' => 'error', 'msg' => 'Invalid student number format. Use XX-XXXXX.'];
    $fp = strtolower(trim((string)$fp));
    if ($fp !== '' && !preg_match('/^[a-f0-9]{16,128}$/', $fp)) $fp = '';
    $fam = strtolower(trim((string)$fam));
    if ($fam !== '' && !preg_match('/^[a-f0-9]{16,128}$/', $fam)) $fam = '';
    // At least one device signal must be present: proves the request came
    // from a real browser that ran the recognition script, not a bare POST.
    if ($fp === '' && $fam === '') return ['status' => 'error', 'msg' => 'Device not recognized yet — reload the page and try again.'];
    $model = substr(trim((string)$model), 0, 120);
    if ($model === '') $model = 'Unknown Device';
    try {
        hgs_ensure_device_tables($pdo);
        $chk = $pdo->prepare("SELECT COUNT(*) FROM student_device_logs WHERE student_number = :sn AND status = 'bind_request' AND id > COALESCE((SELECT MAX(id) FROM student_device_logs WHERE student_number = :sn2 AND status IN ('success','first_bind','admin_force_bind','admin_unbind')), 0)");
        $chk->execute([':sn' => $sn, ':sn2' => $sn]);
        if ((int)$chk->fetchColumn() > 0) return ['status' => 'info', 'msg' => 'Request already sent — the admin has been notified. Please wait for approval, then try logging in again.'];
        hgs_log_device($pdo, $sn, $fp, $model, $ip, $ua, 'bind_request', json_encode(['reason' => 'student requested binding approval', 'attempt_fp' => $fp, 'attempt_family' => $fam, 'attempt_model' => $model, 'raw' => substr((string)$raw, 0, 200)], JSON_UNESCAPED_SLASHES));
        return ['status' => 'success', 'msg' => 'Request sent! The admin has been notified and will review your device.'];
    } catch (Exception $e) { return ['status' => 'error', 'msg' => 'Could not send request. Please try again.']; }
}

// ---------- WebAuthn device key (challenge-response) ----------
// Hardware-backed keypair (Android Keystore / iOS Secure Enclave via the
// browser's WebAuthn): the private key never leaves the phone; the server
// keeps the public key and verifies signatures over a random challenge.
// ES256 (P-256 + SHA-256) only — universal on phones, verifiable by
// openssl. Attestation "none" (no cert chains to validate).
// Flip to true once the portal runs on HTTPS everywhere: a stored key then
// becomes REQUIRED (no legacy fallback) instead of best-effort. Until then
// it must stay false — WebAuthn needs a secure context, so plain-HTTP
// (LAN-IP) phones cannot run the ceremony at all.
define('HGS_WEBAUTHN_STRICT', false);

function hgs_b64u_encode($bin) { return rtrim(strtr(base64_encode((string)$bin), '+/', '-_'), '='); }
function hgs_b64u_decode($s) {
    $s = (string)$s;
    if (!preg_match('/^[A-Za-z0-9\-_]*$/', $s)) return null;
    $s = strtr($s, '-_', '+/');
    $pad = strlen($s) % 4;
    if ($pad) $s .= str_repeat('=', 4 - $pad);
    $out = base64_decode($s, true);
    return ($out === false) ? null : $out;
}

// Minimal CBOR decoder — just enough for WebAuthn (uint/nint/bytes/text/
// array/map/tag-skip). Returns [value, nextOffset]; throws on truncation or
// unsupported items (indefinite lengths, floats, simple values).
function hgs_cbor_item($bin, $pos) {
    $n = strlen($bin);
    if ($pos >= $n) throw new Exception('cbor truncated');
    $ib = ord($bin[$pos]); $pos++;
    $major = $ib >> 5; $ai = $ib & 0x1F;
    if ($ai < 24) $arg = $ai;
    elseif ($ai === 24) { if ($pos + 1 > $n) throw new Exception('cbor truncated'); $arg = ord($bin[$pos]); $pos += 1; }
    elseif ($ai === 25) { if ($pos + 2 > $n) throw new Exception('cbor truncated'); $arg = (ord($bin[$pos]) << 8) | ord($bin[$pos + 1]); $pos += 2; }
    elseif ($ai === 26) { if ($pos + 4 > $n) throw new Exception('cbor truncated'); $u = unpack('N', substr($bin, $pos, 4)); $arg = $u[1]; $pos += 4; }
    elseif ($ai === 27) {
        if ($pos + 8 > $n) throw new Exception('cbor truncated');
        $hi = unpack('N', substr($bin, $pos, 4)); $lo = unpack('N', substr($bin, $pos + 4, 4));
        if ($hi[1] !== 0) throw new Exception('cbor length too large');
        $arg = $lo[1]; $pos += 8;
    } else throw new Exception('cbor indefinite unsupported');
    switch ($major) {
        case 0: return [$arg, $pos];
        case 1: return [-1 - $arg, $pos];
        case 2:
            if ($pos + $arg > $n) throw new Exception('cbor truncated');
            return [substr($bin, $pos, $arg), $pos + $arg];
        case 3:
            if ($pos + $arg > $n) throw new Exception('cbor truncated');
            return [substr($bin, $pos, $arg), $pos + $arg];
        case 4:
            $arr = [];
            for ($i = 0; $i < $arg; $i++) { list($v, $pos) = hgs_cbor_item($bin, $pos); $arr[] = $v; }
            return [$arr, $pos];
        case 5:
            $map = [];
            for ($i = 0; $i < $arg; $i++) { list($k, $pos) = hgs_cbor_item($bin, $pos); list($v, $pos) = hgs_cbor_item($bin, $pos); $map[$k] = $v; }
            return [$map, $pos];
        case 6: return hgs_cbor_item($bin, $pos); // tag: use enclosed item
        default: throw new Exception('cbor simple/float unsupported');
    }
}

// Uncompressed P-256 point (X/Y, 32 bytes each) → PEM public key.
function hgs_p256_pem($x, $y) {
    if (!is_string($x) || !is_string($y) || strlen($x) !== 32 || strlen($y) !== 32) return null;
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . "\x04" . $x . $y;
    return "-----BEGIN PUBLIC KEY-----\n" . chunk_split(base64_encode($der), 64, "\n") . "-----END PUBLIC KEY-----\n";
}

function hgs_webauthn_rp() {
    $host = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
    $host = preg_replace('/:\d+$/', '', $host);
    if ($host === '') $host = 'localhost';
    return $host;
}
function hgs_webauthn_origin() {
    $https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO'])) $https = (strtolower(trim((string)$_SERVER['HTTP_X_FORWARDED_PROTO'])) === 'https');
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') $host = 'localhost';
    return ($https ? 'https' : 'http') . '://' . $host;
}

// Verify a WebAuthn registration ceremony. $challengeRaw = raw bytes issued
// via the options endpoint. Returns [credIdB64u, pem] or [null, errorMsg].
function hgs_webauthn_register($payload, $challengeRaw, $rpId, $origin) {
    try {
        if (!is_array($payload)) return [null, 'Bad key data.'];
        $resp = (isset($payload['response']) && is_array($payload['response'])) ? $payload['response'] : [];
        $attObj = hgs_b64u_decode($resp['attestationObject'] ?? '');
        $cliJson = hgs_b64u_decode($resp['clientDataJSON'] ?? '');
        if ($attObj === null || $cliJson === null) return [null, 'Bad key encoding.'];
        $cli = json_decode($cliJson, true);
        if (!is_array($cli) || ($cli['type'] ?? '') !== 'webauthn.create') return [null, 'Wrong ceremony.'];
        if (($cli['origin'] ?? '') !== $origin) return [null, 'Origin mismatch.'];
        $cch = hgs_b64u_decode($cli['challenge'] ?? '');
        if ($cch === null || !hash_equals((string)$challengeRaw, $cch)) return [null, 'Challenge mismatch.'];
        list($att, $off) = hgs_cbor_item($attObj, 0);
        if (!is_array($att) || ($att['fmt'] ?? '') !== 'none') return [null, 'Attestation not supported.'];
        if (!empty($att['attStmt'])) return [null, 'Attestation not supported.'];
        $auth = $att['authData'] ?? null;
        if (!is_string($auth) || strlen($auth) < 37 + 18) return [null, 'Bad authenticator data.'];
        if (substr($auth, 0, 32) !== hash('sha256', $rpId, true)) return [null, 'RP mismatch.'];
        $flags = ord($auth[32]);
        if (!($flags & 0x01)) return [null, 'User not present.'];
        if (!($flags & 0x40)) return [null, 'No key data.'];
        $credLen = (ord($auth[53]) << 8) | ord($auth[54]);
        if ($credLen <= 0 || $credLen > 1024 || strlen($auth) < 55 + $credLen) return [null, 'Bad credential id.'];
        $credId = substr($auth, 55, $credLen);
        list($cose, $off2) = hgs_cbor_item($auth, 55 + $credLen);
        if (!is_array($cose) || ($cose[1] ?? null) !== 2 || ($cose[3] ?? null) !== -7 || ($cose[-1] ?? null) !== 1) return [null, 'Only ES256 keys are supported.'];
        $pem = hgs_p256_pem($cose[-2] ?? null, $cose[-3] ?? null);
        if ($pem === null) return [null, 'Bad key coordinates.'];
        if (@openssl_pkey_get_public($pem) === false) return [null, 'Bad public key.'];
        return [hgs_b64u_encode($credId), $pem];
    } catch (Exception $e) { return [null, 'Key verification failed.']; }
}

// Verify a WebAuthn assertion against the stored credential row ($binding).
// Returns [true, ''] or [false, errorMsg]; advances the sign count on
// success (equal-or-lower count with a nonzero stored count = cloned key).
function hgs_webauthn_authenticate(PDO $pdo, $binding, $payload, $challengeRaw, $rpId, $origin) {
    try {
        if (!is_array($payload)) return [false, 'Bad key data.'];
        $storedId = (string)($binding['webauthn_credential_id'] ?? '');
        $pem = (string)($binding['webauthn_public_key'] ?? '');
        if ($storedId === '' || $pem === '') return [false, 'No device key.'];
        $givenId = (string)($payload['id'] ?? '');
        if ($givenId === '' || !hash_equals($storedId, $givenId)) return [false, 'Unknown device key.'];
        $resp = (isset($payload['response']) && is_array($payload['response'])) ? $payload['response'] : [];
        $auth = hgs_b64u_decode($resp['authenticatorData'] ?? '');
        $cliJson = hgs_b64u_decode($resp['clientDataJSON'] ?? '');
        $sig = hgs_b64u_decode($resp['signature'] ?? '');
        if ($auth === null || $cliJson === null || $sig === null) return [false, 'Bad key encoding.'];
        $cli = json_decode($cliJson, true);
        if (!is_array($cli) || ($cli['type'] ?? '') !== 'webauthn.get') return [false, 'Wrong ceremony.'];
        if (($cli['origin'] ?? '') !== $origin) return [false, 'Origin mismatch.'];
        $cch = hgs_b64u_decode($cli['challenge'] ?? '');
        if ($cch === null || !hash_equals((string)$challengeRaw, $cch)) return [false, 'Challenge mismatch.'];
        if (strlen($auth) < 37) return [false, 'Bad authenticator data.'];
        if (substr($auth, 0, 32) !== hash('sha256', $rpId, true)) return [false, 'RP mismatch.'];
        $flags = ord($auth[32]);
        if (!($flags & 0x01)) return [false, 'User not present.'];
        $count = (ord($auth[33]) << 24) | (ord($auth[34]) << 16) | (ord($auth[35]) << 8) | ord($auth[36]);
        $stored = (int)($binding['webauthn_sign_count'] ?? 0);
        if (!($count === 0 && $stored === 0) && $count <= $stored) return [false, 'Key replay detected.'];
        $key = @openssl_pkey_get_public($pem);
        if ($key === false) return [false, 'Bad stored key.'];
        $vr = @openssl_verify($auth . hash('sha256', $cliJson, true), $sig, $key, OPENSSL_ALGO_SHA256);
        if ($vr !== 1) return [false, 'Signature mismatch.'];
        $sn = (string)($binding['student_number'] ?? '');
        if ($sn !== '') {
            $up = $pdo->prepare("UPDATE student_device_bindings SET webauthn_sign_count = :c, last_seen = CURRENT_TIMESTAMP WHERE student_number = :sn");
            $up->execute([':c' => $count, ':sn' => $sn]);
        }
        return [true, ''];
    } catch (Exception $e) { return [false, 'Key verification failed.']; }
}


// WebAuthn ceremony options (pre-login AJAX): tells the login page whether
// this number needs key registration, key authentication, or nothing, and
// issues the single-use challenge. No auth required (same exposure as login).
if (isset($_REQUEST['webauthn']) && $_REQUEST['webauthn'] === 'options') {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    header('Content-Type: application/json');
    $sn = trim((string)($_REQUEST['student_number'] ?? ''));
    if (!preg_match('/^\d{2}-\d{5}$/', $sn)) { echo json_encode(['status' => 'error', 'msg' => 'Invalid number']); exit; }
    try {
        $pdoO = new PDO('sqlite:' . HGS_MAIN_DB);
        $pdoO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        hgs_ensure_device_tables($pdoO);
        $bO = $pdoO->prepare("SELECT webauthn_credential_id FROM student_device_bindings WHERE student_number = :sn LIMIT 1");
        $bO->execute([':sn' => $sn]);
        $rowO = $bO->fetch(PDO::FETCH_ASSOC);
        $hasKey = $rowO && trim((string)($rowO['webauthn_credential_id'] ?? '')) !== '';
        $chRaw = random_bytes(32);
        $rpId = hgs_webauthn_rp();
        $_SESSION['webauthn_challenge'] = ['ch' => base64_encode($chRaw), 'exp' => time() + 300, 'mode' => $hasKey ? 'authenticate' : 'register', 'sn' => $sn];
        $out = ['status' => 'success', 'mode' => $hasKey ? 'authenticate' : 'register', 'challenge' => hgs_b64u_encode($chRaw), 'rpId' => $rpId, 'userName' => $sn, 'userHandle' => hgs_b64u_encode($sn)];
        if ($hasKey) $out['credentialId'] = trim((string)$rowO['webauthn_credential_id']);
        echo json_encode($out);
    } catch (Exception $e) { echo json_encode(['status' => 'error', 'msg' => 'Could not start device key ceremony.']); }
    exit;
}

// Binding-approval request from a blocked student (see the Request
// Approval button under the login error). No auth required — same exposure
// as the login POST itself; abuse is capped by hgs_bind_request (device
// signals required, one open request per number).
if (isset($_REQUEST['bind']) && $_REQUEST['bind'] === 'request') {
    while (ob_get_level() > 0) { @ob_end_clean(); }
    header('Content-Type: application/json');
    try {
        $pdoR = new PDO('sqlite:' . HGS_MAIN_DB);
        $pdoR->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $r = hgs_bind_request($pdoR, (string)($_POST['student_number'] ?? ''), (string)($_POST['device_fingerprint'] ?? ''), (string)($_POST['device_model'] ?? ''), (string)($_POST['device_family'] ?? ''), (string)($_POST['device_raw'] ?? ''), hgs_get_client_ip(), substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500));
        echo json_encode(['status' => $r['status'], 'msg' => $r['msg']]);
    } catch (Exception $e) { echo json_encode(['status' => 'error', 'msg' => 'Could not send request. Please try again.']); }
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_number = isset($_POST['student_number']) ? trim($_POST['student_number']) : '';
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    if ($action === 'login' && !empty($student_number)) {
        if (!preg_match('/^\d{2}-\d{5}$/', $student_number)) {
            $error_message = 'Invalid student number format. Please use XX-XXXXX format.';
        } else {
            // Device payload from client JS (strong recognition)
            $device_fp = isset($_POST['device_fingerprint']) ? trim((string)$_POST['device_fingerprint']) : '';
            $device_model = isset($_POST['device_model']) ? trim((string)$_POST['device_model']) : '';
            $device_raw = isset($_POST['device_raw']) ? trim((string)$_POST['device_raw']) : '';
            $device_platform = isset($_POST['device_platform']) ? trim((string)$_POST['device_platform']) : '';
            $device_screen = isset($_POST['device_screen']) ? trim((string)$_POST['device_screen']) : '';
            $device_tz = isset($_POST['device_timezone']) ? trim((string)$_POST['device_timezone']) : '';
            // Cross-browser device-family hash (same value in every browser on
            // one physical device). Empty when the page is cached/old.
            $device_family = isset($_POST['device_family']) ? trim((string)$_POST['device_family']) : '';
            if ($device_family !== '' && !preg_match('/^[a-f0-9]{16,128}$/i', $device_family)) $device_family = '';
            $device_family = strtolower(substr($device_family, 0, 128));
            // Server-issued device token pair from our persistent cookies
            // (set at bind time). Absent on first sight, cleared cookies, or
            // legacy bindings — all handled gracefully below, never fatal.
            $ckFp = isset($_COOKIE['hgs_device_token']) ? trim((string)$_COOKIE['hgs_device_token']) : '';
            $ckUno = isset($_COOKIE['hgs_device_uno']) ? trim((string)$_COOKIE['hgs_device_uno']) : '';
            if ($ckFp !== '' && !preg_match('/^[a-f0-9]{16,128}$/i', $ckFp)) $ckFp = '';
            if ($ckUno !== '' && !preg_match('/^[a-f0-9]{16,128}$/i', $ckUno)) $ckUno = '';
            $ckFp = strtolower($ckFp);
            $ckUno = strtolower($ckUno);
            // Client Hints JSON (real model names, OS/browser versions) for
            // display + forensics. Never used for identity (it changes).
            $device_hints = isset($_POST['device_hints']) ? substr(trim((string)$_POST['device_hints']), 0, 500) : '';
            // Hardware identifier: ANDROID_ID only — stable per app signing
            // key and readable by the school wrapper app, which injects it
            // via a JS bridge (window.HGSAndroidId, see init() below).
            // Browsers expose no IMEI/serial at all, and regular apps are
            // blocked from IMEI since Android 10, so the retired IMEI
            // columns stay dropped. Absent on plain browsers: stored as
            // NULL and never blocks login — identity stays token + family.
            $hw_aid = isset($_POST['device_aid']) ? strtolower(trim((string)$_POST['device_aid'])) : '';
            if ($hw_aid !== '' && !preg_match('/^[a-f0-9]{8,64}$/', $hw_aid)) $hw_aid = '';
            $hw_aid = substr($hw_aid, 0, 64);
            $hw_ids = ['serial' => '', 'aid' => $hw_aid];
            $hw_log = [];
            if ($hw_aid !== '') $hw_log['aid'] = $hw_aid;
            $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $ip = hgs_get_client_ip();
            // Facebook in-app browser version (FBAV/<major> in the UA).
            // Parsed from the FULL UA — device_raw is truncated at 500 chars
            // and FB UAs put FBAV near the end. Evidence only (see helper):
            // recorded on bindings + logs, never a block/allow verdict.
            $fbav = hgs_parse_fb_version($ua);
            if ($fbav !== '') $hw_log['fb'] = $fbav;
            // Normalize fingerprint: hex 32-128 chars, else reject
            if ($device_fp !== '' && !preg_match('/^[a-f0-9]{16,128}$/i', $device_fp)) {
                // allow srv- fallback prefix? we now reject server fallback, so only hex
                // if malformed, treat as missing
                $device_fp = '';
            }
            if ($device_fp === '') {
                // No fingerprint supplied — browser JS may be disabled or still computing.
                // We block with a friendly message and log. This forces JS-enabled flow.
                try {
                    $pdoTmp = new PDO('sqlite:' . HGS_MAIN_DB);
                    $pdoTmp->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    hgs_log_device($pdoTmp, $student_number, '', $device_model !== '' ? $device_model : hgs_parse_device_build_fallback($ua), $ip, $ua, 'blocked_no_fingerprint', json_encode(['reason'=>'missing fingerprint; JS required','raw'=>$device_raw,'screen'=>$device_screen], JSON_UNESCAPED_SLASHES));
                } catch (Exception $e) {}
                $error_message = 'Device recognition failed. Please enable JavaScript and cookies, reload this page, and try again. Your device could not be verified.';
            } else {
                // Normalize build label
                if ($device_model === '' || $device_model === 'Unknown Device') {
                    $device_model = hgs_parse_device_build_fallback($ua);
                    if ($device_raw !== '' && strlen($device_model) < 4) {
                        $device_model = substr($device_raw, 0, 80);
                    }
                }
                // Limit fields
                $device_model = substr($device_model, 0, 120);
                // Prefer the real hardware model from Client Hints (e.g. SM-A127F)
                // over generic fallbacks — display only, never identity.
                $hintModel = hgs_hint_model($device_hints);
                if ($hintModel !== '' && ($device_model === '' || $device_model === 'Unknown Device' || $device_model === 'Android Device')) {
                    $device_model = $hintModel;
                }
                $device_raw = substr($device_raw !== '' ? $device_raw : $ua, 0, 500);
                $device_platform = substr($device_platform, 0, 80);
                $device_screen = substr($device_screen, 0, 32);
                $device_tz = substr($device_tz, 0, 64);
                $device_fp = strtolower(substr($device_fp, 0, 128));

                $student = null;
                $found_in_db = '';
                try {
                    $conn = new DBConnection();
                    $stmt = $conn->query("SELECT s.*, c.grade, c.section, sub.name as subject_name FROM student_list s JOIN class_list c ON s.class_id = c.class_id JOIN subjects sub ON c.subject_id = sub.subject_id WHERE s.student_number = '$student_number' LIMIT 1");
                    $student = $stmt->fetchArray(SQLITE3_ASSOC);
                    if ($student) { $found_in_db = 'Main Database'; }
                } catch (Exception $e) {}
                if (!$student) {
                    $faculty_dbs = glob(__DIR__ . '/../db/*.db');
                    foreach ($faculty_dbs as $db_file) {
                        if (basename($db_file) !== 'grading_db.db') {
                            try {
                                $faculty_conn = new PDO('sqlite:' . $db_file);
                                $faculty_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                $stmt = $faculty_conn->query("SELECT s.*, c.grade, c.section, sub.name as subject_name FROM student_list s JOIN class_list c ON s.class_id = c.class_id JOIN subjects sub ON c.subject_id = sub.subject_id WHERE s.student_number = '$student_number' LIMIT 1");
                                $student = $stmt->fetch(PDO::FETCH_ASSOC);
                                if ($student) { $found_in_db = basename($db_file); break; }
                            } catch (Exception $e) {}
                        }
                    }
                }
                if (!$student) {
                    $admin_backup_path = __DIR__ . '/../db/backups/Administrator/';
                    if (is_dir($admin_backup_path)) {
                        $admin_dbs = glob($admin_backup_path . '*.db');
                        foreach ($admin_dbs as $db_file) {
                            try {
                                $admin_conn = new PDO('sqlite:' . $db_file);
                                $admin_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                $stmt = $admin_conn->query("SELECT s.*, c.grade, c.section, sub.name as subject_name FROM student_list s JOIN class_list c ON s.class_id = c.class_id JOIN subjects sub ON c.subject_id = sub.subject_id WHERE s.student_number = '$student_number' LIMIT 1");
                                $student = $stmt->fetch(PDO::FETCH_ASSOC);
                                if ($student) { $found_in_db = 'Administrator/' . basename($db_file); break; }
                            } catch (Exception $e) {}
                        }
                    }
                }
                if (!$student) {
                    $faculty_backup_path = __DIR__ . '/../db/backups/faculty_backups/';
                    if (is_dir($faculty_backup_path)) {
                        $backup_dbs = glob($faculty_backup_path . '*.db');
                        foreach ($backup_dbs as $db_file) {
                            try {
                                $backup_conn = new PDO('sqlite:' . $db_file);
                                $backup_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                                $stmt = $backup_conn->query("SELECT s.*, c.grade, c.section, sub.name as subject_name FROM student_list s JOIN class_list c ON s.class_id = c.class_id JOIN subjects sub ON c.subject_id = sub.subject_id WHERE s.student_number = '$student_number' LIMIT 1");
                                $student = $stmt->fetch(PDO::FETCH_ASSOC);
                                if ($student) { $found_in_db = 'faculty_backups/' . basename($db_file); break; }
                            } catch (Exception $e) {}
                        }
                    }
                }
                if ($student) {
                    // -----------------------------
                    // Strong device binding check
                    // -----------------------------
                    $deviceBlocked = false;
                    $deviceBindMsg = '';
                    $pdo = null;
                    $fam = $device_family;
                    $newBrowserEnrolled = false;
                    try {
                        $pdo = new PDO('sqlite:' . HGS_MAIN_DB);
                        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        $pdo->exec("PRAGMA busy_timeout = 5000");
                        hgs_ensure_device_tables($pdo);

                        $newBrowserEnrolled = false;

                        $stmtB = $pdo->prepare("SELECT * FROM student_device_bindings WHERE student_number = :sn LIMIT 1");
                        $stmtB->execute([':sn' => $student_number]);
                        $binding = $stmtB->fetch(PDO::FETCH_ASSOC);

                        // Attached WebAuthn ceremony result (if the page ran
                        // one — see the device-key script below). Verified
                        // below for known keys; enrolled below on success.
                        $keyPayload = null;
                        if (isset($_POST['webauthn_result']) && trim((string)$_POST['webauthn_result']) !== '') {
                            $kd = json_decode((string)$_POST['webauthn_result'], true);
                            if (is_array($kd)) $keyPayload = $kd;
                        }
                        $keyOk = false; $keySkipped = false;

                        // Adopt the freshly supplied family. Always refreshes (not
                        // only when empty) so stored signatures migrate forward
                        // when the family recipe changes; only non-empty values.
                        $adoptFamily = function() use ($pdo, $student_number, $fam) {
                            if ($fam === '') return;
                            try {
                                $up = $pdo->prepare("UPDATE student_device_bindings SET device_family = :fam WHERE student_number = :sn");
                                $up->execute([':fam' => $fam, ':sn' => $student_number]);
                            } catch (Exception $e) {}
                        };

                        if (!$binding) {
                            // First login ever for this student number: claim the device.
                            // A different student number on the SAME device is refused here.
                            // A browser token registered to another number proves this
                            // browser is bound to someone else — refuse outright,
                            // before even consulting family/IMEI evidence.
                            $tokOwner = hgs_token_owner($pdo, $ckFp, $ckUno);
                            if ($tokOwner && strcasecmp((string)($tokOwner['student_number'] ?? ''), $student_number) !== 0) {
                                $deviceBlocked = true;
                                $tokNo = (!empty($tokOwner['device_unique_no'])) ? ' (device no. ' . htmlspecialchars(hgs_short_no($tokOwner['device_unique_no'])) . ')' : '';
                                $deviceBindMsg = 'This browser is already registered to student <strong>' . htmlspecialchars($tokOwner['student_number']) . '</strong> (' . htmlspecialchars($tokOwner['student_name'] ?? 'Unknown') . ')' . $tokNo . '. One browser may only be used by one student number. Please use your own device or contact the administrator to reset the binding.';
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_family_taken', json_encode([
                                    'reason' => 'browser token already bound to another student',
                                    'attempt_name' => $student['name'] ?? null,
                                    'attempt_fp' => $device_fp,
                                    'owner' => $tokOwner['student_number'],
                                    'owner_name' => $tokOwner['student_name'] ?? null,
                                    'attempt_model' => $device_model,
                                ] + $hw_log, JSON_UNESCAPED_SLASHES));
                                $blocked_details = ['type'=>'taken','owner'=>$tokOwner['student_number'],'owner_model'=>null];
                            } else {
                            $owner = hgs_family_owner($pdo, $fam, $student_number);
                            // A family already bound to another number refuses any
                            // other number outright — even one with no binding yet.
                            if ($owner) {
                                $deviceBlocked = true;
                                    $ownerNo = (!empty($owner['device_unique_no'])) ? ' (device no. ' . htmlspecialchars(hgs_short_no($owner['device_unique_no'])) . ')' : '';
                                    $deviceBindMsg = 'This device is already registered to student <strong>' . htmlspecialchars($owner['student_number']) . '</strong> (' . htmlspecialchars($owner['student_name'] ?? 'Unknown') . ')' . $ownerNo . '. Each device may only be used by one student — even in a different browser. Please use your own device or contact the administrator to reset the binding.';
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_family_taken', json_encode(array_merge([
                                    'reason' => 'device family already bound to another student',
                                    'attempt_name' => $student['name'] ?? null,
                                    'attempt_family' => $fam,
                                    'owner' => $owner['student_number'],
                                    'owner_name' => $owner['student_name'] ?? null,
                                    'attempt_model' => $device_model,
                                    'raw' => $device_raw,
                                ], $hw_log), JSON_UNESCAPED_SLASHES));
                                $blocked_details = ['type'=>'taken','owner'=>$owner['student_number'],'owner_model'=>null];
                            } else {
                                try {
                                    // Server-random browser token: unlike the reproducible
                                    // browser fingerprint, this differs even between two
                                    // identical phones (different cookie jars).
                                    $tokNow = hgs_issue_device_token($pdo, $student_number);
                                    $stmtIns = $pdo->prepare("INSERT INTO student_device_bindings (student_number, student_name, device_fingerprint, device_family, device_model, device_token, device_serial, device_android_id, device_fb, device_raw, platform, ip_address, user_agent, screen_resolution, timezone, first_seen, last_seen, is_active) VALUES (:sn, :name, :fp, :fam, :model, :tok, :serial, :aid, :fb, :raw, :plat, :ip, :ua, :scr, :tz, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)");
                                    $stmtIns->execute([
                                        ':sn' => $student_number,
                                        ':name' => $student['name'] ?? null,
                                        ':fp' => $device_fp,
                                        ':fam' => $fam,
                                        ':model' => $device_model,
                                        ':tok' => $tokNow !== '' ? $tokNow : null,
                                        ':serial' => $hw_ids['serial'] !== '' ? $hw_ids['serial'] : null,
                                        ':aid' => $hw_ids['aid'] !== '' ? $hw_ids['aid'] : null,
                                        ':fb' => $fbav !== '' ? $fbav : null,
                                        ':raw' => $device_raw,
                                        ':plat' => $device_platform,
                                        ':ip' => $ip,
                                        ':ua' => $ua,
                                        ':scr' => $device_screen,
                                        ':tz' => $device_tz,
                                    ]);
                                    $unoNow = hgs_adopt_device_no($pdo, $student_number, $fam);
                                    hgs_set_device_cookies($tokNow, $unoNow);
                                    hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'first_bind', json_encode(array_merge(['model'=>$device_model,'screen'=>$device_screen,'tz'=>$device_tz,'platform'=>$device_platform,'family'=>$fam,'unique_no'=>$unoNow], $hw_log), JSON_UNESCAPED_SLASHES));
                                    hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'success', 'First login — device bound successfully');
                                } catch (PDOException $e) {
                                    // Unique constraint race: student_number just taken
                                    if (strpos($e->getMessage(), 'UNIQUE') !== false || strpos($e->getMessage(), 'unique') !== false) {
                                        $deviceBlocked = true;
                                        $deviceBindMsg = 'This device or student number was just registered by another session. Please reload and try again, or contact the administrator.';
                                        hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_race', $e->getMessage());
                                    } else {
                                        throw $e;
                                    }
                                }
                            }
                            } // end token-owner else: existing family/bind flow above
                        } else {
                            // Known student. Matching order for THIS number:
                            //  0. Hardware key (if enrolled): a valid assertion
                            //     bypasses the family block below (proves the
                            //     physical device); an invalid one blocks.
                            //  1. Server token pair (random per binding — even
                            //     identical phones differ, unlike fingerprints).
                            //  2. Legacy same-fingerprint path (pre-token
                            //     bindings, cleared cookies): allow + migrate.
                            //  3. Otherwise the family + hardware verdict
                            //     decides (block someone else's device, or move
                            //     here and issue a fresh token).
                            // Facebook app version (device_fb) is recorded,
                            // adopted and logged as evidence, but NEVER read by
                            // the verdicts above: it changes on app update
                            // (same phone 577 → 579), is shared across
                            // different phones, and is absent in Chrome on the
                            // same phone.
                            // Device-key gate: a stored credential means this
                            // number enrolled a hardware key. A presented
                            // assertion MUST verify (anything else is a forgery
                            // attempt and blocks outright). An absent assertion
                            // falls back to the legacy checks below — unless
                            // HGS_WEBAUTHN_STRICT (HTTPS-only future).
                            $storedCred = trim((string)($binding['webauthn_credential_id'] ?? ''));
                            if ($storedCred !== '') {
                                if (is_array($keyPayload) && ($keyPayload['mode'] ?? '') === 'authenticate') {
                                    $sesKey = $_SESSION['webauthn_challenge'] ?? null;
                                    unset($_SESSION['webauthn_challenge']);
                                    $chRaw = null;
                                    if (is_array($sesKey) && ($sesKey['mode'] ?? '') === 'authenticate' && ($sesKey['sn'] ?? '') === $student_number && ($sesKey['exp'] ?? 0) >= time()) {
                                        $chRaw = base64_decode((string)($sesKey['ch'] ?? ''), true);
                                    }
                                    if (!is_string($chRaw) || $chRaw === '') {
                                        $deviceBlocked = true;
                                        $deviceBindMsg = 'Device key session expired. Reload the login page and try again.';
                                        hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_key_mismatch', 'Key challenge missing or expired');
                                    } else {
                                        list($kOk, $kMsg) = hgs_webauthn_authenticate($pdo, $binding, $keyPayload, $chRaw, hgs_webauthn_rp(), hgs_webauthn_origin());
                                        if ($kOk) { $keyOk = true; }
                                        else {
                                            $deviceBlocked = true;
                                            $deviceBindMsg = 'Device key mismatch. This number is locked to a registered device key — use the enrolled phone' . ($kMsg !== '' ? ' (' . htmlspecialchars($kMsg) . ')' : '') . ' or contact the administrator to reset the binding.';
                                            hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_key_mismatch', $kMsg);
                                        }
                                    }
                                } elseif (HGS_WEBAUTHN_STRICT) {
                                    $deviceBlocked = true;
                                    $deviceBindMsg = 'A registered device key is required. Open this page in a browser with passkey support (HTTPS) and try again, or contact the administrator.';
                                    hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_key_required', 'Stored key but no assertion and strict mode on');
                                } else {
                                    $keySkipped = true;
                                }
                            }
                            if ($keyOk) $hw_log['key'] = 'verified';
                            elseif ($keySkipped) $hw_log['key'] = 'legacy_fallback';
                            $storedTok = strtolower(trim((string)($binding['device_token'] ?? '')));
                            $storedUno = strtolower(trim((string)($binding['device_unique_no'] ?? '')));
                            $tokenBound = ($storedTok !== '' && $storedUno !== '');
                            $tokenPresented = ($ckFp !== '' && $ckUno !== '');
                            $tokenMatch = ($tokenBound && $tokenPresented
                                && hash_equals($storedTok, $ckFp) && hash_equals($storedUno, $ckUno));
                            if ($tokenMatch) {
                                // This exact browser was bound to this number.
                                // device_fb adopts only when non-empty (Chrome on the
                                // same phone reports no FBAV — must not wipe it).
                                $stmtTok = $pdo->prepare("UPDATE student_device_bindings SET device_fingerprint = :fp, device_fb = COALESCE(NULLIF(:fb, ''), device_fb), is_active = 1, last_seen = CURRENT_TIMESTAMP, ip_address = :ip, user_agent = :ua, student_name = :name WHERE student_number = :sn");
                                $stmtTok->execute([':fp'=>$device_fp,':fb'=>$fbav,':ip'=>$ip,':ua'=>$ua,':name'=>$student['name'] ?? $binding['student_name'],':sn'=>$student_number]);
                                $adoptFamily();
                                hgs_adopt_device_no($pdo, $student_number, $fam);

                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'success', $hw_log ? json_encode(array_merge(['msg' => 'Token match'], $hw_log), JSON_UNESCAPED_SLASHES) : 'Token match');
                            } elseif (hash_equals((string)($binding['device_fingerprint'] ?? ''), $device_fp) && (!$tokenBound || !$tokenPresented)) {
                                // Returning browser — allow (reactivates if admin-disabled).
                                // Migrates (or re-establishes) the token pair.
                                $stmtRe = $pdo->prepare("UPDATE student_device_bindings SET is_active = 1, last_seen = CURRENT_TIMESTAMP, ip_address = :ip, user_agent = :ua, student_name = :name WHERE student_number = :sn");
                                $stmtRe->execute([':ip'=>$ip,':ua'=>$ua,':name'=>$student['name'] ?? $binding['student_name'],':sn'=>$student_number]);
                                $adoptFamily();
                                $unoMig = hgs_adopt_device_no($pdo, $student_number, $fam);

                                $tokMig = hgs_issue_device_token($pdo, $student_number);
                                hgs_set_device_cookies($tokMig, $unoMig);
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'success', $hw_log ? json_encode(array_merge(['msg' => 'Returning browser'], $hw_log), JSON_UNESCAPED_SLASHES) : 'Returning browser');
                            } else {
                            // A browser token registered to another number proves
                            // this browser is bound to someone else — refuse
                            // outright, before family/IMEI evidence.
                            $tokOwner = hgs_token_owner($pdo, $ckFp, $ckUno);
                            if ($tokOwner && strcasecmp((string)($tokOwner['student_number'] ?? ''), $student_number) !== 0) {
                                $deviceBlocked = true;
                                $tokNo = (!empty($tokOwner['device_unique_no'])) ? ' (device no. ' . htmlspecialchars(hgs_short_no($tokOwner['device_unique_no'])) . ')' : '';
                                $deviceBindMsg = 'This browser is already registered to student <strong>' . htmlspecialchars($tokOwner['student_number']) . '</strong> (' . htmlspecialchars($tokOwner['student_name'] ?? 'Unknown') . ')' . $tokNo . '. One browser may only be used by one student number. Please use your own device or contact the administrator to reset the binding.';
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_family_taken', json_encode([
                                    'reason' => 'browser token already bound to another student',
                                    'attempt_name' => $student['name'] ?? null,
                                    'attempt_fp' => $device_fp,
                                    'owner' => $tokOwner['student_number'],
                                    'owner_name' => $tokOwner['student_name'] ?? null,
                                    'attempt_model' => $device_model,
                                ] + $hw_log, JSON_UNESCAPED_SLASHES));
                                $blocked_details = ['type'=>'taken','owner'=>$tokOwner['student_number'],'owner_model'=>null];
                            } else {
                            $owner = hgs_family_owner($pdo, $fam, $student_number);
                            // Hardware-key override: a VALID assertion for this
                            // number's own enrolled credential proves THIS
                            // physical device holds the private key — so two
                            // identical-model phones (same build, same FB
                            // version, same family) can no longer lock each
                            // other out. The browser-token check above still
                            // stands (cookie jar = browser profile sharing).
                            $keyOverridesFamily = ($keyOk && !empty($owner));
                            if ($owner && !$keyOverridesFamily) {
                                // Same device (same family) but registered to another student.
                                $ownerNo2 = (!empty($owner['device_unique_no'])) ? ' (device no. ' . htmlspecialchars(hgs_short_no($owner['device_unique_no'])) . ')' : '';
                                $deviceBlocked = true;
                                $deviceBindMsg = 'This device is already registered to student <strong>' . htmlspecialchars($owner['student_number']) . '</strong> (' . htmlspecialchars($owner['student_name'] ?? 'Unknown') . ')' . $ownerNo2 . '. A device may only be used by one student number. Please use your own device or ask the administrator to reset the binding.';
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'blocked_family_taken', json_encode(array_merge([
                                    'reason' => 'device family already bound to another student',
                                    'attempt_name' => $student['name'] ?? null,
                                    'attempt_family' => $fam,
                                    'owner' => $owner['student_number'],
                                    'owner_name' => $owner['student_name'] ?? null,
                                    'attempt_fp' => $device_fp,
                                    'attempt_model' => $device_model,
                                ], $hw_log), JSON_UNESCAPED_SLASHES));
                                $blocked_details = ['type'=>'taken','owner'=>$owner['student_number'],'owner_model'=>null];
                            } else {
                                // Same student, different browser (another browser on the
                                // same device, or a new device): move the binding here.
                                // device_fb adopts only when non-empty (see token-match path above).
                                $stmtUpd = $pdo->prepare("UPDATE student_device_bindings SET device_fingerprint = :fp, device_family = :fam, device_model = :model, device_fb = COALESCE(NULLIF(:fb, ''), device_fb), device_raw = :raw, platform = :plat, ip_address = :ip, user_agent = :ua, screen_resolution = :scr, timezone = :tz, student_name = :name, is_active = 1, last_seen = CURRENT_TIMESTAMP WHERE student_number = :sn");
                                $stmtUpd->execute([':fp'=>$device_fp,':fam'=>$fam,':model'=>$device_model,':fb'=>$fbav,':raw'=>$device_raw,':plat'=>$device_platform,':ip'=>$ip,':ua'=>$ua,':scr'=>$device_screen,':tz'=>$device_tz,':name'=>$student['name'] ?? $binding['student_name'],':sn'=>$student_number]);
                                $adoptFamily();
                                $unoNow = hgs_adopt_device_no($pdo, $student_number, $fam);

                                $tokMove = hgs_issue_device_token($pdo, $student_number);
                                hgs_set_device_cookies($tokMove, $unoNow);
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'family_enroll', json_encode(array_merge(['model'=>$device_model,'screen'=>$device_screen,'tz'=>$device_tz,'platform'=>$device_platform,'family'=>$fam,'unique_no'=>$unoNow,'prev_fb'=>(string)($binding['device_fb'] ?? ''),'key_family_bypass'=>($keyOverridesFamily ? (string)($owner['student_number'] ?? '') : '')], $hw_log), JSON_UNESCAPED_SLASHES));
                                hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'success', 'New browser recognized on trusted device');
                                $newBrowserEnrolled = true;
                            }
                            } // end token-owner else: existing family/move flow above
                            }
                        }
                    } catch (Exception $e) {
                        error_log('Device binding error: ' . $e->getMessage());
                        // Fail open? For strong security we fail closed but log.
                        // If DB error, allow login but log error so admin can audit — do not block student on infra failure.
                        if ($pdo) {
                            try { hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'error', $e->getMessage()); } catch (Exception $ee) {}
                        }
                    }

                    // Device-key enrollment: a registration ceremony attached
                    // to this login is verified and stored — but only when
                    // this number has NO key yet (first claim; same trust as
                    // first bind) and the login itself was not blocked. Never
                    // fatal to the login.
                    if (!$deviceBlocked && $pdo && is_array($keyPayload) && ($keyPayload['mode'] ?? '') === 'register') {
                        try {
                            $curB = $pdo->prepare("SELECT webauthn_credential_id FROM student_device_bindings WHERE student_number = :sn LIMIT 1");
                            $curB->execute([':sn' => $student_number]);
                            $curR = $curB->fetch(PDO::FETCH_ASSOC);
                            if ($curR && trim((string)($curR['webauthn_credential_id'] ?? '')) === '') {
                                $sesReg = $_SESSION['webauthn_challenge'] ?? null;
                                unset($_SESSION['webauthn_challenge']);
                                $chReg = null;
                                if (is_array($sesReg) && ($sesReg['mode'] ?? '') === 'register' && ($sesReg['sn'] ?? '') === $student_number && ($sesReg['exp'] ?? 0) >= time()) {
                                    $chReg = base64_decode((string)($sesReg['ch'] ?? ''), true);
                                }
                                if (is_string($chReg) && $chReg !== '') {
                                    list($newId, $newPem) = hgs_webauthn_register($keyPayload, $chReg, hgs_webauthn_rp(), hgs_webauthn_origin());
                                    if ($newId !== null) {
                                        $upK = $pdo->prepare("UPDATE student_device_bindings SET webauthn_credential_id = :id, webauthn_public_key = :pem, webauthn_sign_count = 0 WHERE student_number = :sn");
                                        $upK->execute([':id' => $newId, ':pem' => $newPem, ':sn' => $student_number]);
                                        hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'key_registered', 'Hardware device key enrolled');
                                    } else {
                                        hgs_log_device($pdo, $student_number, $device_fp, $device_model, $ip, $ua, 'key_register_failed', (string)$newPem);
                                    }
                                }
                            }
                        } catch (Exception $e) {}
                    }

                    if ($deviceBlocked) {
                        $error_message = $deviceBindMsg ?: 'Device not recognized. This student number is locked to another device. Please use the original device or contact the administrator.';
                    } else {
                        $_SESSION['student_logged_in'] = true;
                        $_SESSION['student_number'] = $student['student_number'];
                        $_SESSION['student_id'] = $student['student_id'];
                        $_SESSION['student_name'] = $student['name'];
                        $_SESSION['login_time'] = time();
                        $_SESSION['found_in_db'] = $found_in_db;
                        $_SESSION['device_fingerprint'] = $device_fp;
                        $_SESSION['device_family'] = $fam;
                        $_SESSION['device_model'] = $device_model;
                        $_SESSION['success_message'] = $newBrowserEnrolled
                            ? 'Login successful! New browser recognized on your trusted device — welcome, ' . htmlspecialchars($student['name']) . '!'
                            : 'Login successful! Welcome, ' . htmlspecialchars($student['name']) . '!';
                        // Native app (Flutter APK, UA "HORIZON-Student-App"): it
                        // keeps cookies itself but cannot carry them across a
                        // redirect, so the 302 below would strand its session
                        // and every app login would fail. Answer the app's POST
                        // directly with JSON — the session cookie rides this
                        // 200 response and the app's session probe then passes.
                        // Browsers are unaffected (they never send that UA).
                        if (stripos((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 'HORIZON-Student-App') !== false) {
                            while (ob_get_level() > 0) { @ob_end_clean(); }
                            header('Content-Type: application/json');
                            echo json_encode([
                                'status' => 'success',
                                'student_number' => $student['student_number'],
                                'name' => $student['name'] ?? '',
                            ]);
                            exit();
                        }
                        header('Location: index.php');
                        exit();
                    }
                } else {
                    // Student not found — log it
                    try {
                        $pdoNF = new PDO('sqlite:' . HGS_MAIN_DB);
                        $pdoNF->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                        hgs_log_device($pdoNF, $student_number, $device_fp, $device_model, $ip, $ua, 'not_found', 'Student number not in any database');
                    } catch (Exception $e) {}
                    $error_message = 'Student not found or Incorrect Student Number!. Please check your student number and try again.';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login — HORIZON | ESSUC</title>
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <meta name="theme-color" content="#4318FF">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="HORIZON">
    <link rel="manifest" href="manifest.webmanifest">
    <link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
    <link href="../css/bootstrap.min.css" rel="stylesheet">
<link href="../css/horizon-theme.css" rel="stylesheet">
<link href="../Font-Awesome-master/css/all.min.css" rel="stylesheet">
<style>
.horizon-login-extra .horizon-input-icon{position:absolute;left:12px;top:50%;transform:translateY(-50%);width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;background:var(--horizon-brand-50);color:var(--horizon-brand-500);border:1px solid #E9E3FF;font-size:.9rem;pointer-events:none}
.horizon-input-wrap{position:relative}
.horizon-input-wrap .form-control{padding-left:52px !important;height:48px}
@media (max-width:767.98px){.horizon-login-extra{min-height:100vh}}
.device-badge{font-size:10px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:6px 10px;border-radius:999px;display:inline-flex;align-items:center;gap:6px}
.device-badge.ok{background:#ECFDF5;border:1px solid #A7F3D0;color:#065F46}
.device-badge.wait{background:#FEF3C7;border:1px solid #FDE68A;color:#92400E}
.device-badge.fail{background:#FEF2F2;border:1px solid #FECACA;color:#991B1B}
</style>
</head>
<body>
<div id="pwaInstallBar" style="display:none;align-items:center;gap:10px;padding:10px 16px;background:var(--horizon-brand-linear);color:#fff;font-size:12.5px;font-weight:700">
  <i class="fas fa-mobile-screen"></i><span style="flex:1">Install HORIZON on your phone for one-tap grades access.</span>
  <button id="pwaInstallBtn" type="button" style="border:none;border-radius:999px;padding:7px 16px;background:#fff;color:var(--horizon-brand-500);font-weight:800;cursor:pointer">Install</button>
  <button id="pwaInstallX" type="button" aria-label="Dismiss" style="background:transparent;border:none;color:#fff;font-size:16px;cursor:pointer;opacity:.8">×</button>
</div>
<div class="horizon-auth-container horizon-login-extra">
  <div class="horizon-auth-form-side">
    <div style="width:100%;max-width:420px;margin:0 auto">
      <div class="d-flex align-items-center gap-2 mb-3">
        <span class="d-inline-flex align-items-center justify-content-center" style="width:38px;height:38px;border-radius:12px;background:var(--horizon-brand-linear);color:#fff"><i class="fas fa-graduation-cap"></i></span>
        <div><div style="font-weight:800;color:var(--horizon-text-title);line-height:1">ESSUC Grading System</div><small style="color:var(--horizon-text-muted);font-weight:700;letter-spacing:.08em;text-transform:uppercase;font-size:10px">Can-Avid Campus</small></div>
      </div>
      <h2 style="font-weight:800;color:var(--horizon-text-title);margin:0 0 6px;font-size:22px">Welcome back, Student</h2>
      <p style="color:var(--horizon-text-muted);font-size:13px;margin:0 0 18px;font-weight:500">Enter your student number to access your HORIZON portal.</p>
      <?php if (!empty($error_message)): ?>
        <div class="horizon-flash-banner horizon-flash-danger" role="alert" style="margin-bottom:16px"><i class="fas fa-circle-exclamation"></i><span style="font-weight:700;font-size:13px"><?php echo $error_message; // contains <strong> on device blocks, intentionally not escaped ?></span></div>
      <?php endif; ?>
      <?php if (!empty($blocked_details) && ($blocked_details['type'] ?? '') === 'taken'): ?>
        <div class="horizon-flash-banner horizon-flash-info" role="alert" style="margin-bottom:16px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <i class="fas fa-hand-pointer"></i>
          <span style="font-weight:700;font-size:13px;flex:1;min-width:200px">Using your own phone? Ask the admin to approve this device.</span>
          <button type="button" id="bindRequestBtn" class="btn btn-sm btn-primary rounded-pill px-3"><i class="fas fa-paper-plane me-1"></i>Request Approval</button>
        </div>
        <div id="bindRequestMsg" style="margin:-8px 0 16px;font-size:12px;font-weight:600"></div>
      <?php endif; ?>
      <div id="deviceStatus" class="device-badge wait mb-3" style="width:100%;justify-content:center"><i class="fas fa-microchip"></i><span id="deviceStatusText">Verifying device…</span><span id="deviceModelHint" style="opacity:.7;font-weight:600"></span></div>
      <form method="POST" action="login.php" novalidate id="studentLoginForm">
        <input type="hidden" name="action" value="login">
        <input type="hidden" name="device_fingerprint" id="device_fingerprint" value="">
        <input type="hidden" name="device_family" id="device_family" value="">
        <input type="hidden" name="device_hints" id="device_hints" value="">
        <input type="hidden" name="device_model" id="device_model" value="">
        <input type="hidden" name="device_raw" id="device_raw" value="">
        <input type="hidden" name="device_platform" id="device_platform" value="">
        <input type="hidden" name="device_screen" id="device_screen" value="">
        <input type="hidden" name="device_timezone" id="device_timezone" value="">
        <input type="hidden" name="device_aid" id="device_aid" value="">
        <input type="hidden" name="webauthn_result" id="webauthn_result" value="">
        <div class="mb-3">
          <label for="student_number" class="form-label">Student Number</label>
          <div class="horizon-input-wrap">
            <span class="horizon-input-icon"><i class="fas fa-id-card"></i></span>
            <input type="text" class="form-control" id="student_number" name="student_number" placeholder="XX-XXXXX" maxlength="8" pattern="^\d{2}-\d{5}$" inputmode="numeric" required autocomplete="off" value="<?php echo isset($_POST['student_number']) ? htmlspecialchars($_POST['student_number']) : ''; ?>">
          </div>
          <div class="form-text" style="color:var(--horizon-text-muted);font-size:11px;font-weight:600"><i class="fas fa-circle-info me-1"></i>Format <strong>XX-XXXXX</strong> (e.g., 25-12345) — dash auto-added</div>
        </div>
        <button type="submit" class="btn btn-gradient w-100" id="loginBtn" style="height:46px;border-radius:var(--horizon-radius-md);font-weight:800" disabled><i class="fas fa-spinner fa-spin me-2" id="loginBtnSpin"></i><span id="loginBtnLabel">Verifying device…</span></button>
        <div id="deviceHelp" class="form-text mt-2" style="font-size:11px;color:var(--horizon-text-muted);font-weight:600;display:none"><i class="fas fa-shield-halved me-1"></i>First login locks this student number to this device. You may use any browser on this same device, but other student numbers cannot use it.</div>
        <div class="d-flex align-items-center gap-2 my-3"><div style="height:1px;flex:1;background:var(--horizon-divider)"></div><span style="font-size:11px;font-weight:700;color:var(--horizon-text-muted)">or</span><div style="height:1px;flex:1;background:var(--horizon-divider)"></div></div>
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
          <a href="../landingpage.php" class="btn btn-secondary btn-sm"><i class="fas fa-user-plus me-1"></i>Enroll Now</a>
          <span style="font-size:11px;color:var(--horizon-text-muted);font-weight:600"><i class="fas fa-lock me-1"></i>Private &amp; secure</span>
        </div>
      </form>
      <div class="text-center mt-4" style="color:var(--horizon-text-muted);font-size:11px;font-weight:600">Need help? Contact your adviser or registrar.<br>Only <strong style="color:var(--horizon-text-title)">published</strong> grades are shown.<div class="mt-2" style="font-size:10px;opacity:.8">© <?php echo date('Y'); ?> ESSUC • HORIZON UI</div></div>
    </div>
  </div>
  <div class="horizon-auth-hero-side" style="flex-direction:column;text-align:left;align-items:flex-start">
    <div style="max-width:420px;width:100%">
      <div style="font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.82)"><i class="fas fa-sparkles me-1"></i>HORIZON Student Experience</div>
      <h1 style="font-size:28px;font-weight:800;line-height:1.15;color:#fff;margin:8px 0 10px">Your grades,<br>in beautiful focus.</h1>
      <p style="color:rgba(255,255,255,.88);font-size:13px;line-height:1.6">HORIZON brings clarity — published grades, assessments, and class insights in a clean, responsive workspace built for ESSUC.</p>
      <div class="d-flex flex-wrap gap-2 mt-3">
        <span class="badge" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);color:#fff"><i class="fas fa-shield-halved me-1"></i>Device-locked login</span>
        <span class="badge" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);color:#fff"><i class="fas fa-chart-simple me-1"></i>Real-time results</span>
        <span class="badge" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);color:#fff"><i class="fas fa-mobile-screen me-1"></i>One device per student</span>
      </div>
      <div class="horizon-card mt-4" style="border-radius:16px;padding:14px;background:rgba(255,255,255,.94);border:1px solid rgba(255,255,255,.6)">
        <div class="d-flex align-items-center gap-3 mb-2">
          <span class="horizon-widget-icon-box brand" style="width:42px;height:42px;min-width:42px;font-size:15px"><i class="fas fa-fingerprint"></i></span>
          <div><div style="font-weight:800;color:var(--horizon-text-title);font-size:13px;line-height:1">Strong Device Recognition</div><small style="color:var(--horizon-text-muted);font-weight:700;font-size:11px">First login binds • <span class="badge badge-success">fingerprint</span> <span class="badge badge-brand">build</span></small></div>
          <span class="ms-auto badge badge-brand">HORIZON</span>
        </div>
        <div class="d-flex gap-2 flex-wrap"><span class="badge badge-success">Canvas + WebGL</span><span class="badge badge-secondary">Screen & TZ</span><span class="badge badge-warning">Locked to device</span></div>
        <div style="font-size:11px;color:var(--horizon-text-muted);font-weight:600;margin-top:8px;line-height:1.4"><i class="fas fa-circle-info me-1"></i>Your student number will be permanently linked to this device on first login — any browser on this same device works. Only this device can then use that number. Contact your administrator to reset.</div>
      </div>
      <div class="mt-3 d-flex align-items-center gap-2" style="color:rgba(255,255,255,.88);font-size:11px;font-weight:700"><span class="d-inline-flex align-items-center justify-content-center rounded-circle" style="width:28px;height:28px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.2)"><i class="fas fa-building-columns"></i></span>Eastern Samar State University — Can-Avid Campus</div>
    </div>
  </div>
</div>
<script src="../js/bootstrap.bundle.min.js"></script>
<script>
const el=document.getElementById('student_number');
if(el){
  el.addEventListener('input',function(e){
    let v=e.target.value,pos=e.target.selectionStart,prev=e.target.getAttribute('data-prev')||'';
    let isDeleting=v.length<prev.length;
    let clean=v.replace(/[^\d-]/g,'');
    if(!isDeleting){let d=clean.replace(/-/g,'');clean=d.length>=2?d.substring(0,2)+'-'+d.substring(2,7):d;}
    if(e.target.value!==clean){e.target.value=clean;requestAnimationFrame(()=>{let p=isDeleting?Math.min(pos,clean.length):clean.length;try{e.target.setSelectionRange(p,p);}catch(_){}});}
    e.target.setAttribute('data-prev',clean);
  });
  el.addEventListener('paste',function(e){e.preventDefault();let t=(e.clipboardData||window.clipboardData).getData('text').replace(/[^\d]/g,'');if(t.length>=2)t=t.substring(0,2)+'-'+t.substring(2,7);e.target.value=t;requestAnimationFrame(()=>{try{e.target.setSelectionRange(t.length,t.length);}catch(_){}});e.target.setAttribute('data-prev',t);});
  el.addEventListener('focus',function(){const a=document.querySelector('.horizon-flash-danger');if(a)a.style.display='none';});
}
</script>
<script>
// ===== Strong device fingerprint — runs before submit, persists in localStorage =====
(function(){
  const LS_FP = 'hgs_device_fp_v2';
  const LS_MODEL = 'hgs_device_model_v3'; // v3: stores the build number (v2 stored the model number)
  const $fp = document.getElementById('device_fingerprint');
  const $fam = document.getElementById('device_family');
  const $hints = document.getElementById('device_hints');
  const $model = document.getElementById('device_model');
  const $raw = document.getElementById('device_raw');
  const $plat = document.getElementById('device_platform');
  const $scr = document.getElementById('device_screen');
  const $tz = document.getElementById('device_timezone');
  const $aid = document.getElementById('device_aid');
  const $badge = document.getElementById('deviceStatus');
  const $badgeText = document.getElementById('deviceStatusText');
  const $badgeHint = document.getElementById('deviceModelHint');
  const $btn = document.getElementById('loginBtn');
  const $btnLabel = document.getElementById('loginBtnLabel');
  const $btnSpin = document.getElementById('loginBtnSpin');
  const $help = document.getElementById('deviceHelp');

  function setBadge(state, text, hint){
    if(!$badge) return;
    $badge.className = 'device-badge ' + state + ' mb-3';
    if($badgeText) $badgeText.textContent = text;
    if($badgeHint) $badgeHint.textContent = hint ? ' • ' + hint : '';
    const icon = $badge.querySelector('i');
    if(icon){
      icon.className = state==='ok' ? 'fas fa-shield-halved' : state==='fail' ? 'fas fa-triangle-exclamation' : 'fas fa-microchip';
    }
  }
  function setBtnEnabled(on){
    if(!$btn) return;
    $btn.disabled = !on;
    if($btnSpin) $btnSpin.style.display = on ? 'none' : 'inline-block';
    if($btnLabel) $btnLabel.textContent = on ? 'Login to HORIZON Portal' : 'Verifying device…';
    // swap icon
    const ii = $btn.querySelector('i:not(#loginBtnSpin)');
    // keep spin separate
    if(on && $btnSpin) $btnSpin.className = 'fas fa-right-to-bracket me-2';
    if(!on && $btnSpin) $btnSpin.className = 'fas fa-spinner fa-spin me-2';
    if($help) $help.style.display = on ? 'block' : 'none';
  }

  function getDeviceBuild(){
    const ua = navigator.userAgent || '';
    // Build number: token after "Build/" (e.g. TP1A.220624.014) — NOT the
    // model number (e.g. SM-A127F) that precedes it in Android UAs.
    const bld = ua.match(/Build\/([^\s;)]+)/i);
    if(bld){
      let cand = (bld[1]||'').trim();
      if(cand && /[A-Za-z0-9]/.test(cand) && cand.length>=2 && cand.length<=40) return cand;
    }
    if(/iPhone/i.test(ua)) return 'iPhone';
    if(/iPad/i.test(ua)) return 'iPad';
    if(/Android/i.test(ua)) return 'Android Device';
    if(/Windows NT/i.test(ua)) return 'Windows PC';
    if(/Macintosh|Mac OS X/i.test(ua)) return 'Mac';
    if(/CrOS/i.test(ua)) return 'Chromebook';
    if(/Linux/i.test(ua)) return 'Linux PC';
    return 'Unknown Device';
  }

  function getCanvasFingerprint(){
    try{
      const c = document.createElement('canvas');
      c.width = 280; c.height = 60;
      const ctx = c.getContext('2d');
      if(!ctx) return 'no-canvas';
      ctx.textBaseline = 'top';
      ctx.font = "14px 'Arial'";
      ctx.fillStyle = '#4318FF';
      ctx.fillRect(0,0,280,60);
      ctx.fillStyle = '#fff';
      ctx.fillText('HORIZON-ESSUC-' + (navigator.language||'en'), 8, 8);
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fillText(navigator.userAgent.slice(0, 48), 8, 30);
      // geometry
      ctx.strokeStyle = '#05CD99';
      ctx.beginPath();
      ctx.arc(220, 30, 18, 0, Math.PI*2);
      ctx.stroke();
      return c.toDataURL();
    }catch(e){ return 'canvas-err'; }
  }

  function getWebGLInfo(){
    try{
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
      if(!gl) return 'no-webgl';
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      let vendor = '', renderer = '';
      if(dbg){
        vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || '';
        renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '';
      }
      return (vendor + '|' + renderer + '|' + (gl.getParameter(gl.VERSION)||'') ).slice(0, 220);
    }catch(e){ return 'webgl-err'; }
  }

  function djb2Hex(str){
    let h1 = 5381, h2 = 52711;
    for(let i=0;i<str.length;i++){
      const ch = str.charCodeAt(i);
      h1 = ((h1 << 5) + h1 + ch) >>> 0;
      h2 = ((h2 << 5) + h2 + ch) >>> 0;
    }
    const hex = (h1>>>0).toString(16).padStart(8,'0') + (h2>>>0).toString(16).padStart(8,'0');
    // stretch to 32 hex by hashing again with length
    let h3 = 0;
    for(let i=0;i<str.length;i++) h3 = (h3 * 31 + str.charCodeAt(i)) >>> 0;
    return (hex + (h3>>>0).toString(16).padStart(8,'0') + (str.length>>>0).toString(16).padStart(8,'0')).slice(0,32);
  }

  async function sha256Hex(str){
    try{
      if(window.crypto && crypto.subtle && crypto.subtle.digest){
        const enc = new TextEncoder().encode(str);
        const buf = await crypto.subtle.digest('SHA-256', enc);
        const arr = new Uint8Array(buf);
        let out = '';
        for(let i=0;i<16;i++) out += arr[i].toString(16).padStart(2,'0'); // 32 hex = 128 bits; enough
        return out;
      }
    }catch(e){}
    return djb2Hex(str);
  }

  async function computeFingerprint(){
    // Reuse localStorage if present and looks valid — stability across reloads/updates
    try{
      const cached = localStorage.getItem(LS_FP);
      const cachedModel = localStorage.getItem(LS_MODEL);
      if(cached && /^[a-f0-9]{16,128}$/i.test(cached)){
        // still collect fresh signals for hidden fields, but keep fingerprint stable
        const ua = navigator.userAgent || '';
        return { fp: cached.toLowerCase(), model: cachedModel || getDeviceBuild(), ua: ua, cached: true };
      }
    }catch(e){}
    const ua = navigator.userAgent || '';
    const plat = navigator.platform || '';
    const lang = navigator.language || '';
    const tz = (Intl && Intl.DateTimeFormat && Intl.DateTimeFormat().resolvedOptions().timezone) || '';
    const scr = (screen.width||0) + 'x' + (screen.height||0) + 'x' + (screen.colorDepth||0);
    const hw = (navigator.hardwareConcurrency||'') + '|' + (navigator.deviceMemory||'');
    const canvas = getCanvasFingerprint();
    const webgl = getWebGLInfo();
    const vendor = navigator.vendor || '';
    const raw = [ua, plat, lang, tz, scr, hw, vendor, canvas.slice(0, 900), webgl].join('|');
    const fp = await sha256Hex(raw);
    const model = getDeviceBuild();
    try{
      localStorage.setItem(LS_FP, fp);
      localStorage.setItem(LS_MODEL, model);
    }catch(e){}
    return { fp: fp, model: model, ua: ua, cached: false };
  }

  // Cross-browser device-family hash: ONLY signals that are identical in
  // every browser on one physical device (no UA, vendor, canvas, raw WebGL,
  // language or deviceMemory — those differ per browser/engine and would
  // split one device in two). Same machine + any browser => same family.
  // Deliberately recomputed every load (never cached): stability comes from
  // the signals, not storage.
  async function computeFamily(){
    try{
      const plat = navigator.platform || '';
      const scr = (screen.width||0) + 'x' + (screen.height||0) + 'x' + (screen.colorDepth||0);
      const av = (screen.availWidth||0) + 'x' + (screen.availHeight||0);
      let tz = '';
      try{ tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; }catch(e){}
      const hw = (navigator.hardwareConcurrency||'');
      const touch = (navigator.maxTouchPoints||0);
      const gpu = getGpuToken();
      return await sha256Hex(['HGS-FAMILY-V2', plat, scr, av, tz, hw, touch, gpu].join('|'));
    }catch(e){ return ''; }
  }

  // Graphics-chip token for the family. Raw renderer strings differ per
  // browser ("ANGLE (ARM, Mali-G57 MC1, OpenGL ES 3.2)" in Chrome vs
  // "Mali-G57 MC1" in Firefox), so they are normalized hard: unwrap ANGLE,
  // drop API/version/vendor fluff and lone digits, compact the rest. Same
  // chip => same token in every browser; different chips (Mali vs Adreno)
  // never collide. This is what separates same-spec phones.
  function normGpu(s){
    let t = String(s || '').toLowerCase();
    t = t.replace(/angle\s*\(([^)]*)\)/g, '$1');
    t = t.replace(/opengl\s*es[\s\d.]*/g, ' ');
    t = t.replace(/direct3d.*/g, ' ');
    t = t.replace(/0x[0-9a-f]+/g, ' ');
    t = t.replace(/[^a-z0-9]+/g, ' ');
    t = t.replace(/\b(angle|webgl|experimental|renderer|graphics|gpu|direct|tm|arm|qualcomm|inc|technologies|technology|corporation|corp|company|limited|ltd|semiconductor|multimedia|vs|ps|d3d|metal|opengl|es|pci|pcie|sse2?|sse4|avx2?|swiftshader|google|apple|unspecified|version|vulkan)\b/g, ' ');
    t = t.replace(/\b\d\b/g, ' ');
    // Drop repeated words (vendor often duplicates the renderer brand —
    // e.g. "NVIDIA … NVIDIA GeForce …") so equivalent strings converge.
    t = t.replace(/\s+/g, ' ').trim().split(' ').filter(function(w, i, a){ return w !== '' && a.indexOf(w) === i; }).join('').slice(0, 48);
    return t;
  }
  function getGpuToken(){
    try{
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
      if(!gl) return 'no-webgl';
      const dbg = gl.getExtension('WEBGL_debug_renderer_info');
      let vendor = '', renderer = '';
      if(dbg){
        vendor = gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) || '';
        renderer = gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) || '';
      }
      const tok = normGpu(vendor + ' ' + renderer);
      return tok !== '' ? tok : 'no-gpu-string';
    }catch(e){ return 'webgl-err'; }
  }

  // Client Hints: real hardware facts the UA string hides (Android model
  // name, OS version, CPU architecture). Display/forensics only — versions
  // change with updates, so this never feeds identity hashes.
  async function collectHints(){
    try{
      const uad = navigator.userAgentData;
      if(!uad) return '';
      const out = { v: 1, brands: null, mobile: null, platform: null, high: {} };
      try{
        out.brands = uad.brands || null;
        out.mobile = (uad.mobile === undefined) ? null : !!uad.mobile;
        out.platform = uad.platform || null;
      }catch(e){}
      try{
        if(uad.getHighEntropyValues){
          const high = await uad.getHighEntropyValues(['model', 'platformVersion', 'architecture', 'bitness', 'fullVersionList']);
          out.high = {
            model: high.model || '',
            platformVersion: high.platformVersion || '',
            architecture: high.architecture || '',
            bitness: high.bitness || '',
            fullVersionList: (high.fullVersionList || []).map(function(b){ return { brand: b.brand || '', version: b.version || '' }; }).slice(0, 6)
          };
        }
      }catch(e){}
      return JSON.stringify(out).slice(0, 500);
    }catch(e){ return ''; }
  }

  // ANDROID_ID bridge: the school wrapper app injects it via
  // window.HGSAndroidId (string) or window.HGSBridge.getAndroidId().
  // Plain browsers have neither — the field stays empty and the server
  // stores NULL. Server re-validates, so this check is only hygiene.
  function getAndroidId(){
    try{
      if(typeof window.HGSAndroidId === 'string' && /^[a-f0-9]{8,64}$/i.test(window.HGSAndroidId.trim())) return window.HGSAndroidId.trim().toLowerCase();
      if(window.HGSBridge && typeof window.HGSBridge.getAndroidId === 'function'){
        const v = String(window.HGSBridge.getAndroidId() || '').trim();
        if(/^[a-f0-9]{8,64}$/i.test(v)) return v.toLowerCase();
      }
    }catch(e){}
    return '';
  }

  // Fill hidden fields once fingerprint is ready, then enable submit
  (async function init(){
    setBtnEnabled(false);
    setBadge('wait', 'Verifying device…', '');
    try{
      const res = await computeFingerprint();
      const famHash = await computeFamily();
      const hints = await collectHints();
      const fp = (res.fp||'').toLowerCase();
      const model = res.model || getDeviceBuild();
      const ua = res.ua || navigator.userAgent || '';
      const plat = navigator.platform || '';
      const scr = (screen.width||0)+'x'+(screen.height||0);
      let tz = '';
      try{ tz = Intl.DateTimeFormat().resolvedOptions().timeZone || ''; }catch(e){}
      if($fp) $fp.value = fp;
      if($fam && /^[a-f0-9]{16,128}$/i.test(famHash)) $fam.value = famHash.toLowerCase();
      if($hints && hints) $hints.value = String(hints).slice(0, 500);
      if($model) $model.value = model;
      if($raw) $raw.value = ua.slice(0,500);
      if($plat) $plat.value = plat.slice(0,80);
      if($scr) $scr.value = scr;
      if($tz) $tz.value = tz;
      if($aid) $aid.value = getAndroidId();
      if(fp && /^[a-f0-9]{16,128}$/i.test(fp)){
        setBadge('ok', 'Device verified', model);
        setBtnEnabled(true);
      }else{
        setBadge('fail', 'Device verification failed', 'Enable JS & reload');
        // still enable but server will reject with friendly message
        setBtnEnabled(true);
      }
    }catch(e){
      setBadge('fail', 'Device check error', 'Reload page');
      setBtnEnabled(true);
    }
  })();

  // Safety: if user submits before fingerprint (race), block and recompute synchronously
  const form = document.getElementById('studentLoginForm');
  if(form){
    form.addEventListener('submit', function(e){
      const v = $fp ? $fp.value.trim() : '';
      if(!v || !/^[a-f0-9]{16,128}$/i.test(v)){
        e.preventDefault();
        setBadge('fail','Device not ready — reloading…','');
        // force recompute then submit
        (async()=>{
          const r = await computeFingerprint();
          const fh = await computeFamily();
          const hz = await collectHints();
          if($fp) $fp.value = r.fp;
          if($model) $model.value = r.model;
          if($fam && /^[a-f0-9]{16,128}$/i.test(fh)) $fam.value = fh.toLowerCase();
          if($hints && hz) $hints.value = String(hz).slice(0, 500);
          if($aid && !$aid.value) $aid.value = getAndroidId();
          form.submit();
        })();
      }
    });
  }
})();
</script>
<script>
// ===== Hardware device key (WebAuthn) — runs the register/authenticate
// ceremony before the normal POST, then attaches the result. Any failure
// (no support, insecure HTTP/LAN-IP context, user cancel) silently falls
// back to the legacy login — the server decides what that means.
(function(){
  var form = document.getElementById('studentLoginForm');
  var res = document.getElementById('webauthn_result');
  if (!form || !res) return;
  function b64uDec(s){
    s = String(s || '').replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var bin = atob(s);
    var b = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) b[i] = bin.charCodeAt(i);
    return b;
  }
  function b64uEnc(buf){
    var b = new Uint8Array(buf);
    var s = '';
    for (var i = 0; i < b.length; i += 8192) s += String.fromCharCode.apply(null, b.subarray(i, i + 8192));
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }
  function te(s){
    if (window.TextEncoder) return new TextEncoder().encode(s);
    var b = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0xff;
    return b;
  }
  async function doRegister(opt){
    var cred = await navigator.credentials.create({ publicKey: {
      challenge: b64uDec(opt.challenge),
      rp: { name: 'HORIZON ESSUC', id: opt.rpId },
      user: { id: te(opt.userHandle || opt.userName || 'student'), name: opt.userName || 'student', displayName: opt.userName || 'student' },
      pubKeyCredParams: [{ type: 'public-key', alg: -7 }],
      timeout: 60000, attestation: 'none',
      authenticatorSelection: { userVerification: 'preferred' }
    }});
    if (!cred) return null;
    return { mode: 'register', id: cred.id, rawId: b64uEnc(cred.rawId),
      response: { attestationObject: b64uEnc(cred.response.attestationObject), clientDataJSON: b64uEnc(cred.response.clientDataJSON) } };
  }
  async function doAuthenticate(opt){
    var cred = await navigator.credentials.get({ publicKey: {
      challenge: b64uDec(opt.challenge),
      rpId: opt.rpId,
      allowCredentials: [{ type: 'public-key', id: b64uDec(opt.credentialId) }],
      timeout: 60000, userVerification: 'preferred'
    }});
    if (!cred) return null;
    return { mode: 'authenticate', id: cred.id, rawId: b64uEnc(cred.rawId),
      response: { authenticatorData: b64uEnc(cred.response.authenticatorData), clientDataJSON: b64uEnc(cred.response.clientDataJSON), signature: b64uEnc(cred.response.signature) } };
  }
  form.addEventListener('submit', function(e){
    if (form.dataset.hgsKeyDone === '1') return; // second pass: proceed
    if (!window.PublicKeyCredential || !navigator.credentials) return; // plain legacy submit
    e.preventDefault();
    (async function(){
      try {
        var snEl = document.getElementById('student_number');
        var sn = snEl ? snEl.value.trim() : '';
        var r = await fetch('login.php?webauthn=options&student_number=' + encodeURIComponent(sn), { credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
        var opt = null;
        try { opt = await r.json(); } catch (_) { opt = null; }
        if (opt && opt.status === 'success' && opt.challenge && (opt.mode === 'register' || opt.mode === 'authenticate')){
          var out = (opt.mode === 'register') ? await doRegister(opt) : await doAuthenticate(opt);
          if (out) res.value = JSON.stringify(out);
        }
      } catch (err) { try { console.warn('device key skipped:', err); } catch (_) {} }
      form.dataset.hgsKeyDone = '1';
      form.submit(); // programmatic: bypasses listeners, no loop
    })();
  });
})();
</script>
<script>
// ===== Binding-approval request — blocked student asks the admin to bind
// this device. Forwards the already-computed device signals; the server
// dedupes while a request is still open. Independent of the login submit.
(function(){
  var btn = document.getElementById('bindRequestBtn');
  if (!btn) return;
  var msgBox = document.getElementById('bindRequestMsg');
  var orig = btn.innerHTML;
  function showMsg(t, isErr){
    if (!msgBox) return;
    msgBox.textContent = t;
    msgBox.style.color = isErr ? '#991b1b' : '#065f46';
  }
  btn.addEventListener('click', function(){
    var snEl = document.getElementById('student_number');
    var sn = snEl ? String(snEl.value || '').trim() : '';
    if (!/^\d{2}-\d{5}$/.test(sn)) { showMsg('Enter your student number first (XX-XXXXX).', true); return; }
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Sending…';
    var p = function(id){ var el = document.getElementById(id); return el ? el.value : ''; };
    var body = 'bind=request&student_number=' + encodeURIComponent(sn)
      + '&device_fingerprint=' + encodeURIComponent(p('device_fingerprint'))
      + '&device_family=' + encodeURIComponent(p('device_family'))
      + '&device_model=' + encodeURIComponent(p('device_model'))
      + '&device_raw=' + encodeURIComponent(p('device_raw'));
    fetch('login.php?bind=request', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }, body: body })
      .then(function(r){ return r.json(); })
      .then(function(j){
        if (j && (j.status === 'success' || j.status === 'info')) {
          btn.disabled = true;
          btn.innerHTML = '<i class="fas fa-check me-1"></i>Request sent';
          showMsg(j.msg || 'Admin has been notified.', false);
        } else {
          btn.disabled = false;
          btn.innerHTML = orig;
          showMsg((j && j.msg) || 'Could not send request.', true);
        }
      })
      .catch(function(){
        // Offline: queue the request in IndexedDB — api_sync.php push
        // delivers it on reconnect (server dedupes while one is open).
        if (window.HorizonDB) {
          HorizonDB.queueAction('bind_request', {
            student_number: sn,
            device_fingerprint: p('device_fingerprint'),
            device_family: p('device_family'),
            device_model: p('device_model'),
            device_raw: p('device_raw')
          }).then(function(qid){
            if (qid) {
              btn.disabled = true;
              btn.innerHTML = '<i class="fas fa-check me-1"></i>Request saved';
              showMsg('No internet — request saved on this device, will send when you reconnect.', false);
            } else {
              btn.disabled = false;
              btn.innerHTML = orig;
              showMsg('Network error — please try again.', true);
            }
          });
          return;
        }
        btn.disabled = false;
        btn.innerHTML = orig;
        showMsg('Network error — please try again.', true);
      });
  });
})();
</script>
<script src="js/offline-db.js"></script>
<script>
// PWA: register service worker + in-page install prompt.
// Skipped on https://localhost (self-signed cert => SSL fetch error).
(function() {
  var h = location.hostname || '';
  var isLocal = h === 'localhost' || h === '127.0.0.1' || h === '::1' || h.indexOf('.') === -1 || /^192\.168\./.test(h) || /^10\./.test(h) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(h);
  var ok = ('serviceWorker' in navigator) && ((location.protocol === 'http:' && (h === 'localhost' || h === '127.0.0.1')) || (location.protocol === 'https:' && !isLocal));
  if (ok) window.addEventListener('load', function() { navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function() {}); });
})();
(function() {
  var deferred = null;
  var bar = document.getElementById('pwaInstallBar');
  window.addEventListener('beforeinstallprompt', function(e) {
    e.preventDefault();
    deferred = e;
    if (bar) bar.style.display = 'flex';
  });
  var btn = document.getElementById('pwaInstallBtn');
  if (btn) btn.addEventListener('click', function() {
    if (!deferred) return;
    deferred.prompt();
    deferred.userChoice.then(function() { deferred = null; if (bar) bar.style.display = 'none'; });
  });
  var x = document.getElementById('pwaInstallX');
  if (x) x.addEventListener('click', function() { if (bar) bar.style.display = 'none'; });
})();
</script>
</body>
</html>
